// ════════════════════════════════════
//  APPLICATION STATE
// ════════════════════════════════════
let supplierFiles = [], billingFiles = [];
let purchaseMap = {};
let billingPkgMap = {};
let supTransactions = {};
let supFileTotals = {};
let billingRows = [];
let billingPkgCounter = {};  // NDC → {pkgSize: count} for modal calculation
let ndcGroups = [], allRows = [], filteredRows = [], parseStats = {};
let activeFilter = 'all', sortCol = 'description', sortDir = 1;
let rawPreviewData = [];
// ── Column override map ──────────────────────────────────────────────
// Keyed by file identifier (fileName or fileName[sheetName]).
// Each entry holds field → column index overrides set by the user.
// e.g. { 'TRXADE.csv': { ndc: 4, qty: 15, date: 2 } }
let columnOverrides = {};

// Apply overrides to a mappingIdx object — user picks win over auto-detect
function applyColOverrides(fileKey, mappingObj) {
    const ov = columnOverrides[fileKey];
    if (!ov) return mappingObj;
    return { ...mappingObj, ...ov };
}

// Save a single field override for a file and re-run reconciliation
function setColOverride(fileKey, field, colIdx) {
    if (!columnOverrides[fileKey]) columnOverrides[fileKey] = {};
    if (colIdx < 0) {
        delete columnOverrides[fileKey][field];
    } else {
        columnOverrides[fileKey][field] = colIdx;
    }
    // Re-run full parse + reconcile so the new mapping takes effect
    reRunWithOverrides();
}

// Reads the filename/field safely from data-* attributes (set via the DOM API,
// which handles arbitrary characters correctly) instead of embedding raw
// values into the onchange="..." attribute string, which previously broke
// whenever a filename's JSON.stringify-wrapped quotes collided with the
// surrounding double-quoted HTML attribute.
function setColOverrideFromSelect(selectEl) {
    const fileKey = selectEl.dataset.filename;
    const field = selectEl.dataset.field;
    const colIdx = parseInt(selectEl.value);
    setColOverride(fileKey, field, colIdx);
}

// Same data-attribute pattern as setColOverrideFromSelect above — avoids
// embedding a raw filename into an onclick="..." string, which is exactly
// what broke this button (it referenced a variable that no longer existed
// after the onchange fix, and before that had the same quote-collision risk).
function resetFileMapping(btnEl) {
    const fileKey = btnEl.dataset.filename;
    if (typeof columnOverrides !== 'undefined') {
        delete columnOverrides[fileKey];
        reRunWithOverrides();
    }
}

async function reRunWithOverrides() {
    // ── Find which tab is currently active so we can return to it ──
    const activeTabBtn = document.querySelector('.topbar-tab.active');
    const activeTabName = activeTabBtn
        ? (activeTabBtn.getAttribute('onclick') || '').match(/switchTab\('(\w+)'/)?.[1] || 'results'
        : 'results';

    // ── Re-parse all files with current overrides ──
    purchaseMap = {}; supTransactions = {}; supFileTotals = {};
    billingRows = []; billingPkgMap = {}; billingPkgCounter = {};
    const savedOverrides = JSON.parse(JSON.stringify(columnOverrides)); // deep copy
    rawPreviewData = []; parseStats = {};

    try {
        const totalFiles = billingFiles.length + supplierFiles.length;
        let done = 0;

        showProg(true, 'Re-mapping columns…', 5);
        await tick();

        for (const bf of billingFiles) {
            const pct = 5 + Math.round((done / Math.max(totalFiles, 1)) * 40);
            showProg(true, `Re-reading: ${bf.name.slice(0, 30)}`, pct);
            await tick();
            await readBilling(bf);
            done++;
        }
        for (const f of supplierFiles) {
            const pct = 5 + Math.round((done / Math.max(totalFiles, 1)) * 40);
            showProg(true, `Re-reading: ${f.name.slice(0, 30)}`, pct);
            await tick();
            await readSupplier(f);
            done++;
        }

        showProg(true, 'Reconciling…', 50);
        await tick();
        columnOverrides = savedOverrides; // restore before reconcile
        reconcile();

        // ── Render only the tab the user is actually looking at — the rest
        // get marked dirty and will render lazily via switchTab()'s existing
        // dirty-check (see tabs-other.js), exactly like normal navigation
        // already does. Eagerly rendering all 9 tabs on every remap was the
        // actual cause of "remapping takes time" — most of that work was for
        // tabs nobody was even looking at yet.
        showProg(true, 'Updating Results…', 60);
        await tick();
        renderAll(); // always renders Results (it isn't part of the dirty-tab system)

        showProg(true, 'Updating current tab…', 80);
        await tick();
        const lazyTabs = ['suppliers','final','bill','dollar','discarded','issues','notbilled','mfp','raw'];
        const renderFns = {
            suppliers: renderSuppliersTab, final: renderFinalTab, bill: renderBillTab,
            dollar: renderDollarTab, discarded: renderDiscardedTab, issues: renderIssuesTab,
            notbilled: renderNotBilledTab, mfp: renderMFP, raw: renderRawPreview,
        };
        lazyTabs.forEach(t => {
            if (t === activeTabName && renderFns[t]) {
                renderFns[t]();
                if (typeof _dirty !== 'undefined') _dirty[t] = false;
            } else if (typeof _dirty !== 'undefined') {
                _dirty[t] = true; // will render next time the user actually switches to it
            }
        });
        // Preview is cheap to keep current (it's often the tab being actively
        // used while remapping) and isn't row-heavy like the data tabs, so
        // it's fine to always refresh it rather than defer it.
        if (activeTabName !== 'raw') { renderRawPreview(); if (typeof _dirty !== 'undefined') _dirty['raw'] = false; }

        showProg(true, 'Done!', 100);
        await tick();
        showProg(false, '', 100);

        // ── Return user to the tab they were on ──
        const tabBtn = document.querySelector(`.topbar-tab[onclick*="switchTab('${activeTabName}'"]`);
        if (tabBtn) switchTab(activeTabName, tabBtn);

        // ── Show a brief "Remapped ✓" toast ──
        _showRemapToast('Column mapping updated — all tabs refreshed');

    } catch (err) {
        console.error('Re-map error:', err);
        showProg(false, '', 0);
        alert('Error applying column mapping:\n' + err.message);
    }
}

function _showRemapToast(msg) {
    let toast = document.getElementById('remap-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'remap-toast';
        toast.style.cssText = [
            'position:fixed', 'bottom:24px', 'left:50%', 'transform:translateX(-50%) translateY(20px)',
            'background:#059669', 'color:#fff', 'padding:10px 22px', 'border-radius:8px',
            'font-size:13px', 'font-weight:600', 'box-shadow:0 4px 16px rgba(0,0,0,.18)',
            'z-index:9999', 'opacity:0', 'transition:all .3s ease', 'pointer-events:none'
        ].join(';');
        document.body.appendChild(toast);
    }
    toast.textContent = '✓ ' + msg;
    // Fade in
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(-50%) translateY(0)';
    });
    // Fade out after 3s
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(-50%) translateY(20px)';
    }, 3000);
}
let mfpActiveYear = 'all', mfpActiveStatus = 'all', mfpSortCol = 'desc', mfpSortDir = 1;
let supSearch = '', supSortCol = 'desc', supSortDir = 1, supFormFilter = 'all';
let rawSearchTerms = {}, rawCollapsed = {}, rawGlobalSearch = '';
let finalSearch = '', finalSortCol = 'description', finalSortDir = 1, finalStatusFilter = 'all', finalInsFilter = 'all';
let nbSearch = '', nbSortCol = 'desc', nbSortDir = 1, nbFormFilter = 'all';
let billSearch = '', billSortCol = 'totalRxQty', billSortDir = -1, billIssuesOnly = false;
let discSearch = '', discSortCol = 'desc', discSortDir = 1, discInsFilter = 'all', discFormFilter = 'all';
let issSearch = '', issSortCol = 'shortAmt', issSortDir = 1, issTypeFilter = 'all';
let globalNDCSearch = '';   // IMPROVEMENT 12: global cross-tab NDC search

// ════════════════════════════════════
//  UTILITY FUNCTIONS
// ════════════════════════════════════

// ── Debounce: returns a function that waits `ms` ms after the last call ──
function debounce(fn, ms) {
    let timer = null;
    return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(() => { timer = null; fn.apply(this, args); }, ms);
    };
}

function buildDesc(name, strong, form) {
    const parts = [name, strong, form].map(s => (s || '').trim().toUpperCase()).filter(Boolean);
    return parts.join(' - ');
}

// Resolve the best available description for an NDC
// Falls back: supplier description → billing drgName → NDC-based lookup → placeholder
function resolveDesc(desc, strong, form, ndc) {
    // Try to enrich strong/form from purchaseMap if not provided
    let s = strong, f = form;
    if (ndc && typeof purchaseMap !== 'undefined' && purchaseMap[ndc]) {
        if (!s && purchaseMap[ndc].strong) s = purchaseMap[ndc].strong;
        if (!f && purchaseMap[ndc].form)   f = purchaseMap[ndc].form;
    }
    const built = buildDesc(desc, s, f);
    if (built) return built;
    // Try billing rows for this NDC
    if (ndc && typeof billingRows !== 'undefined') {
        const bRow = billingRows.find(r => r.ndc === ndc && r.drgName);
        if (bRow && bRow.drgName) return buildDesc(bRow.drgName, bRow.strong || s, bRow.form || f);
    }
    // Try purchaseMap description (already has strong/form baked in if stored)
    if (ndc && typeof purchaseMap !== 'undefined' && purchaseMap[ndc] && purchaseMap[ndc].description) {
        return buildDesc(purchaseMap[ndc].description, s, f) || purchaseMap[ndc].description.toUpperCase();
    }
    return '';
}

function descCellHtml(name, strong, form, searchTerm, ndc) {
    // Try to resolve description with fallbacks
    const resolved = resolveDesc(name, strong, form, ndc);
    const hl = v => searchTerm ? hlText(escHtml(v), searchTerm) : escHtml(v);
    if (resolved) {
        return `<div class="desc-single-line">${hl(resolved)}</div>`;
    }
    // No description found — show NDC as fallback with a clear visual hint
    const ndcDisp = ndc ? `<span style="font-family:'Courier New',monospace;color:#7c3aed;font-weight:600">${escHtml(ndc)}</span>` : '';
    return `<div class="desc-single-line desc-missing">
        <span class="desc-na-badge" title="No drug description found in supplier or billing files">No description</span>
        ${ndcDisp}
    </div>`;
}

function resolveInsName(raw, bin) {
    return (bin && BIN_TO_INSURER[bin]) ? BIN_TO_INSURER[bin] : (raw || '');
}

function matchCol(hdrs, f) {
    for (const p of PATTERNS[f] || []) {
        const i = hdrs.findIndex(h => p.test(h));
        if (i >= 0) return i;
    }
    return -1;
}

function cleanNDC(raw) {
    if (!raw) return '';
    let s = String(raw).replace(/[^0-9]/g, '').trim();
    if (s.length > 0 && s.length < 11) s = s.padStart(11, '0');
    return s;
}

function normBIN(v) {
    if (!v) return '';
    let s = String(v).replace(/[^0-9]/g, '').trim();
    if (!s) return '';
    if (s.length > 6) s = s.slice(-6);
    if (s.length < 6) s = s.padStart(6, '0');
    return s;
}

function stripF(v) {
    return v == null ? '' : String(v).replace(/^="?|"?$/g, '').trim();
}

function escHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function parseSize(s) {
    if (s == null || s === '' || s === undefined) return 1;
    const str = String(s).trim().toUpperCase();
    if (!str) return 1;
    const mx = str.match(/^(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)/i);
    if (mx) { const v = parseFloat(mx[1]) * parseFloat(mx[2]); return v > 0 ? v : 1; }
    const mn = str.match(/^(\d+(?:\.\d+)?)/);
    if (mn) { const v = parseFloat(mn[1]); return v > 0 ? v : 1; }
    return 1;
}

function normalizeNDCSearch(s) { return s.replace(/[-\s.]/g, ''); }

function fmt(n, dec = 0) {
    if (n === undefined || n === null || n === '') return '';
    const x = parseFloat(n);
    if (isNaN(x)) return n;
    if (dec > 0) return x.toFixed(dec);
    return x.toLocaleString();
}

function hlText(s, term) {
    if (!term) return s;
    const esc = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return s.replace(new RegExp('(' + esc + ')', 'gi'), '<mark style="background:#fef08a;color:#78350f;border-radius:2px;padding:0 1px">$1</mark>');
}

function csvLine(line) {
    const r = [];
    let cur = '', q = false;
    for (const c of line) {
        if (c === '"') { q = !q; }
        else if (c === ',' && !q) { r.push(cur); cur = ''; }
        else cur += c;
    }
    r.push(cur);
    return r;
}

function copyText(t) { navigator.clipboard.writeText(t).catch(() => {}); }
function tick() { return new Promise(r => setTimeout(r, 10)); }

// Prompt shown when NDC wasn't auto-detected in one or more files. Resolves to:
//   'applied'      — user picked column(s) and reRunWithOverrides() already
//                     ran with them (processFiles should return early)
//   'goToPreview'  — user navigated to Preview to sort it out manually
// (There's no 'skip' path here — NDC is required, so reconciling without it
// isn't offered as an option. Description is not checked by this prompt at
// all; if it's not detected, rows just show "No description" as before.)
let _mappingPromptResolve = null;
function showMappingPrompt(problemFiles) {
    return new Promise((resolve) => {
        _mappingPromptResolve = resolve;
        const overlay = document.getElementById('mapping-prompt-overlay');
        const list = document.getElementById('mapping-prompt-files');
        const title = document.getElementById('mapping-prompt-title');
        const body = document.getElementById('mapping-prompt-body');
        const errEl = document.getElementById('mapping-prompt-error');
        if (!overlay || !list) { resolve('skip'); return; } // no UI available — don't block silently forever
        if (errEl) errEl.style.display = 'none';

        if (title) title.textContent = "A required column needs your help";
        if (body) body.textContent = "We couldn't automatically find the NDC column in the file(s) below — without it we can't reconcile those rows at all. Pick the right column, or go fix it in Preview.";

        list.innerHTML = problemFiles.map(p => {
            const fd = p.fd;
            const optionsHtml = ['<option value="-1">— select a column —</option>',
                ...fd.headers.map((h, i) => `<option value="${i}">${i}: ${escHtml(h)}</option>`)].join('');
            return `<div class="mapping-prompt-file-card">
                <div class="mapping-prompt-file-name">📄 ${escHtml(fd.fileName)}</div>
                <div class="mapping-prompt-field-row">
                    <span class="mapping-prompt-field-label">NDC *</span>
                    <select class="mapping-prompt-field-select" data-filename="${escHtml(fd.fileName)}" data-field="ndc">${optionsHtml}</select>
                </div>
            </div>`;
        }).join('');
        overlay.style.display = 'flex';
    });
}

async function _mappingPromptApply() {
    const overlay = document.getElementById('mapping-prompt-overlay');
    const errEl = document.getElementById('mapping-prompt-error');
    const selects = [...document.querySelectorAll('#mapping-prompt-files .mapping-prompt-field-select')];

    const missingRequired = selects.filter(s => parseInt(s.value) < 0);
    if (missingRequired.length) {
        if (errEl) { errEl.textContent = 'Please select an NDC column for every file listed — it\'s required to reconcile.'; errEl.style.display = 'block'; }
        return;
    }

    selects.forEach(s => {
        const val = parseInt(s.value);
        const fileKey = s.dataset.filename;
        const field = s.dataset.field;
        if (!columnOverrides[fileKey]) columnOverrides[fileKey] = {};
        columnOverrides[fileKey][field] = val;
    });

    if (overlay) overlay.style.display = 'none';
    if (_mappingPromptResolve) { _mappingPromptResolve('applied'); _mappingPromptResolve = null; }
    await reRunWithOverrides();
}

function _mappingPromptGoFix() {
    const overlay = document.getElementById('mapping-prompt-overlay');
    if (overlay) overlay.style.display = 'none';
    const previewBtn = document.querySelector('.topbar-tab[onclick*="switchTab(\'raw\'"]');
    if (previewBtn && typeof switchTab === 'function') switchTab('raw', previewBtn);
    if (_mappingPromptResolve) { _mappingPromptResolve('goToPreview'); _mappingPromptResolve = null; }
}

function showUploadError(message, file) {
    const panel = document.getElementById('upload-error-panel');
    const detail = document.getElementById('upload-error-detail');
    if (!panel || !detail) { alert('Error parsing files:\n' + message); return; }
    const fileNote = file && file.name ? `File: ${file.name}\n` : '';
    detail.textContent = fileNote + message;
    panel.style.display = 'flex';
    panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
function hideUploadError() {
    const panel = document.getElementById('upload-error-panel');
    if (panel) panel.style.display = 'none';
}

function showProg(show, msg, pct) {
    const bar   = document.getElementById('progress-bar');
    const label = document.getElementById('progress-label');
    const fill  = document.getElementById('progress-fill');
    const btn   = document.getElementById('process-btn');
    if (!bar || !label || !fill) return;

    if (show) {
        // Activate — use class toggle so CSS transition plays
        bar.classList.add('active');
        label.classList.add('active');
        fill.style.width = (pct || 0) + '%';
        label.textContent = msg || '';

        // Disable the Run button while processing
        if (btn) { btn.disabled = true; btn.style.opacity = '0.6'; btn.style.cursor = 'not-allowed'; }

        // Scroll progress bar into view so it's always visible
        bar.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
        // Deactivate — fill to 100% briefly, then hide
        fill.style.width = '100%';
        setTimeout(() => {
            bar.classList.remove('active');
            label.classList.remove('active');
            fill.style.width = '0%';
            label.textContent = '';
            if (btn) { btn.disabled = false; btn.style.opacity = ''; btn.style.cursor = ''; }
        }, 350);
    }
}

function checkReady() {
    const ready = supplierFiles.length > 0 && billingFiles.length > 0;
    document.getElementById('process-btn').classList.toggle('ready', ready);
    const label = document.getElementById('progress-label');
    const bar   = document.getElementById('progress-bar');
    if (!label || !bar) return;
    if (!bar.classList.contains('active')) {
        // Show a hint in the label area when files are ready (or not)
        if (ready) {
            label.textContent = '✓ Ready — click Run Reconciliation';
            label.style.color = '#059669';
        } else if (supplierFiles.length === 0 && billingFiles.length === 0) {
            label.textContent = 'Add supplier and billing files above';
            label.style.color = '#9ca3af';
        } else if (supplierFiles.length === 0) {
            label.textContent = 'Add a supplier file to continue';
            label.style.color = '#9ca3af';
        } else {
            label.textContent = 'Add a billing file to continue';
            label.style.color = '#9ca3af';
        }
        // Show the label but not the bar
        label.classList.add('active');
    }
}

// Update the browser tab title based on which screen/tab is active
function setPageTitle(key) {
    const label = (typeof PAGE_TITLE_MAP !== 'undefined' && PAGE_TITLE_MAP[key]) || null;
    document.title = label ? `${label} — RxAuditwise` : 'RxAuditwise — Pharmacy Reconciliation v4.2';
}

// ── Date filter dropdown panel ──────────────────────────────────
function dfTogglePanel(e) {
    if (e) e.stopPropagation();
    const panel = document.getElementById('df-wrap');
    if (!panel) return;
    const willOpen = !panel.classList.contains('open');
    document.querySelectorAll('.df-panel.open, .tb-profile-menu.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.tb-expand-btn.force-expand, .tb-avatar-btn.force-expand').forEach(b => b.classList.remove('force-expand'));
    if (willOpen) {
        panel.classList.add('open');
        const btn = document.getElementById('tb-filter-btn');
        if (btn) btn.classList.add('force-expand');
    }
}
function dfClosePanel() {
    const panel = document.getElementById('df-wrap');
    if (panel) panel.classList.remove('open');
    const btn = document.getElementById('tb-filter-btn');
    if (btn) btn.classList.remove('force-expand');
}
document.addEventListener('click', function(e) {
    const panel = document.getElementById('df-wrap');
    const btn   = document.getElementById('tb-filter-btn');
    if (panel && panel.classList.contains('open') &&
        !panel.contains(e.target) && (!btn || !btn.contains(e.target))) {
        panel.classList.remove('open');
        if (btn) btn.classList.remove('force-expand');
    }
});
// Reflect whether a date filter is currently active as a dot on the filter icon
function dfUpdateFilterDot() {
    const dot = document.getElementById('tb-filter-dot');
    if (!dot) return;
    const active = (typeof _dateFilterFrom !== 'undefined' && (_dateFilterFrom || _dateFilterTo));
    dot.style.display = active ? '' : 'none';
}

// ── Info sidebar (About RxAuditwise) ────────────────────────────
// Captured once, immediately at load, before any contact info or override is
// ever injected — this is the TRUE static default, used only to restore the
// sidebar when a previously-applied custom override is cleared.
let _infoSidebarDefaultHtml = (function() {
    const el = document.getElementById('info-sidebar-body');
    return el ? el.innerHTML : null;
})();
// Tracks whether a custom full-sidebar override is currently applied — an
// explicit flag rather than comparing innerHTML, since the body's HTML always
// legitimately changes as contact info updates and can never be reliably
// diffed against a static snapshot to detect "override cleared" vs "contact
// info updated" (comparing HTML content conflated the two and caused contact
// info updates to be silently reverted).
let _infoOverrideActive = false;

// Upload screen's "Need a different format? Let us know" links — these are
// visible before any sidebar/panel opens, so they get a dedicated update
// call at page load rather than going through _tbFillContactCard's prefix
// pattern (they only need the email, not the full contact card).
async function _updateFormatHintMailto() {
    const contact = typeof licFetchContact === 'function' ? await licFetchContact() : {};
    const defaults = (typeof LIC_DEFAULT_CONTACT !== 'undefined') ? LIC_DEFAULT_CONTACT : {};
    const email = contact.adminEmail || defaults.adminEmail || 'info@rxauditwise.com';
    ['sup-fmt-mailto', 'bil-fmt-mailto'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.href = `mailto:${email}?subject=RxAuditwise%20-%20New%20file%20format%20request`;
    });
}

async function _tbFillContactCard(prefix) {
    if (typeof licFetchContact !== 'function') return;
    const contact = await licFetchContact();
    const defaults = (typeof LIC_DEFAULT_CONTACT !== 'undefined') ? LIC_DEFAULT_CONTACT : {};

    // Full sidebar override (admin-authored HTML) takes precedence over everything
    // else — handled FIRST so the contact fields set below always apply last and
    // are never subsequently wiped out by a body-level innerHTML replacement.
    const bodyEl = document.getElementById('info-sidebar-body');
    if (bodyEl && contact.aboutHtml) {
        bodyEl.innerHTML = contact.aboutHtml;
        _infoOverrideActive = true;
    } else if (bodyEl && _infoOverrideActive && _infoSidebarDefaultHtml !== null) {
        bodyEl.innerHTML = _infoSidebarDefaultHtml; // override was cleared — restore true default
        _infoOverrideActive = false;
    }

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set(prefix + '-admin-org',  contact.adminOrg   || defaults.adminOrg   || 'RxAuditwise');
    set(prefix + '-admin-name', contact.adminName  || defaults.adminName || 'RxAuditwise Support');
    set(prefix + '-admin-phone',contact.adminPhone || defaults.adminPhone|| '+1 (347) 870-0748');
    set(prefix + '-admin-address', contact.adminAddress || defaults.adminAddress || '2548 Matthews Ave, Bronx NY 10467');
    const emailEl = document.getElementById(prefix + '-admin-email');
    if (emailEl) {
        const em = contact.adminEmail || defaults.adminEmail || 'info@rxauditwise.com';
        emailEl.textContent = em;
        emailEl.href = 'mailto:' + em;
    }

    // Admin-configured "About RxAuditwise" text overrides just the default description
    // (only present in the info sidebar, and only relevant when no full override is
    // active — a full override already replaced this element entirely above).
    if (!contact.aboutHtml && contact.aboutText) {
        const aboutEl = document.getElementById('info-about-text');
        if (aboutEl) aboutEl.textContent = contact.aboutText;
    }
}

function infoSidebarOpen() {
    const sb = document.getElementById('info-sidebar');
    const ov = document.getElementById('info-sidebar-overlay');
    if (sb) sb.classList.add('open');
    if (ov) ov.style.display = 'block';
    _tbFillContactCard('info');
}
function infoSidebarClose() {
    const sb = document.getElementById('info-sidebar');
    const ov = document.getElementById('info-sidebar-overlay');
    if (sb) sb.classList.remove('open');
    if (ov) ov.style.display = 'none';
}

// ── Dynamic tab badge counts (rename-by-calculation) ────────────
// Tab badges were removed. Kept as no-ops so existing call sites
// (renderAll, resetApp) don't need to change.
function updateTabBadges() {}
function clearTabBadges() {}

// ── Manage tabs (show/hide) ─────────────────────────────────────
const TAB_VIS_STORE = 'rxaw_tab_visibility_v1';
const TB_TAB_META = [
    { key:'raw',        icon:'👁️', label:'Preview',   iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' },
    { key:'suppliers',  icon:'📦', label:'Suppliers',  iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>' },
    { key:'results',    icon:'📊', label:'Results',    iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>' },
    { key:'mfp',        icon:'📐', label:'MFP',        iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>' },
    { key:'final',      icon:'✅', label:'Final',      iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>' },
    { key:'bill',       icon:'💵', label:'Bill',       iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>' },
    { key:'dollar',     icon:'💲', label:'Dollar',     iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' },
    { key:'discarded',  icon:'🗑️', label:'Discarded',  iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' },
    { key:'notbilled',  icon:'⚠️', label:'Not Billed', iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' },
    { key:'issues',     icon:'🚨', label:'Issues',     iconSvg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' },
];

function tbGetTabVisibility() {
    try { return JSON.parse(localStorage.getItem(TAB_VIS_STORE) || '{}'); } catch(e) { return {}; }
}
function tbSaveTabVisibility(v) {
    try { localStorage.setItem(TAB_VIS_STORE, JSON.stringify(v)); } catch(e) {}
}

function tbApplyTabVisibility() {
    const vis = tbGetTabVisibility();
    TB_TAB_META.forEach(t => {
        const hidden = vis[t.key] === false;
        const el = document.querySelector('.topbar-tab[data-tabkey="' + t.key + '"]');
        if (el) el.classList.toggle('tb-hidden', hidden);
    });
    tbRenderTabsManageList();
}

function tbRenderTabsManageList() {
    const list = document.getElementById('tb-tabs-manage-list');
    if (!list) return;
    const vis = tbGetTabVisibility();
    list.innerHTML = TB_TAB_META.map(t => {
        const checked = vis[t.key] !== false;
        return `<label class="tb-tabs-manage-item">
            <input type="checkbox" ${checked ? 'checked' : ''} onchange="tbToggleTabVisibility('${t.key}', this.checked)">
            <span class="tb-tab-ico">${t.iconSvg}</span><span>${t.label}</span>
        </label>`;
    }).join('');
}

function tbToggleTabVisibility(key, visible) {
    const vis = tbGetTabVisibility();
    vis[key] = visible;
    tbSaveTabVisibility(vis);
    tbApplyTabVisibility();

    // If the currently active tab was just hidden, fall back to Results
    const activeTab = document.querySelector('.topbar-tab.active');
    if (!visible && activeTab && activeTab.getAttribute('data-tabkey') === key) {
        const resultsTab = document.querySelector('.topbar-tab[data-tabkey="results"]');
        if (resultsTab && typeof switchTab === 'function') switchTab('results', resultsTab);
    }
}

function tbResetTabVisibility() {
    tbSaveTabVisibility({});
    tbApplyTabVisibility();
}

function tbTabsManageToggle(e) {
    if (e) e.stopPropagation();
    const panel = document.getElementById('tb-tabs-manage-panel');
    if (!panel) return;
    const willOpen = !panel.classList.contains('open');
    document.querySelectorAll('.tb-tabs-manage-panel.open, .df-panel.open, .tb-profile-menu.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.tb-expand-btn.force-expand, .tb-avatar-btn.force-expand').forEach(b => b.classList.remove('force-expand'));
    if (willOpen) {
        tbRenderTabsManageList(); panel.classList.add('open');
        const btn = document.getElementById('tb-tabs-manage-btn');
        if (btn) btn.classList.add('force-expand');
    }
}
document.addEventListener('click', function(e) {
    const panel = document.getElementById('tb-tabs-manage-panel');
    const btn   = document.getElementById('tb-tabs-manage-btn');
    if (panel && panel.classList.contains('open') &&
        !panel.contains(e.target) && (!btn || !btn.contains(e.target))) {
        panel.classList.remove('open');
        if (btn) btn.classList.remove('force-expand');
    }
});
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tbApplyTabVisibility);
} else {
    tbApplyTabVisibility();
}

// ── Account sidebar (My Account) ────────────────────────────────
function accountSidebarOpen() {
    const s = (typeof LIC_CURRENT_SESSION !== 'undefined' && LIC_CURRENT_SESSION) || {};
    const pharmacy = s.pharmacy || s.name || '—';
    const initials = String(pharmacy).replace(/[^A-Za-z0-9 ]/g,'').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase() || 'U';

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('acct-avatar', initials);
    set('acct-pharmacy', pharmacy);
    set('acct-contact', s.name || '—');

    const pill = document.getElementById('acct-status-pill');
    if (pill) {
        let daysLeft = null;
        if (s.endDate) {
            const end = new Date(s.endDate);
            if (!isNaN(end)) daysLeft = Math.ceil((end - new Date()) / 86400000);
        }
        pill.classList.remove('inactive','expiring');
        if (s.active === false) {
            pill.textContent = 'Inactive'; pill.classList.add('inactive');
        } else if (daysLeft !== null && daysLeft < 0) {
            pill.textContent = 'Expired'; pill.classList.add('inactive');
        } else if (daysLeft !== null && daysLeft <= 14) {
            pill.textContent = `Active — expires in ${daysLeft}d`; pill.classList.add('expiring');
        } else {
            pill.textContent = 'Active';
        }
    }
    set('acct-expiry', s.endDate ? (typeof licFmtDate === 'function' ? licFmtDate(s.endDate) : s.endDate) : '—');

    const sb = document.getElementById('account-sidebar');
    const ov = document.getElementById('account-sidebar-overlay');
    if (typeof infoSidebarClose === 'function') infoSidebarClose();
    if (sb) sb.classList.add('open');
    if (ov) ov.style.display = 'block';
    _tbFillContactCard('acct');
}
function accountSidebarClose() {
    const sb = document.getElementById('account-sidebar');
    const ov = document.getElementById('account-sidebar-overlay');
    if (sb) sb.classList.remove('open');
    if (ov) ov.style.display = 'none';
}

// ── Settings sidebar ─────────────────────────────────────────────
const DEFAULT_TAB_STORE = 'rxaw_default_tab_v1';
function tbGetDefaultTab() {
    try { return localStorage.getItem(DEFAULT_TAB_STORE) || 'results'; } catch(e) { return 'results'; }
}
function tbSaveDefaultTab(key) {
    try { localStorage.setItem(DEFAULT_TAB_STORE, key); } catch(e) {}
}
function _tbPopulateDefaultTabSelect() {
    const sel = document.getElementById('settings-default-tab');
    if (!sel || typeof TB_TAB_META === 'undefined') return;
    const current = tbGetDefaultTab();
    sel.innerHTML = TB_TAB_META.map(t =>
        `<option value="${t.key}" ${t.key === current ? 'selected' : ''}>${t.icon} ${t.label}</option>`
    ).join('');
}
// Switch to the user's preferred default tab after reconciliation (called from showApp)
function tbApplyDefaultTab() {
    const key = tbGetDefaultTab();
    if (!key || key === 'results') return;
    const btn = document.querySelector('.topbar-tab[data-tabkey="' + key + '"]');
    if (btn && !btn.classList.contains('tb-hidden') && typeof switchTab === 'function') {
        switchTab(key, btn);
    }
}
function settingsSidebarOpen() {
    const sb = document.getElementById('settings-sidebar');
    const ov = document.getElementById('settings-sidebar-overlay');
    if (typeof infoSidebarClose === 'function') infoSidebarClose();
    if (typeof accountSidebarClose === 'function') accountSidebarClose();
    if (sb) sb.classList.add('open');
    if (ov) ov.style.display = 'block';
    _tbPopulateDefaultTabSelect();
    const darkToggle = document.getElementById('dark-mode-toggle');
    if (darkToggle) darkToggle.checked = document.documentElement.getAttribute('data-theme') === 'dark';
}
function settingsSidebarClose() {
    const sb = document.getElementById('settings-sidebar');
    const ov = document.getElementById('settings-sidebar-overlay');
    if (sb) sb.classList.remove('open');
    if (ov) ov.style.display = 'none';
}

// ── Dark chrome mode ─────────────────────────────────────────────
function tbToggleDarkMode(enabled) {
    document.documentElement.setAttribute('data-theme', enabled ? 'dark' : 'light');
    try { localStorage.setItem('rxaw_dark_mode', enabled ? '1' : '0'); } catch(e) {}
}

// ── Help Center ──────────────────────────────────────────────────
function helpCenterOpen() {
    const panel = document.getElementById('help-center');
    const ov = document.getElementById('help-center-overlay');
    document.querySelectorAll('.info-sidebar.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.info-sidebar-overlay').forEach(o => o.style.display = 'none');
    if (panel) panel.classList.add('open');
    if (ov) ov.style.display = 'block';
    if (typeof _tbFillContactCard === 'function') _tbFillContactCard('help');
    _helpApplyContentOverrides();
    setTimeout(() => { const inp = document.getElementById('help-search-input'); if (inp) inp.focus(); }, 200);
}
// Captured once per section, before any override is applied, so a cleared
// override can be restored within the same page session without a reload —
// same pattern used for the "About" sidebar's full-content override.
let _helpDefaultHtml = {};
const HELP_SECTION_MAP = {
    gettingStarted: 'help-getting-started',
    tabsGuide:      'help-tabs-guide',
    filtering:      'help-filtering',
    sorting:        'help-sorting',
    shortcuts:      'help-shortcuts',
};
async function _helpApplyContentOverrides() {
    if (typeof licFetchContact !== 'function') return;
    const contact = await licFetchContact();
    const hc = contact.helpContent || {};

    Object.entries(HELP_SECTION_MAP).forEach(([key, elId]) => {
        const el = document.getElementById(elId);
        if (!el) return;
        if (_helpDefaultHtml[elId] === undefined) _helpDefaultHtml[elId] = el.innerHTML;
        if (hc[key]) {
            el.innerHTML = hc[key];
        } else if (el.innerHTML !== _helpDefaultHtml[elId]) {
            el.innerHTML = _helpDefaultHtml[elId];
        }
    });

    // Contact note is additive (shown above the existing live contact card),
    // not a full-section replacement like the others.
    const noteHost = document.getElementById('help-contact');
    let noteEl = document.getElementById('help-contact-note-display');
    if (hc.contactNote) {
        if (!noteEl) {
            noteEl = document.createElement('div');
            noteEl.id = 'help-contact-note-display';
            noteEl.className = 'help-card';
            noteHost.insertBefore(noteEl, noteHost.querySelector('.help-contact-card'));
        }
        noteEl.textContent = hc.contactNote;
    } else if (noteEl) {
        noteEl.remove();
    }
}
function helpCenterClose() {
    const panel = document.getElementById('help-center');
    const ov = document.getElementById('help-center-overlay');
    if (panel) panel.classList.remove('open');
    if (ov) ov.style.display = 'none';
}
function helpShowSection(name, btn) {
    document.querySelectorAll('.help-nav-item').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.help-section').forEach(el => { el.classList.remove('active'); el.style.display = ''; });
    if (btn) btn.classList.add('active');
    const sec = document.getElementById('help-' + name);
    if (sec) sec.classList.add('active');
    const content = document.getElementById('help-content');
    if (content) content.scrollTop = 0;
    const searchInp = document.getElementById('help-search-input');
    if (searchInp && searchInp.value) searchInp.value = '';
    const noRes = document.getElementById('help-no-results');
    if (noRes) noRes.remove();
}
// Simple client-side search across all help sections — shows every section
// that contains a match (with matching text highlighted) and hides the rest,
// rather than trying to guess a single "best" section.
function helpSearch(query) {
    const q = query.trim().toLowerCase();
    const sections = document.querySelectorAll('.help-section');
    if (!q) {
        const activeNav = document.querySelector('.help-nav-item.active') || document.querySelector('.help-nav-item');
        sections.forEach(s => _helpClearHighlights(s));
        helpShowSection(activeNav ? activeNav.dataset.section : 'getting-started', activeNav);
        return;
    }
    let anyMatch = false;
    sections.forEach(s => {
        _helpClearHighlights(s);
        const text = s.textContent.toLowerCase();
        if (text.includes(q)) {
            s.style.display = '';
            s.classList.add('active');
            anyMatch = true;
            _helpHighlight(s, query);
        } else {
            s.style.display = 'none';
            s.classList.remove('active');
        }
    });
    document.querySelectorAll('.help-nav-item').forEach(el => el.classList.remove('active'));
    const content = document.getElementById('help-content');
    let noRes = document.getElementById('help-no-results');
    if (!anyMatch) {
        if (content && !noRes) {
            const div = document.createElement('div');
            div.id = 'help-no-results';
            div.className = 'help-no-results';
            div.textContent = `No help topics match "${query}".`;
            content.appendChild(div);
        }
    } else if (noRes) {
        noRes.remove();
    }
}
// Submits a question from the Help Center to the admin via email, using the
// same session token the main app already holds for authenticated API calls.
async function helpAskAdmin() {
    const inp = document.getElementById('help-question-input');
    const btn = document.getElementById('help-ask-btn');
    const statusEl = document.getElementById('help-ask-status');
    const question = (inp && inp.value || '').trim();
    if (!question) {
        if (statusEl) { statusEl.textContent = 'Please type a question first.'; statusEl.className = 'help-ask-status err'; }
        return;
    }
    const session = (typeof LIC_CURRENT_SESSION !== 'undefined' && LIC_CURRENT_SESSION) || null;
    if (!session || !session.token) {
        if (statusEl) { statusEl.textContent = 'Your session has expired — please refresh and sign in again.'; statusEl.className = 'help-ask-status err'; }
        return;
    }
    if (btn) { btn.disabled = true; btn.classList.add('loading'); }
    if (statusEl) { statusEl.textContent = ''; statusEl.className = 'help-ask-status'; }
    try {
        const r = await fetch(typeof LIC_API !== 'undefined' ? LIC_API : 'api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Auth-Token': session.token },
            body: JSON.stringify({ action: 'ask_admin_question', question })
        });
        const j = await r.json();
        if (j.ok) {
            if (statusEl) {
                let msg = 'Your question was received.';
                if (j.sentConfirmation) msg = "We've also emailed you a confirmation.";
                else if (j.sentToAdmin) msg = 'Your administrator has been notified by email.';
                statusEl.innerHTML = '<span class="ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></span> Sent! ' + msg;
                statusEl.className = 'help-ask-status ok';
            }
            if (inp) inp.value = '';
        } else {
            if (statusEl) { statusEl.textContent = j.error || 'Could not send your question. Please try again.'; statusEl.className = 'help-ask-status err'; }
        }
    } catch (e) {
        if (statusEl) { statusEl.textContent = 'Network error — please check your connection and try again.'; statusEl.className = 'help-ask-status err'; }
    } finally {
        if (btn) { btn.disabled = false; btn.classList.remove('loading'); }
    }
}

function _helpClearHighlights(root) {
    root.querySelectorAll('mark.help-hl').forEach(m => {
        const parent = m.parentNode;
        parent.replaceChild(document.createTextNode(m.textContent), m);
        parent.normalize();
    });
}
function _helpHighlight(root, query) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    const re = new RegExp('(' + query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig');
    nodes.forEach(node => {
        if (!re.test(node.nodeValue)) return;
        re.lastIndex = 0;
        const frag = document.createDocumentFragment();
        let lastIdx = 0, m;
        while ((m = re.exec(node.nodeValue))) {
            frag.appendChild(document.createTextNode(node.nodeValue.slice(lastIdx, m.index)));
            const mark = document.createElement('mark');
            mark.className = 'help-hl';
            mark.textContent = m[0];
            frag.appendChild(mark);
            lastIdx = m.index + m[0].length;
        }
        frag.appendChild(document.createTextNode(node.nodeValue.slice(lastIdx)));
        node.parentNode.replaceChild(frag, node);
    });
}

// ── Fullscreen toggle ────────────────────────────────────────────
function tbToggleFullscreen() {
    if (!document.fullscreenElement) {
        (document.documentElement.requestFullscreen && document.documentElement.requestFullscreen())?.catch(()=>{});
    } else {
        document.exitFullscreen && document.exitFullscreen().catch(()=>{});
    }
}
function _tbUpdateFullscreenIcon() {
    const icon = document.getElementById('tb-fullscreen-icon');
    const btn  = document.getElementById('tb-fullscreen-btn');
    if (!icon || !btn) return;
    if (document.fullscreenElement) {
        icon.innerHTML = '<path d="M9 3H6a3 3 0 0 0-3 3v3M15 3h3a3 3 0 0 1 3 3v3M9 21H6a3 3 0 0 1-3-3v-3M15 21h3a3 3 0 0 0 3-3v-3" stroke-linecap="round" stroke-linejoin="round" transform="scale(0.8) translate(2.5,2.5)"/><path d="M9 9L4 4M15 9l5-5M9 15l-5 5M15 15l5 5" stroke-linecap="round"/>';
        btn.title = 'Exit fullscreen';
    } else {
        icon.innerHTML = '<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3" stroke-linecap="round" stroke-linejoin="round"/>';
        btn.title = 'Enter fullscreen';
    }
}
document.addEventListener('fullscreenchange', _tbUpdateFullscreenIcon);

function showApp() {
    document.getElementById('upload-screen').style.display = 'none';
    document.getElementById('app-screen').style.display = 'flex';
    document.getElementById('tab-results').style.display = 'flex';
    setPageTitle('results');
    // Show the date filter bar
    if (typeof dfShow === 'function') dfShow();
    if (typeof tbApplyDefaultTab === 'function') tbApplyDefaultTab();
}




function resetApp() {
    purchaseMap = {}; supTransactions = {}; supFileTotals = {}; billingRows = []; billingPkgMap = {}; billingPkgCounter = {};
    ndcGroups = []; allRows = []; filteredRows = []; rawPreviewData = []; parseStats = {};
    supplierFiles = []; billingFiles = [];
    activeFilter = 'all'; sortCol = 'description'; sortDir = 1;
    mfpActiveYear = 'all'; mfpActiveStatus = 'all';
    supSearch = ''; supSortCol = 'desc'; supSortDir = 1;
    finalSearch = ''; finalSortCol = 'description'; finalSortDir = 1; finalStatusFilter = 'all';
    nbSearch = ''; nbSortCol = 'desc'; nbSortDir = 1;
    billSearch = ''; billSortCol = 'totalRxQty'; billSortDir = -1;
    discSearch = ''; discSortCol = 'desc'; discSortDir = 1;
    issSearch = ''; issSortCol = 'shortAmt'; issSortDir = 1;
    rawSearchTerms = {}; rawCollapsed = {}; rawGlobalSearch = ''; globalNDCSearch = '';
    // Reset date filter
    if (typeof dfClear === 'function') dfClear();
    const dfWrap = document.getElementById('df-wrap');
    if (dfWrap) dfWrap.style.display = 'none';
    const gsi = document.getElementById('global-ndc-search');
    if (gsi) gsi.value = '';
    ['supplier', 'billing'].forEach(k => {
        document.getElementById('card-' + k).classList.remove('loaded');
        document.getElementById('fn-' + k).innerHTML = '';
        document.getElementById('inp-' + k).value = '';
    });
    // Reset format selectors
    window.supFmt = 'auto'; window.bilFmt = 'auto';
    ['sup-fmt-grid','bil-fmt-grid'].forEach(gridId => {
        document.querySelectorAll('#' + gridId + ' .fmt-btn').forEach(b => b.classList.remove('active'));
        const autoBtn = document.querySelector('#' + gridId + ' .fmt-btn[data-fmt="auto"]');
        if (autoBtn) autoBtn.classList.add('active');
    });
    document.getElementById('app-screen').style.display = 'none';
    document.getElementById('upload-screen').style.display = 'flex';
    setPageTitle('upload');
    if (typeof clearTabBadges === 'function') clearTabBadges();
    checkReady();
}

// IMPROVEMENT 12: Global NDC search — propagates to all tabs
function _doGlobalNDCSearchImmediate(val) {
    globalNDCSearch = val.trim();
    supSearch = globalNDCSearch;
    finalSearch = globalNDCSearch;
    billSearch = globalNDCSearch;
    discSearch = globalNDCSearch;
    issSearch = globalNDCSearch;
    nbSearch = globalNDCSearch;
    if (typeof dolSearch !== 'undefined') dolSearch = globalNDCSearch;
    ['mfp-search','raw-global-search','sup-search-inp','final-search-inp',
     'bill-search-inp','disc-search-inp','iss-search-inp','nb-search-inp','dol-search-inp'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = globalNDCSearch;
    });
    applyFilters();
    if (typeof renderMFP === 'function') renderMFP();
}
// Debounced version — fires 200ms after user stops typing
const doGlobalNDCSearch = debounce(_doGlobalNDCSearchImmediate, 200);

// BIN chips display — show first 2 BINs then "+N more" tooltip
function formatBinChips(binStr, highlight) {
    if (!binStr) return '';
    const bins = binStr.split(',').map(b => b.trim()).filter(Boolean);
    if (!bins.length) return '';
    const MAX_SHOW = 2;
    const shown = bins.slice(0, MAX_SHOW);
    const rest = bins.length - MAX_SHOW;
    const chipStyle = highlight
        ? 'background:#fef08a;color:#78350f;padding:1px 5px;border-radius:3px;margin-right:2px;font-size:10.5px;font-weight:700;white-space:nowrap'
        : 'background:#f1f5f9;color:#475569;padding:1px 5px;border-radius:3px;margin-right:2px;font-size:10.5px;white-space:nowrap';
    let html = shown.map(b => `<span style="${chipStyle}">${escHtml(b)}</span>`).join('');
    if (rest > 0) html += `<span style="font-size:10px;color:var(--primary);cursor:default" title="${escHtml(bins.join(', '))}">+${rest}</span>`;
    return html;
}

// PKG source badge helper
function pkgSrcBadge(src) {    if (!src || src === 'supplier') return '';
    if (src === 'derived') return '<span class="pkg-src-badge derived" title="Pkg size derived from DoseExt÷InvQty (McKesson)">÷</span>';
    if (src === 'billing') return '<span class="pkg-src-badge billing" title="Pkg size from billing file fallback">B</span>';
    if (src === 'none') return '<span class="pkg-src-badge none" title="No pkg size found — using raw package count">?</span>';
    return '';
}

// ── Global keyboard/click handlers ──
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        const sel = window.getSelection();
        if (sel && sel.toString().trim()) return;
        const a = document.activeElement;
        if (a && a.tagName === 'TD') navigator.clipboard.writeText(a.textContent.trim()).catch(() => {});
    }
});
document.addEventListener('click', e => {
    const td = e.target.closest('td');
    if (td) {
        document.querySelectorAll('td.focused').forEach(c => c.classList.remove('focused'));
        td.classList.add('focused');
        td.tabIndex = 0;
        td.focus();
    }
});

// ══════════════════════════════════════
//  ROW + COLUMN HOVER HIGHLIGHT
//  Attaches to any <table> with class .hl-table
//  or the specific table IDs we know about.
//  Uses event delegation — one handler per table.
// ══════════════════════════════════════
function attachColHover(table) {
    if (!table || table._colHoverAttached) return;
    table._colHoverAttached = true;

    let _lastColIdx = -1;
    let _lastNdc = null;

    // NDC per row is cached on the <tr> itself the first time it's read, so
    // repeated hovers over the same table don't re-run a child-element query
    // for every row on every mouse movement.
    function getRowNdc(tr) {
        if (tr.dataset.ndcCache !== undefined) return tr.dataset.ndcCache || null;
        const el = tr.querySelector('.ndc-plain, .sup-ndc, .final-ndc, .nb-ndc, .disc-ndc, .iss-ndc');
        const ndc = el ? el.textContent.trim() : '';
        tr.dataset.ndcCache = ndc;
        return ndc || null;
    }

    function clearHighlights() {
        table.querySelectorAll('.col-hov').forEach(el => el.classList.remove('col-hov'));
        table.querySelectorAll('.ndc-group-hov').forEach(el => el.classList.remove('ndc-group-hov'));
    }

    table.addEventListener('mouseover', function(e) {
        const td = e.target.closest('td, th');
        if (!td) return;
        const tr = td.closest('tr');
        const colIdx = td.cellIndex;
        const ndc = tr ? getRowNdc(tr) : null;
        if (colIdx === _lastColIdx && ndc === _lastNdc) return;
        _lastColIdx = colIdx; _lastNdc = ndc;

        clearHighlights();

        // Highlight ONLY the column header, not every cell in the column
        const thead = table.querySelector('thead');
        if (thead) {
            thead.querySelectorAll(`tr th:nth-child(${colIdx + 1})`).forEach(el => el.classList.add('col-hov'));
        }

        // Highlight every row sharing this cell's NDC
        if (ndc) {
            table.querySelectorAll('tbody tr').forEach(rowEl => {
                if (getRowNdc(rowEl) === ndc) rowEl.classList.add('ndc-group-hov');
            });
        }
    });

    table.addEventListener('mouseleave', function() {
        _lastColIdx = -1; _lastNdc = null;
        clearHighlights();
    });
}

// Attach to all known tables after any render
// ── Per-column sort menu ─────────────────────────────────────────
// Clicking the small ▾ caret next to a sortable column header (added by
// tabColHeader) opens this small floating menu with explicit options —
// "A → Z" / "Z → A" for text columns, "Highest → Lowest" / "Lowest → Highest"
// for numeric ones — rather than relying on the less-discoverable toggle
// behavior of clicking the header itself.
let _colMenuEl = null;
function _closeColHeaderMenu() {
    if (_colMenuEl) { _colMenuEl.remove(); _colMenuEl = null; }
    document.removeEventListener('click', _closeColHeaderMenu, true);
}
// Shared status-priority ranking — lets any tab's status column be sorted as
// "OK first" / "Over first" / "Short first" instead of just alphabetically.
// Unknown/other status values always sort to the end.
const STATUS_ORDERS = {
    ok:    ['ok', 'over', 'short'],
    over:  ['over', 'short', 'ok'],
    short: ['short', 'over', 'ok'],
};
function statusRank(status, orderKey) {
    const order = STATUS_ORDERS[orderKey] || STATUS_ORDERS.ok;
    const idx = order.indexOf(status);
    return idx === -1 ? 99 : idx;
}

function colHeaderShowMenu(event, presetFnName, sortKey, colType) {
    _closeColHeaderMenu();
    const rect = event.target.getBoundingClientRect();
    const menu = document.createElement('div');
    menu.className = 'col-filter-menu';

    const svgUp = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>';
    const svgDown = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>';
    const svgAZ = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="4" y2="18"/><polyline points="4 6 2 9"/><polyline points="4 6 6 9"/><line x1="10" y1="4" x2="10" y2="20"/><line x1="16" y1="4" x2="20" y2="20"/><line x1="17" y1="15" x2="19.5" y2="15"/></svg>';
    const svgZA = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="4" y2="18"/><polyline points="4 18 2 15"/><polyline points="4 18 6 15"/><line x1="10" y1="4" x2="10" y2="20"/><line x1="16" y1="4" x2="20" y2="20"/><line x1="17" y1="15" x2="19.5" y2="15"/></svg>';

    const svgOk = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
    const svgOver = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"/></svg>';
    const svgShort = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';

    let opts;
    if (colType === 'status') {
        opts = [[svgOk, 'OK First', 'ok'], [svgOver, 'Over First', 'over'], [svgShort, 'Short First', 'short']];
    } else if (colType === 'num') {
        opts = [[svgUp, 'Highest → Lowest', -1], [svgDown, 'Lowest → Highest', 1]];
    } else {
        opts = [[svgAZ, 'A → Z', 1], [svgZA, 'Z → A', -1]];
    }
    menu.innerHTML = opts.map(([icon, label, dir]) =>
        `<button onclick="event.stopPropagation();${presetFnName}('${sortKey}',${typeof dir === 'string' ? `'${dir}'` : dir});_closeColHeaderMenu();"><span class="col-filter-menu-icon">${icon}</span>${label}</button>`
    ).join('');

    document.body.appendChild(menu);
    _colMenuEl = menu;

    // Position after appending so we can measure the menu's actual width/height
    // and clamp it to stay fully within the viewport (was previously able to
    // render partially off the right/bottom edge).
    const menuRect = menu.getBoundingClientRect();
    let left = rect.left;
    if (left + menuRect.width > window.innerWidth - 8) left = window.innerWidth - menuRect.width - 8;
    if (left < 8) left = 8;
    let top = rect.bottom + 4;
    if (top + menuRect.height > window.innerHeight - 8) top = rect.top - menuRect.height - 4;
    menu.style.left = Math.round(left) + 'px';
    menu.style.top  = Math.round(top) + 'px';

    // Deferred so the click that opened the menu doesn't immediately close it
    setTimeout(() => document.addEventListener('click', _closeColHeaderMenu, true), 0);
}

function attachAllColHovers() {
    const selectors = [
        '#main-table', '.sup-table', '.final-table', '.iss-table',
        '.nb-table', '.bill-table', '.disc-table', '.dol-table', '.mfp-table',
        '.raw-table', '.hl-table'
    ];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(t => attachColHover(t));
    });
}

// First-time discoverability nudge for the per-column sort/filter caret —
// shown once ever (localStorage-gated), disappears permanently after the
// user's first interaction with any caret, or after ~7s if ignored.
let _sortHintDone = false;
function maybeShowSortHint() {
    if (_sortHintDone) return;
    try { if (localStorage.getItem('rxaw_sort_hint_seen')) { _sortHintDone = true; return; } } catch(e) {}
    const caret = document.querySelector('.col-filter-caret');
    if (!caret) return; // no sortable column visible yet — try again on next render
    _sortHintDone = true;
    caret.classList.add('pulse-hint');

    const bubble = document.createElement('div');
    bubble.className = 'sort-hint-bubble';
    bubble.textContent = 'New here? Click this icon to sort or filter this column.';
    document.body.appendChild(bubble);
    const rect = caret.getBoundingClientRect();
    bubble.style.left = Math.max(8, Math.round(rect.left - 20)) + 'px';
    bubble.style.top = Math.round(rect.bottom + 10) + 'px';

    function dismiss() {
        try { localStorage.setItem('rxaw_sort_hint_seen', '1'); } catch(e) {}
        caret.classList.remove('pulse-hint');
        bubble.remove();
        document.removeEventListener('click', onAnyCaretClick, true);
    }
    function onAnyCaretClick(e) {
        if (e.target.closest && e.target.closest('.col-filter-caret')) dismiss();
    }
    document.addEventListener('click', onAnyCaretClick, true);
    setTimeout(dismiss, 7000);
}

// Run after DOM updates — use MutationObserver on tab content areas
(function() {
    const observer = new MutationObserver(function() {
        attachAllColHovers();
        maybeShowSortHint();
    });
    document.addEventListener('DOMContentLoaded', function() {
        const targets = ['#tab-results','#tab-suppliers','#tab-final','#tab-bill',
                         '#tab-discarded','#tab-issues','#tab-notbilled','#tab-dollar','#tab-mfp','#tab-raw'];
        targets.forEach(sel => {
            const el = document.querySelector(sel);
            if (el) observer.observe(el, { childList: true, subtree: true });
        });
        // Also observe app-screen for tables added dynamically
        const app = document.getElementById('app-screen');
        if (app) observer.observe(app, { childList: true, subtree: false });
        attachAllColHovers();
        maybeShowSortHint();
    });
})();
