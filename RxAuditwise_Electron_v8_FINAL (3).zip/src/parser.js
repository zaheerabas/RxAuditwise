// ════════════════════════════════════
//  FILE INPUT LISTENERS
// ════════════════════════════════════

// File input listeners are in index.html (drag-drop handlers)

// ════════════════════════════════════
//  PROCESS ENTRY POINT
// ════════════════════════════════════

async function processFiles() {
    if (typeof hideUploadError === 'function') hideUploadError();
    showProg(true, 'Starting…', 3);
    await tick();
    try {
        if (typeof licCheckFiles === 'function') {
            const lic = await licCheckFiles(supplierFiles, billingFiles[0] || null);
            if (!lic.allowed) { showProg(false, '', 0); licShowGate(lic); return; }
        }
    } catch (licErr) {
        console.warn('License check skipped:', licErr.message);
    }

    purchaseMap = {}; supTransactions = {}; supFileTotals = {};
    billingRows = []; billingPkgMap = {}; billingPkgCounter = {}; rawPreviewData = []; parseStats = {};

    const totalFiles = billingFiles.length + supplierFiles.length;
    let done = 0;

    try {
        // ── Billing files ──
        for (const bf of billingFiles) {
            const pct = 8 + Math.round((done / Math.max(totalFiles, 1)) * 52);
            const shortName = bf.name.length > 30 ? bf.name.slice(0, 27) + '…' : bf.name;
            showProg(true, `Reading billing: ${shortName}`, pct);
            await tick();
            await readBilling(bf);
            done++;
        }

        // ── Supplier files ──
        for (const f of supplierFiles) {
            const pct = 8 + Math.round((done / Math.max(totalFiles, 1)) * 52);
            const shortName = f.name.length > 30 ? f.name.slice(0, 27) + '…' : f.name;
            showProg(true, `Reading supplier: ${shortName}`, pct);
            await tick();
            await readSupplier(f);
            done++;
        }

        // ── Check for unmapped NDC before reconciling ──
        // NDC is required — a file with no NDC column detected means every
        // row in it gets silently skipped. Description is not checked here;
        // if it's not detected, rows just show "No description" as before.
        const problemFiles = rawPreviewData
            .map(fd => ({ fd, missingNdc: !fd.mappingIdx || fd.mappingIdx.ndc == null || fd.mappingIdx.ndc < 0 }))
            .filter(p => p.missingNdc);

        if (problemFiles.length && typeof showMappingPrompt === 'function') {
            showProg(false, '', 0);
            const outcome = await showMappingPrompt(problemFiles);
            // 'applied'     — reRunWithOverrides() already re-parsed, reconciled,
            //                 rendered every tab, and shown the app. Nothing left to do.
            // 'goToPreview' — user is now looking at Preview to sort it out manually.
            // 'skip'        — fall through and reconcile with whatever's already parsed.
            if (outcome === 'applied' || outcome === 'goToPreview') return;
        }

        showProg(true, 'Running reconciliation…', 68);
        await tick();
        reconcile();

        showProg(true, 'Building results…', 85);
        await tick();
        renderAll();

        showProg(true, 'Done! Loading results…', 100);
        await tick();
        showApp();
        showProg(false, '', 100);
    } catch (err) {
        showUploadError(err.message, done < billingFiles.length ? billingFiles[done] : supplierFiles[done - billingFiles.length]);
        showProg(false, '', 0);
        console.error(err);
    }
}

// ════════════════════════════════════
//  HELPERS
// ════════════════════════════════════

function isDummyNDC(ndc) {
    if (!ndc) return true;
    const d = ndc.replace(/\D/g, '');
    return !d || /^9+$/.test(d) || /^0+$/.test(d);
}

function detectDateRange(dateStrings) {
    const dates = [];
    for (let raw of dateStrings) {
        if (!raw) continue;
        // Strip ="..." wrappers (RxReportPlus)
        let s = String(raw).replace(/^=?"?|"?$/g, '').trim();
        if (s.length < 5) continue;
        let d = null;
        // ISO full date or YYYY-MM (Invoice Month)
        if (/^\d{4}-\d{2}-\d{2}/.test(s))          d = new Date(s.slice(0, 10));
        else if (/^\d{4}-\d{2}$/.test(s))           d = new Date(s + '-01');
        else if (/^\d{1,2}\/\d{1,2}\/\d{2,4}/.test(s)) d = new Date(s.split(' ')[0]);
        else                                              d = new Date(s);
        if (d && !isNaN(d.getTime()) && d.getFullYear() > 2000) dates.push(d);
    }
    if (!dates.length) return null;
    const min = new Date(Math.min(...dates.map(d => d.getTime())));
    const max = new Date(Math.max(...dates.map(d => d.getTime())));
    const fmt = d => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    return { min, max, label: min.getTime() === max.getTime() ? fmt(min) : `${fmt(min)} – ${fmt(max)}` };
}

// ── Match ALL columns matching a pattern (for multi-cost-column files) ──────
// Returns array of column indices that match (e.g. "Mar 2026 Cost", "Apr 2026 Cost")
function matchAllCols(hdrs, field) {
    const pats = PATTERNS[field] || [];
    const indices = [];
    hdrs.forEach((h, i) => {
        for (const p of pats) { if (p.test(h)) { indices.push(i); break; } }
    });
    return indices;
}

// ── Strip dollar signs, commas, spaces; handle "$ 26.70" format ──────────────
function parseDollar(s) {
    if (!s && s !== 0) return 0;
    const cleaned = String(s).replace(/[^\d.\-]/g, '');
    return parseFloat(cleaned) || 0;
}

// ── Strip ="..." Excel-text wrapping and quotes ──────────────
function cleanVal(v) {
    if (v == null) return '';
    let s = String(v);
    // Remove Excel ="..." wrapping that appears in exported CSVs
    s = s.replace(/^="?(.*?)"?$/, '$1').trim();
    // Remove surrounding quotes
    s = s.replace(/^"+|"+$/g, '').trim();
    return s;
}

// ── Find the real header row in XLSX data ──
// Returns the index of the row that best looks like a column-header row
function findXlsxHeaderRow(data, maxScan) {
    const scan = Math.min(maxScan || 12, data.length);
    // Priority 1: a row that CONTAINS "NDC" (the most reliable signal)
    for (let i = 0; i < scan; i++) {
        const row = (data[i] || []).map(v => String(v == null ? '' : v).trim());
        if (row.some(v => /^ndc$/i.test(v) || /^ndc\/upc/i.test(v))) return i;
    }
    // Priority 2: a row with other recognizable column names
    for (let i = 0; i < scan; i++) {
        const row = (data[i] || []).map(v => String(v == null ? '' : v).trim().toLowerCase());
        const joined = row.join(' ');
        const nonEmpty = row.filter(Boolean).length;
        if (nonEmpty >= 2 && (
            /invoice.?quantity/.test(joined) ||
            /shipped.?qty/.test(joined) ||
            /transaction.?type/.test(joined) ||
            /product.?desc/.test(joined) ||
            /particulars/.test(joined) ||
            /\bdescription\b/.test(joined)
        )) return i;
    }
    return 0;
}

// ── Build merged headers for multi-row header files (e.g. ABC Template) ──
// ABC Template: row 5 = "Shipped Qty | Cost | Cost | Qty | Qty"
//               row 6 = "Product Description | NDC | 1611(num) | Unit Size Qty | ..."
// We merge: prefer text strings over numeric values, later rows win for text.
function buildXlsxHeaders(data, hi) {
    // Look at rows from (hi-2) to hi to collect label candidates
    const candidateIdxs = [];
    for (let k = Math.max(0, hi - 2); k <= hi; k++) candidateIdxs.push(k);
    const numCols = Math.max(...candidateIdxs.map(k => (data[k] || []).length), 1);
    const merged = [];
    for (let col = 0; col < numCols; col++) {
        let textVal = '';   // best text label found
        for (const k of candidateIdxs) {
            const v = data[k] ? data[k][col] : undefined;
            if (v == null || v === '') continue;
            const s = cleanVal(String(v));
            if (!s) continue;
            // Skip if purely numeric (these are totals/sums in summary rows)
            const isNum = /^[\d,.\s\-()]+$/.test(s);
            if (!isNum) textVal = s; // later rows overwrite earlier for text values
        }
        merged.push(textVal);
    }
    return merged;
}

// ── Find the real header row in CSV lines ──────────────────────
function findCsvHeaderRow(lines, maxScan) {
    const scan = Math.min(maxScan || 12, lines.length);
    // Priority 1: row containing "NDC" as an exact column
    for (let i = 0; i < scan; i++) {
        const line = lines[i] || '';
        if (/^sep=/i.test(line.trim()) || !line.trim()) continue;
        const cols = csvLine(line).map(c => cleanVal(c));
        if (cols.some(c => /^ndc$/i.test(c) || /^ndc\/upc/i.test(c))) return i;
    }
    // Priority 2: other recognizable column names
    for (let i = 0; i < scan; i++) {
        const line = lines[i] || '';
        if (/^sep=/i.test(line.trim()) || !line.trim()) continue;
        const cols = csvLine(line).map(c => cleanVal(c).toLowerCase());
        const joined = cols.join(' ');
        if (cols.filter(Boolean).length >= 2 && (
            /invoice.?quantity/.test(joined) ||
            /shipped.?qty/.test(joined) ||
            /transaction.?type/.test(joined) ||
            /product.?desc/.test(joined) ||
            /particulars/.test(joined) ||
            /\bdescription\b/.test(joined)
        )) return i;
    }
    return 0;
}

// ── Build merged headers for multi-row CSV headers ──────────────
function buildCsvHeaders(lines, hi, sep) {
    const candidateIdxs = [];
    for (let k = Math.max(0, hi - 2); k <= hi; k++) {
        const line = lines[k] || '';
        if (/^sep=/i.test(line.trim()) || !line.trim()) continue;
        candidateIdxs.push(k);
    }
    if (!candidateIdxs.length) candidateIdxs.push(hi);
    const parsed = candidateIdxs.map(k => {
        const line = lines[k] || '';
        return sep === "\t" ? line.split("\t").map(cleanVal) : csvLine(line).map(cleanVal);
    });
    const numCols = Math.max(...parsed.map(r => r.length), 1);
    const merged = [];
    for (let col = 0; col < numCols; col++) {
        let textVal = '';
        for (const r of parsed) {
            const s = r[col] || '';
            if (!s) continue;
            const isNum = /^[\d,\.\s\-()]+$/.test(s);
            if (!isNum) textVal = s;
        }
        merged.push(textVal);
    }
    return merged;
}

// ════════════════════════════════════
//  SUPPLIER TRANSACTION TRACKER
// ════════════════════════════════════

function addSupTransaction(ndc, fileName, qty, size, pkgSrc, date, extPrice) {
    if (!ndc || ndc.length < 9) return;
    let sz = parseSize(size);
    if (sz <= 1 && billingPkgMap[ndc] > 0) sz = billingPkgMap[ndc];
    const total = qty * sz;
    if (!supTransactions[ndc]) supTransactions[ndc] = [];
    supTransactions[ndc].push({ file: fileName, qty, sz, total, pkgSrc: pkgSrc || 'supplier', date: date || '', extPrice: extPrice || 0 });
    if (!supFileTotals[ndc]) supFileTotals[ndc] = {};
    if (!supFileTotals[ndc][fileName]) supFileTotals[ndc][fileName] = 0;
    supFileTotals[ndc][fileName] += total;
}

// ════════════════════════════════════
//  READ SUPPLIER FILE
// ════════════════════════════════════

async function readSupplier(file) {
    // Honour user format selection (window.supFmt), fall back to extension
    const userFmt = (window.supFmt || 'auto');
    const ext = userFmt === 'auto' ? file.name.split('.').pop().toLowerCase() : userFmt;
    const MAX_PREVIEW = 99999; // store all rows so preview search works across entire file
    const stats = { rows: 0, skipped: 0, returns: 0, dummyNDC: 0, zeroDoseExt: 0, dateRange: null, type: 'supplier' };

    if (ext === 'csv' || ext === 'tsv') {
        const sep = ext === 'tsv' ? '\t' : ',';
        const text = await file.text();
        const lines = text.split('\n').map(l => l.replace(/\r/g, ''));

        // Auto-detect real header row + merge multi-row headers (e.g. ABC Template)
        const hi = findCsvHeaderRow(lines, 12);
        const hdrs = buildCsvHeaders(lines, hi, sep);

        // ── Auto-detect columns ──
        const _autoNdcI  = matchCol(hdrs, 'ndc');
        const _autoDescI = matchCol(hdrs, 'description');
        const strongI    = matchCol(hdrs, 'drugStrong');
        const formI      = matchCol(hdrs, 'drugForm');
        const _autoQtyI  = matchCol(hdrs, 'qty');
        const _autoSzI   = matchCol(hdrs, 'size');
        const doseQtyExtI= matchCol(hdrs, 'doseQtyExt');
        const _autoDateI = matchCol(hdrs, 'invoiceDate');
        const _autoExtPI = matchCol(hdrs, 'extPrice');
        const unitPriceI = matchCol(hdrs, 'unitPrice');
        const sourceI    = matchCol(hdrs, 'sourceName');
        const orderTypeI = matchCol(hdrs, 'orderType');
        // ── Apply user column overrides (if any) ──
        const _ovSC    = (typeof columnOverrides !== 'undefined') ? (columnOverrides[file.name] || {}) : {};
        const _ndcI    = _ovSC.ndc      != null ? _ovSC.ndc      : _autoNdcI;
        const _descI   = _ovSC.desc     != null ? _ovSC.desc     : _autoDescI;
        const _qtyI    = _ovSC.qty      != null ? _ovSC.qty      : _autoQtyI;
        const _szI     = _ovSC.size     != null ? _ovSC.size     : _autoSzI;
        const _dateI   = _ovSC.date     != null ? _ovSC.date     : _autoDateI;
        const _extPriceI = _ovSC.extPrice != null ? _ovSC.extPrice : _autoExtPI;
        const costColIs  = matchAllCols(hdrs, 'costCol').filter(i => i !== _extPriceI && i !== unitPriceI);
        const isMcKesson = doseQtyExtI >= 0;
        const mappingIdx = { ndc: _ndcI, qty: _qtyI, desc: _descI, size: _szI, doseQtyExt: doseQtyExtI, date: _dateI, extPrice: _extPriceI };
        const allDates    = [];
        const previewRows = [];

        for (let i = hi + 1; i < Math.min(lines.length, MAX_PREVIEW + hi + 1); i++) {
            if (!lines[i].trim()) continue;
            previewRows.push((sep === '\t' ? lines[i].split('\t') : csvLine(lines[i])).map(c => cleanVal(c)));
        }
        rawPreviewData.push({ fileName: file.name, type: 'supplier', sheetName: null, headerRow: hi + 1, totalRows: lines.length - hi - 1, headers: hdrs, rows: previewRows, mappingIdx, stats });

        if (_ndcI < 0) { parseStats[file.name] = stats; return; }

        for (let i = hi + 1; i < lines.length; i++) {
            const rawCols = sep === '\t' ? lines[i].split('\t') : csvLine(lines[i]);
            if (rawCols.length < 2) continue;
            const c = rawCols.map(cleanVal);
            stats.rows++;

            const ndc = cleanNDC(c[_ndcI]);
            if (_dateI >= 0 && c[_dateI]) allDates.push(c[_dateI]);
            if (!ndc || ndc.length < 9) { stats.skipped++; continue; }
            if (isDummyNDC(ndc)) { stats.dummyNDC++; continue; }

            // Skip return/credit/unaccepted transactions (CSV branch)
            // Handles: Purchase/Return=Return (Invoice_Review/Cardinal), Order Type=RETURN,
            // Invoice Type=Credit, Order Status=Unaccepted/Cancelled (TRXADE)
            if (orderTypeI >= 0) {
                const ot = (c[orderTypeI] || '').trim().toLowerCase();
                if (ot === 'return' || ot === 'credit' || ot === 'unaccepted' || ot === 'cancelled' || ot === 'canceled') {
                    stats.returns++;
                    stats.skipped++;
                    continue;
                }
            }

            const desc   = _descI >= 0 ? c[_descI]   : '';
            const strong = strongI >= 0 ? c[strongI] : '';
            const form   = formI   >= 0 ? c[formI]   : '';
            const qty  = _qtyI >= 0 ? (parseFloat(c[_qtyI].replace(/[^\d.\-]/g, '')) || 0) : 1;
            if (qty < 0) { stats.returns++; stats.skipped++; continue; }
            if (qty === 0) { stats.skipped++; continue; }

            const szRaw = _szI >= 0 ? c[_szI] : '';
            let sz, pkgSrc;
            if (isMcKesson) {
                const doseExt = parseFloat((c[doseQtyExtI] || '').replace(/[^\d.]/g, '')) || 0;
                if (doseExt > 0) { sz = Math.round((doseExt / qty) * 1000) / 1000; pkgSrc = 'derived'; }
                else { stats.zeroDoseExt++; sz = billingPkgMap[ndc] > 0 ? billingPkgMap[ndc] : 1; pkgSrc = billingPkgMap[ndc] > 0 ? 'billing' : 'none'; }
                if (billingPkgMap[ndc] > 0) { sz = billingPkgMap[ndc]; pkgSrc = 'billing'; }
            } else {
                if (billingPkgMap[ndc] > 0) { sz = billingPkgMap[ndc]; pkgSrc = 'billing'; }
                else { sz = parseSize(szRaw); pkgSrc = sz > 1 ? 'supplier' : 'none'; }
            }

            const extP   = _extPriceI >= 0 ? parseDollar(c[_extPriceI])  : 0;
            const unitP  = unitPriceI >= 0 ? parseDollar(c[unitPriceI]) : 0;
            // Sum all monthly-cost columns (e.g. Mar 2026 Cost + Apr 2026 Cost)
            const multiCostP = costColIs.reduce((s, ci) => s + parseDollar(c[ci] || ''), 0);
            const lineCost = extP || multiCostP || (unitP * qty);
            if (!purchaseMap[ndc]) purchaseMap[ndc] = { description: '', packageSize: 0, totalQty: 0, pkgSrc: 'none', totalExtPrice: 0, unitPrice: 0 };
            purchaseMap[ndc].totalQty += qty * sz;
            purchaseMap[ndc].totalExtPrice = (purchaseMap[ndc].totalExtPrice || 0) + lineCost;
            if (!purchaseMap[ndc].unitPrice && unitP) purchaseMap[ndc].unitPrice = unitP;
            if (!purchaseMap[ndc].packageSize && sz > 1) { purchaseMap[ndc].packageSize = sz; purchaseMap[ndc].pkgSrc = pkgSrc; }
            if (!purchaseMap[ndc].description && desc)   purchaseMap[ndc].description = desc;
            if (!purchaseMap[ndc].strong     && strong) purchaseMap[ndc].strong      = strong;
            if (!purchaseMap[ndc].form       && form)   purchaseMap[ndc].form        = form;
            // NABP: only flag when file has an explicit Source Name column
            // Source names IN the NON_NABP_WHOLESALERS list → flagged non-NABP
            // Source names NOT in the list → NABP (accredited) → no flag
            if (sourceI >= 0) {
                const srcName = c[sourceI];
                if (srcName && isNonNABP(srcName)) {
                    if (!purchaseMap[ndc].nonNabpSources) purchaseMap[ndc].nonNabpSources = new Set();
                    purchaseMap[ndc].nonNabpSources.add(srcName);
                }
            }
            addSupTransaction(ndc, file.name, qty, String(sz), pkgSrc, _dateI >= 0 ? c[_dateI] : '', lineCost);
        }
        stats.dateRange = detectDateRange(allDates);

    } else {
        // XLSX / XLS
        const buf = await file.arrayBuffer();
        const wb  = XLSX.read(buf, { type: 'array' });

        // ── Smith Drugs detection ────────────────────────────────────────────
        // Identify Smith Drugs format by checking for "Purchase History" sheet
        // and the "PACK SIZE" reference sheet. When found, build an NDC → pkg
        // size lookup from PACK SIZE (col 1 = NDC integer, col 13 = pkg size).
        const isSmithDrugs = wb.SheetNames.some(n => /purchase.?history/i.test(n)) &&
                             wb.SheetNames.some(n => /pack.?size/i.test(n));
        const smithPackSizeLookup = {};
        if (isSmithDrugs) {
            const packSizeSheet = wb.SheetNames.find(n => /pack.?size/i.test(n));
            if (packSizeSheet) {
                const psData = XLSX.utils.sheet_to_json(wb.Sheets[packSizeSheet], { defval: '', header: 1 });
                for (const row of psData) {
                    // col 1 = NDC as integer, col 13 = pkg size number
                    const rawNdc = row[1];
                    const rawSz  = row[13];
                    if (!rawNdc || !rawSz) continue;
                    const ndc = cleanNDC(String(rawNdc));
                    const sz  = parseFloat(String(rawSz)) || 0;
                    if (ndc && ndc.length >= 9 && sz > 0 && !smithPackSizeLookup[ndc]) {
                        smithPackSizeLookup[ndc] = sz;
                    }
                }
            }
        }
        // ── end Smith Drugs PACK SIZE build ─────────────────────────────────

        for (const sheetName of wb.SheetNames) {
            // Skip the Smith Drugs PACK SIZE reference sheet — it's data, not transactions
            if (isSmithDrugs && /pack.?size/i.test(sheetName)) continue;

            const data = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '', header: 1 });
            if (!data.length) continue;

            // Find real header row; use multi-row merge for summary-style files (e.g. ABC Template)
            const hi   = findXlsxHeaderRow(data, 12);
            const hdrs = buildXlsxHeaders(data, hi);

            const ndcI        = matchCol(hdrs, 'ndc');
            const descI       = matchCol(hdrs, 'description');
            const strongI     = matchCol(hdrs, 'drugStrong');
            const formI       = matchCol(hdrs, 'drugForm');
            const qtyI        = matchCol(hdrs, 'qty');
            const szI         = matchCol(hdrs, 'size');
            const doseQtyExtI = matchCol(hdrs, 'doseQtyExt');
            const dateI       = matchCol(hdrs, 'invoiceDate');
            const extPriceI   = matchCol(hdrs, 'extPrice');
            const unitPriceI  = matchCol(hdrs, 'unitPrice');
            const costColIs   = matchAllCols(hdrs, 'costCol').filter(i => i !== extPriceI && i !== unitPriceI);
            const sourceI     = matchCol(hdrs, 'sourceName');
            const isMcKesson  = doseQtyExtI >= 0;
            // Smith Drugs specific columns
            const orderTypeI      = matchCol(hdrs, 'orderType');      // skip RETURN rows
            const brandOrGenericI = matchCol(hdrs, 'brand');          // "Brand or Generic" → brand flag
            const unitsPurchasedI = matchCol(hdrs, 'unitsPurchased'); // total dispensed units (qty×sz), NOT pkg size
            // Smith Drugs: "Units" col matches 'size' pattern and IS the real pkg size;
            // "Size" col contains format strings like "1X30 TB2" — parseSize handles those too.
            // We prefer "Units" (integer) over "Size" (string) for Smith Drugs files.
            const unitsColI = isSmithDrugs ? hdrs.findIndex(h => /^units$/i.test(h)) : -1;

            const label       = wb.SheetNames.filter(n => !(isSmithDrugs && /pack.?size/i.test(n))).length > 1
                                ? `${file.name} [${sheetName}]` : file.name;
            // Apply user column overrides for this file (XLSX supplier)
            const _fileKey = label || file.name;
            const _ovXL = (typeof columnOverrides!=='undefined')?(columnOverrides[_fileKey]||{}):{};
            const _ndcI=_ovXL.ndc??ndcI, _qtyI=_ovXL.qty??qtyI, _descI=_ovXL.desc??descI, _szI=_ovXL.size??szI, _dateI=_ovXL.date??dateI, _extPriceI=_ovXL.extPrice??extPriceI;
            const mappingIdx  = { ndc: _ndcI, qty: _qtyI, desc: _descI, size: _szI, doseQtyExt: doseQtyExtI, date: _dateI, extPrice: _extPriceI };
            const allDates    = [];

            const previewRows = data.slice(hi + 1).map(r =>
                hdrs.map((_, i) => cleanVal(String(r[i] !== undefined ? r[i] : '')))
            );
            rawPreviewData.push({ fileName: label, type: 'supplier', sheetName, headerRow: hi + 1, totalRows: data.length - hi - 1, headers: hdrs, rows: previewRows, mappingIdx, stats });

            if (_ndcI < 0) continue;

            for (const rowArr of data.slice(hi + 1)) {
                const v = i => i >= 0 ? cleanVal(String(rowArr[i] !== undefined ? rowArr[i] : '')) : '';
                stats.rows++;

                // Skip return/credit transactions
                // Handles: Order Type=RETURN (Smith Drugs), Purchase/Return=Return (Invoice_Review),
                // Invoice Type=Credit (Cardinal), Order Status=Unaccepted/Cancelled (TRXADE)
                if (orderTypeI >= 0) {
                    const ot = v(orderTypeI).trim().toLowerCase();
                    if (ot === 'return' || ot === 'credit' || ot === 'unaccepted' || ot === 'cancelled' || ot === 'canceled') {
                        stats.returns++;
                        stats.skipped++;
                        continue;
                    }
                }

                const ndc = cleanNDC(v(_ndcI));
                if (_dateI >= 0) allDates.push(v(_dateI));
                if (!ndc || ndc.length < 9) { stats.skipped++; continue; }
                if (isDummyNDC(ndc)) { stats.dummyNDC++; continue; }

                const desc   = _descI >= 0 ? v(_descI)   : '';
                const strong = strongI >= 0 ? v(strongI) : '';
                const form   = formI   >= 0 ? v(formI)   : '';
                const qty  = _qtyI >= 0 ? (parseFloat(v(_qtyI).replace(/[^\d.\-]/g, '')) || 0) : 1;
                if (qty < 0) { stats.returns++; stats.skipped++; continue; }
                if (qty === 0) { stats.skipped++; continue; }

                // Brand flag: Smith Drugs "Brand or Generic" column → 'B' or 'G'
                const brandFlag = brandOrGenericI >= 0
                    ? (/^brand$/i.test(v(brandOrGenericI).trim()) ? 'B' : 'G')
                    : '';

                const szRaw = _szI >= 0 ? v(_szI) : '';
                let sz, pkgSrc;
                if (isMcKesson) {
                    const doseExt = parseFloat(v(doseQtyExtI).replace(/[^\d.]/g, '')) || 0;
                    if (doseExt > 0) { sz = Math.round((doseExt / qty) * 1000) / 1000; pkgSrc = 'derived'; }
                    else { stats.zeroDoseExt++; sz = billingPkgMap[ndc] > 0 ? billingPkgMap[ndc] : 1; pkgSrc = billingPkgMap[ndc] > 0 ? 'billing' : 'none'; }
                    if (billingPkgMap[ndc] > 0) { sz = billingPkgMap[ndc]; pkgSrc = 'billing'; }
                } else if (isSmithDrugs) {
                    // Priority for Smith Drugs pkg size:
                    // 1. Billing pkg map (most trusted — from dispensing records)
                    // 2. PACK SIZE sheet lookup (exact NDC match, very reliable)
                    // 3. "Units" column (integer, e.g. 30, 100, 120)
                    // 4. "Size" column string parse (e.g. "1X30 TB2" → 30)
                    if (billingPkgMap[ndc] > 0) {
                        sz = billingPkgMap[ndc]; pkgSrc = 'billing';
                    } else if (smithPackSizeLookup[ndc] > 0) {
                        sz = smithPackSizeLookup[ndc]; pkgSrc = 'supplier';
                    } else if (unitsColI >= 0) {
                        const uVal = parseFloat(v(unitsColI).replace(/[^\d.]/g, '')) || 0;
                        sz = uVal > 0 ? uVal : parseSize(szRaw);
                        pkgSrc = sz > 1 ? 'supplier' : 'none';
                    } else {
                        sz = parseSize(szRaw); pkgSrc = sz > 1 ? 'supplier' : 'none';
                    }
                } else {
                    if (billingPkgMap[ndc] > 0) { sz = billingPkgMap[ndc]; pkgSrc = 'billing'; }
                    else { sz = parseSize(szRaw); pkgSrc = sz > 1 ? 'supplier' : 'none'; }
                }

                const extP   = _extPriceI >= 0 ? parseDollar(v(_extPriceI))  : 0;
                const unitP  = unitPriceI >= 0 ? parseDollar(v(unitPriceI)) : 0;
                const multiCostP = costColIs.reduce((s, ci) => s + parseDollar(v(ci)), 0);
                const lineCost = extP || multiCostP || (unitP * qty);
                if (!purchaseMap[ndc]) purchaseMap[ndc] = { description: '', packageSize: 0, totalQty: 0, pkgSrc: 'none', totalExtPrice: 0, unitPrice: 0 };
                purchaseMap[ndc].totalQty += qty * sz;
                purchaseMap[ndc].totalExtPrice = (purchaseMap[ndc].totalExtPrice || 0) + lineCost;
                if (!purchaseMap[ndc].unitPrice && unitP) purchaseMap[ndc].unitPrice = unitP;
                if (!purchaseMap[ndc].packageSize && sz > 1) { purchaseMap[ndc].packageSize = sz; purchaseMap[ndc].pkgSrc = pkgSrc; }
                if (!purchaseMap[ndc].description && desc)   purchaseMap[ndc].description = desc;
                if (!purchaseMap[ndc].strong     && strong) purchaseMap[ndc].strong      = strong;
                if (!purchaseMap[ndc].form       && form)   purchaseMap[ndc].form        = form;
                if (!purchaseMap[ndc].brand      && brandFlag) purchaseMap[ndc].brand   = brandFlag;
                // NABP: only flag when file has an explicit Source Name column
                // Source names IN the NON_NABP_WHOLESALERS list → flagged non-NABP
                // Source names NOT in the list → NABP (accredited) → no flag
                if (sourceI >= 0) {
                    const srcName = v(sourceI);
                    if (srcName && isNonNABP(srcName)) {
                        if (!purchaseMap[ndc].nonNabpSources) purchaseMap[ndc].nonNabpSources = new Set();
                        purchaseMap[ndc].nonNabpSources.add(srcName);
                    }
                }
                addSupTransaction(ndc, label, qty, String(sz), pkgSrc, _dateI >= 0 ? v(_dateI) : '', lineCost);
            }
            stats.dateRange = detectDateRange(allDates);
        }
    }
    parseStats[file.name] = stats;
}

// ════════════════════════════════════
//  READ BILLING FILE
// ════════════════════════════════════

async function readBilling(file) {
    const userFmt = (window.bilFmt || 'auto');
    const ext = userFmt === 'auto' ? file.name.split('.').pop().toLowerCase() : userFmt;
    const MAX_PREVIEW = 99999; // store all rows so preview search works across entire file
    const stats = { rows: 0, skipped: 0, dupRx: 0, dateRange: null, type: 'billing' };
    const rxSeen  = new Set();
    const allDates = [];

    if (ext === 'csv' || ext === 'tsv') {
        const sep   = ext === 'tsv' ? '\t' : ',';
        const text  = await file.text();
        const lines = text.split('\n').map(l => l.replace(/\r/g, ''));

        // Auto-detect real header row + merge multi-row headers
        const hi   = findCsvHeaderRow(lines, 8);
        const hdrs = buildCsvHeaders(lines, hi, sep);

        const ix = f => matchCol(hdrs, f);
        const [ndcI, insI, binI, qtyI, descI, strI, frmI, pkgI, brI, rxnoI, dateI, totalInsPaidI] =
            ['ndc', 'insName', 'binNo', 'qty', 'description', 'drugStrong', 'drugForm', 'pkgSize', 'brand', 'rxno', 'date', 'totalInsPaid'].map(ix);
        // Apply user column overrides for billing file
        const _ovBC = (typeof columnOverrides!=='undefined')?(columnOverrides[file.name]||{}):{};
        const _bNdcI=_ovBC.ndc??ndcI, _bQtyI=_ovBC.qty??qtyI, _bInsI=_ovBC.ins??insI, _bBinI=_ovBC.bin??binI, _bDateI=_ovBC.date??dateI;

        const previewRows = [];
        for (let i = hi + 1; i < Math.min(lines.length, MAX_PREVIEW + hi + 1); i++) {
            if (!lines[i].trim()) continue;
            previewRows.push((sep === '\t' ? lines[i].split('\t') : csvLine(lines[i])).map(c => cleanVal(c)));
        }
        rawPreviewData.push({ fileName: file.name, type: 'billing', sheetName: null, headerRow: hi + 1, totalRows: lines.length - hi - 1, headers: hdrs, rows: previewRows, mappingIdx: { ndc: _bNdcI, qty: _bQtyI, ins: _bInsI, bin: _bBinI, date: _bDateI }, stats });

        for (let i = hi + 1; i < lines.length; i++) {
            const rawCols = sep === '\t' ? lines[i].split('\t') : csvLine(lines[i]);
            if (rawCols.length < 3) continue;
            // FIX: cleanVal strips ="..." wrapping before any parsing
            const c = rawCols.map(cleanVal);
            stats.rows++;

            const ndc = cleanNDC(c[_bNdcI]);
            if (!ndc || ndc.length < 9) { stats.skipped++; continue; }

            if (rxnoI >= 0 && c[rxnoI]) { const rxno = c[rxnoI]; if (rxSeen.has(rxno)) stats.dupRx++; else rxSeen.add(rxno); }
            if (_bDateI >= 0 && c[_bDateI]) allDates.push(c[_bDateI]);

            const rawIns = _bInsI >= 0 ? c[_bInsI].toUpperCase() : '';
            const bin    = normBIN(_bBinI >= 0 ? c[_bBinI] : '');
            const pkg    = pkgI >= 0 ? (parseFloat(c[pkgI].replace(/[^\d.]/g, '')) || 0) : 0;
            const qty    = _bQtyI >= 0 ? (parseFloat(c[_bQtyI].replace(/[^\d.\-]/g, '')) || 0) : 0;

            const insPaid = totalInsPaidI >= 0 ? (parseFloat((c[totalInsPaidI]||'').replace(/[^\d.\-]/g,'')) || 0) : 0;
            billingRows.push({ ndc, insName: resolveInsName(rawIns, bin), binNo: bin, qty, drgName: descI >= 0 ? c[descI] : '', strong: strI >= 0 ? c[strI] : '', form: frmI >= 0 ? c[frmI] : '', pkgSize: pkg, brand: brI >= 0 ? c[brI] : '', insPaid, date: _bDateI >= 0 ? c[_bDateI] : '' });

            if (pkg > 0) {
                if (!billingPkgCounter[ndc]) billingPkgCounter[ndc] = {};
                billingPkgCounter[ndc][pkg] = (billingPkgCounter[ndc][pkg] || 0) + 1;
            }
        }
        for (const [ndc, counts] of Object.entries(billingPkgCounter)) {
            if (!billingPkgMap[ndc]) {
                billingPkgMap[ndc] = parseFloat(Object.entries(counts).sort((a,b) => b[1]-a[1])[0][0]);
            }
        }

    } else {
        // XLSX / XLS billing
        const buf  = await file.arrayBuffer();
        const wb   = XLSX.read(buf, { type: 'array' });
        const data = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '', header: 1 });
        if (!data.length) { parseStats[file.name] = stats; return; }

        const hi   = findXlsxHeaderRow(data, 8);
        const hdrs = buildXlsxHeaders(data, hi);

        const ix = f => matchCol(hdrs, f);
        const [ndcI, insI, binI, qtyI, descI, strI, frmI, pkgI, brI, rxnoI, dateI, totalInsPaidI] =
            ['ndc', 'insName', 'binNo', 'qty', 'description', 'drugStrong', 'drugForm', 'pkgSize', 'brand', 'rxno', 'date', 'totalInsPaid'].map(ix);
        // Apply user column overrides for billing file (was previously missing for XLSX —
        // the CSV path applied overrides, but XLSX billing files ignored them entirely)
        const _ovBX = (typeof columnOverrides!=='undefined')?(columnOverrides[file.name]||{}):{};
        const _bNdcI=_ovBX.ndc??ndcI, _bQtyI=_ovBX.qty??qtyI, _bInsI=_ovBX.ins??insI, _bBinI=_ovBX.bin??binI, _bDateI=_ovBX.date??dateI;

        const previewRows = data.slice(hi + 1).map(r =>
            hdrs.map((_, i) => cleanVal(String(r[i] !== undefined ? r[i] : '')))
        );
        rawPreviewData.push({ fileName: file.name, type: 'billing', sheetName: wb.SheetNames[0], headerRow: hi + 1, totalRows: data.length - hi - 1, headers: hdrs, rows: previewRows, mappingIdx: { ndc: _bNdcI, qty: _bQtyI, ins: _bInsI, bin: _bBinI, date: _bDateI }, stats });

        for (const rowArr of data.slice(hi + 1)) {
            const v = i => i >= 0 ? cleanVal(String(rowArr[i] !== undefined ? rowArr[i] : '')) : '';
            stats.rows++;

            const ndc = cleanNDC(v(_bNdcI));
            if (!ndc || ndc.length < 9) { stats.skipped++; continue; }

            if (rxnoI >= 0 && v(rxnoI)) { const rxno = v(rxnoI); if (rxSeen.has(rxno)) stats.dupRx++; else rxSeen.add(rxno); }
            if (_bDateI >= 0) allDates.push(v(_bDateI));

            const rawIns = v(_bInsI).toUpperCase();
            const bin    = normBIN(v(_bBinI));
            const pkg    = parseFloat(v(pkgI).replace(/[^\d.]/g, '')) || 0;
            const qty    = parseFloat(v(_bQtyI).replace(/[^\d.\-]/g, '')) || 0;

            const insPaid = totalInsPaidI >= 0 ? (parseFloat(v(totalInsPaidI).replace(/[^\d.\-]/g,'')) || 0) : 0;
            billingRows.push({ ndc, insName: resolveInsName(rawIns, bin), binNo: bin, qty, drgName: v(descI), strong: v(strI), form: v(frmI), pkgSize: pkg, brand: v(brI), insPaid, date: _bDateI >= 0 ? v(_bDateI) : '' });

            if (pkg > 0) {
                if (!billingPkgCounter[ndc]) billingPkgCounter[ndc] = {};
                billingPkgCounter[ndc][pkg] = (billingPkgCounter[ndc][pkg] || 0) + 1;
            }
        }
        for (const [ndc, counts] of Object.entries(billingPkgCounter)) {
            if (!billingPkgMap[ndc]) {
                billingPkgMap[ndc] = parseFloat(Object.entries(counts).sort((a,b) => b[1]-a[1])[0][0]);
            }
        }
    }

    stats.dateRange = detectDateRange(allDates);
    parseStats[file.name] = stats;
}

// ════════════════════════════════════
//  DATE FILTER STATE moved to Option B block below
// ════════════════════════════════════

// Robust date parser — handles all formats seen in real files:
//   ="4/1/2026 12:00:00 AM"  (RxReportPlus CSV — ="..." wrapper)
//   2026-04-18               (McKesson CSV — ISO)
//   2/27/2026  02/26/2026    (MCK CSV, Smith Drugs — M/D/YYYY)
//   Thu Feb 04 2021...       (JS Date.toString from XLSX datetime objects)
//   44500                    (Excel serial number — rare fallback)
function _parseBillingDate(raw) {
    if (!raw && raw !== 0) return null;
    let str = String(raw).trim();

    // Strip ="..." or ="..." wrappers (RxReportPlus)
    str = str.replace(/^=?"?|"?$/g, '').trim();
    if (!str) return null;

    let year = null, month = null;

    // ISO: 2026-04-18 or YYYY-MM (Invoice Month — year-month only, no day)
    let m = str.match(/^(\d{4})-(\d{2})(?:-\d{2})?/);
    if (m) { year = +m[1]; month = +m[2]; }

    // M/D/YYYY or MM/DD/YYYY or M/D/YY (with optional time)
    if (!year) {
        m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
        if (m) {
            let y = +m[3];
            if (y < 100) y += y < 50 ? 2000 : 1900;
            year = y; month = +m[1];
        }
    }

    // JS Date string: "Thu Feb 04 2021..." or "Mon Jan 01 2024..."
    if (!year) {
        m = str.match(/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2},?\s+(\d{4})/i);
        if (!m) m = str.match(/\b(\d{4})\b.*\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i);
        if (m) {
            const d = new Date(str);
            if (!isNaN(d.getTime())) { year = d.getFullYear(); month = d.getMonth() + 1; }
        }
    }

    // Excel serial number (e.g. 44500 = some date in 2021)
    if (!year && /^\d{4,6}$/.test(str)) {
        const serial = +str;
        if (serial > 40000 && serial < 60000) {
            const d = new Date(Date.UTC(1899, 11, 30) + serial * 86400000);
            if (!isNaN(d.getTime())) { year = d.getUTCFullYear(); month = d.getUTCMonth() + 1; }
        }
    }

    // Last resort: let the browser try
    if (!year) {
        const d = new Date(str);
        if (!isNaN(d.getTime()) && d.getFullYear() > 2000) {
            year = d.getFullYear(); month = d.getMonth() + 1;
        }
    }

    if (!year || year < 2000 || year > 2100) return null;
    return { year, month };  // month 1–12
}




// ════════════════════════════════════
//  DATE FILTER — Option B
//  Presets: Last Month, 3M, 6M, 1Y, YTD, Custom
//  Logic: only show NDCs where BOTH supplier AND billing
//         have records in the selected range
// ════════════════════════════════════
let _dateFilterFrom = null;  // { year, month } or null
let _dateFilterTo   = null;  // { year, month } or null
let _dateActivePreset = null; // 'lm'|'3m'|'6m'|'1y'|'ytd'|'custom'|null

// ── Helpers ──────────────────────────────────────────────
// Convert { year, month } to a comparable integer (year*12+month)
function _ym(ym) { return ym ? ym.year * 12 + ym.month : null; }

// Is a raw date string within the active filter range?
function _dateInRange(raw) {
    if (!_dateFilterFrom && !_dateFilterTo) return true;
    const dm = _parseBillingDate(raw);
    if (!dm) return true;  // no parseable date → include
    const val  = _ym(dm);
    const from = _dateFilterFrom ? _ym(_dateFilterFrom) : -Infinity;
    const to   = _dateFilterTo   ? _ym(_dateFilterTo)   :  Infinity;
    return val >= from && val <= to;
}

// ── Preset calculator ─────────────────────────────────────
function dfSetPreset(preset, btn) {
    _dateActivePreset = preset;

    // Highlight active button
    document.querySelectorAll('.df-preset').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');

    // Show/hide custom pickers
    const cw = document.getElementById('df-custom-wrap');
    if (cw) cw.style.display = preset === 'custom' ? 'flex' : 'none';

    if (preset === 'custom') {
        // Don't apply yet — wait for user to pick month inputs
        return;
    }

    // Calculate from/to for the preset relative to today
    const now   = new Date();
    const toY   = now.getFullYear();
    const toM   = now.getMonth() + 1; // 1-12
    let fromY = toY, fromM = toM;

    if (preset === '1m') {
        // Last full calendar month
        const d = new Date(toY, toM - 2, 1); // previous month
        fromY = d.getFullYear(); fromM = d.getMonth() + 1;
        const e = new Date(toY, toM - 1, 0); // last day of prev month
        _dateFilterTo   = { year: e.getFullYear(), month: e.getMonth() + 1 };
        _dateFilterFrom = { year: fromY, month: fromM };
    } else if (preset === '3m') {
        const d = new Date(toY, toM - 4, 1);
        fromY = d.getFullYear(); fromM = d.getMonth() + 1;
        _dateFilterFrom = { year: fromY, month: fromM };
        _dateFilterTo   = { year: toY, month: toM };
    } else if (preset === '6m') {
        const d = new Date(toY, toM - 7, 1);
        fromY = d.getFullYear(); fromM = d.getMonth() + 1;
        _dateFilterFrom = { year: fromY, month: fromM };
        _dateFilterTo   = { year: toY, month: toM };
    } else if (preset === '1y') {
        const d = new Date(toY - 1, toM - 1, 1);
        fromY = d.getFullYear(); fromM = d.getMonth() + 1;
        _dateFilterFrom = { year: fromY, month: fromM };
        _dateFilterTo   = { year: toY, month: toM };
    } else if (preset === 'ytd') {
        _dateFilterFrom = { year: toY, month: 1 };
        _dateFilterTo   = { year: toY, month: toM };
    }

    _dfUpdatePill();
    reconcile();
    renderAll();
}

// Apply custom date range from the two <input type="month"> pickers
function dfApplyCustom() {
    const fromVal = document.getElementById('df-from').value; // "YYYY-MM"
    const toVal   = document.getElementById('df-to').value;

    if (!fromVal || !toVal) return; // wait for both

    const [fy, fm] = fromVal.split('-').map(Number);
    const [ty, tm] = toVal.split('-').map(Number);

    // Validate: from must be ≤ to
    if (fy * 12 + fm > ty * 12 + tm) {
        document.getElementById('df-from').style.borderColor = '#dc2626';
        document.getElementById('df-to').style.borderColor   = '#dc2626';
        return;
    }
    document.getElementById('df-from').style.borderColor = '';
    document.getElementById('df-to').style.borderColor   = '';

    _dateFilterFrom = { year: fy, month: fm };
    _dateFilterTo   = { year: ty, month: tm };
    _dfUpdatePill();
    reconcile();
    renderAll();
}

// Clear all date filter state
function dfClear() {
    _dateFilterFrom   = null;
    _dateFilterTo     = null;
    _dateActivePreset = null;

    document.querySelectorAll('.df-preset').forEach(b => b.classList.remove('active'));
    const cw = document.getElementById('df-custom-wrap');
    if (cw) cw.style.display = 'none';
    const fi = document.getElementById('df-from');
    const ti = document.getElementById('df-to');
    if (fi) { fi.value = ''; fi.style.borderColor = ''; }
    if (ti) { ti.value = ''; ti.style.borderColor = ''; }

    _dfUpdatePill();
    reconcile();
    renderAll();
}

// Update the active range pill label and visibility
function _dfUpdatePill() {
    const pill  = document.getElementById('df-range-pill');
    const label = document.getElementById('df-range-label');
    if (typeof dfUpdateFilterDot === 'function') dfUpdateFilterDot();
    if (!pill || !label) return;

    const active = _dateFilterFrom || _dateFilterTo;
    pill.style.display = active ? 'inline-flex' : 'none';

    if (active) {
        const MONTHS = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        const f = _dateFilterFrom ? `${MONTHS[_dateFilterFrom.month]} ${_dateFilterFrom.year}` : '…';
        const t = _dateFilterTo   ? `${MONTHS[_dateFilterTo.month]} ${_dateFilterTo.year}`     : '…';
        label.innerHTML = f === t ? `<span>${f}</span>` : `<span>${f}</span> → <span>${t}</span>`;
    }
}

// Called from showApp — just pre-populates the panel; visibility is toggled via the filter icon
function dfShow() {
    _dfPrePopulateCustom();
    if (typeof dfUpdateFilterDot === 'function') dfUpdateFilterDot();
}

// Pre-fill the custom month inputs with the actual data range
function _dfPrePopulateCustom() {
    const allDates = [];
    for (const r of billingRows) {
        const dm = _parseBillingDate(r.date);
        if (dm) allDates.push(_ym(dm));
    }
    for (const txList of Object.values(supTransactions || {})) {
        for (const tx of txList) {
            const dm = _parseBillingDate(tx.date);
            if (dm) allDates.push(_ym(tx.date ? _parseBillingDate(tx.date) : null));
        }
    }
    if (!allDates.length) return;
    const minYM = Math.min(...allDates.filter(Boolean));
    const maxYM = Math.max(...allDates.filter(Boolean));
    const toInputVal = ym => {
        const y = Math.floor(ym / 12);
        const m = ym % 12 || 12;
        return `${y}-${String(m).padStart(2,'0')}`;
    };
    const fi = document.getElementById('df-from');
    const ti = document.getElementById('df-to');
    if (fi && !fi.value) fi.value = toInputVal(minYM);
    if (ti && !ti.value) ti.value = toInputVal(maxYM);
}

// ════════════════════════════════════
//  RECONCILE
//  When date filter is active:
//  - Filter billing rows to range
//  - Filter supplier transactions to range → rebuild purchaseMap
//  - Only include NDCs present in BOTH filtered sets
// ════════════════════════════════════

function reconcile() {
    const filterActive = _dateFilterFrom || _dateFilterTo;

    // ── Step 1: Filter billing rows by date ──────────────
    // Rows with no date field → always include (no date = can't filter out)
    const activeBillingRows = filterActive
        ? billingRows.filter(r => !r.date || _dateInRange(r.date))
        : billingRows;

    // ── Step 2: Filter supplier transactions by date → rebuild purchaseMap ──
    // KEY RULE: when filter is active, a supplier transaction with NO date is
    // treated as "undatable" and included (benefit of the doubt).
    // A transaction WITH a date that falls OUTSIDE the range is excluded.
    let activePurchaseMap = purchaseMap;
    // Track which NDCs have ANY dated transactions (so we can distinguish
    // "no dates at all" from "dates all out of range")
    const supHasAnyDate = {}; // ndc → bool

    if (filterActive) {
        activePurchaseMap = {};
        for (const [ndc, txList] of Object.entries(supTransactions)) {
            const hasDated = txList.some(tx => tx.date && tx.date.trim() !== '');
            supHasAnyDate[ndc] = hasDated;

            let filtered;
            if (!hasDated) {
                // No dates at all on this supplier file for this NDC →
                // include all transactions (can't filter what has no date)
                filtered = txList;
            } else {
                // Has dates → only keep those IN range
                filtered = txList.filter(tx => !tx.date || !tx.date.trim() || _dateInRange(tx.date));
            }

            if (!filtered.length) continue;
            const orig = purchaseMap[ndc] || {};
            activePurchaseMap[ndc] = {
                ...orig,
                totalQty:      filtered.reduce((s, t) => s + t.total,    0),
                totalExtPrice: filtered.reduce((s, t) => s + (t.extPrice || 0), 0),
            };
        }
    }

    // ── Step 3: Apply the core date-filter rule ───────────
    // Rule: if billing date IS in range but supplier has dated transactions
    //       and NONE of them fall in range → hide the entire NDC from Results.
    //
    // In other words: both sides must have data in the selected date window.
    // Exception: supplier files with no dates at all are not penalised.
    const billedNdcs   = new Set(activeBillingRows.map(r => r.ndc));
    const suppliedNdcs = new Set(Object.keys(activePurchaseMap));

    const resultNdcs = filterActive
        ? new Set([...billedNdcs].filter(ndc => {
            // Must exist in supplier data (in-range or undated)
            if (!suppliedNdcs.has(ndc)) return false;
            const sup = activePurchaseMap[ndc];
            if (!sup || sup.totalQty <= 0) {
                // Supplier key exists but zero qty after date filter:
                // If it had dated transactions, they were all out of range → HIDE
                if (supHasAnyDate[ndc]) return false;
                // Had no dates → include anyway
                return true;
            }
            return true;
          }))
        : billedNdcs;

    // ── Step 4: Group billing rows for result NDCs only ───
    const grouped = {};
    for (const r of activeBillingRows) {
        if (!resultNdcs.has(r.ndc)) continue;
        if (!grouped[r.ndc]) grouped[r.ndc] = [];
        grouped[r.ndc].push(r);
    }

    // Also exclude NDCs where billing qty sums to zero in range
    if (filterActive) {
        for (const ndc of Object.keys(grouped)) {
            const totalQty = grouped[ndc].reduce((s, r) => s + (r.qty || 0), 0);
            if (totalQty <= 0) delete grouped[ndc];
        }
    }

    ndcGroups = [];
    for (const [ndc, rows] of Object.entries(grouped)) {
        const insMap = {};
        for (const r of rows) {
            const key = (r.insName || 'UNKNOWN').trim().toLowerCase();
            if (!insMap[key]) {
                const display = key.replace(/\b\w/g, c => c.toUpperCase());
                insMap[key] = { insName: display, bins: [], qty: 0, insPaid: 0 };
            }
            insMap[key].qty    += r.qty;
            insMap[key].insPaid += (r.insPaid || 0);
            if (r.binNo && !insMap[key].bins.includes(r.binNo)) insMap[key].bins.push(r.binNo);
        }
        const insurerRows      = Object.values(insMap).map(r => ({ insName: r.insName, binNo: r.bins.join(', '), bins: r.bins, qty: r.qty, insPaid: r.insPaid }));
        const totalRxQty       = insurerRows.reduce((s, r) => s + r.qty, 0);
        const sup              = activePurchaseMap[ndc] || {};
        const totalPurchaseQty = sup.totalQty || 0;
        const diff             = totalPurchaseQty - totalRxQty;
        const status           = diff === 0 ? 'ok' : diff > 0 ? 'over' : 'short';
        const s                = rows[0];
        const drgName          = s.drgName || sup.description || '';
        const strong           = s.strong || sup.strong || '';
        const form             = s.form   || sup.form   || '';
        const packageSize      = s.pkgSize || sup.packageSize || billingPkgMap[ndc] || 0;
        const totalInsPaid     = rows.reduce((sum, r) => sum + (r.insPaid || 0), 0);
        const totalSupplyCost  = sup.totalExtPrice || 0;
        const dollarDiff       = totalSupplyCost - totalInsPaid;
        const unitPrice        = sup.unitPrice || 0;
        const nonNabpSources   = sup.nonNabpSources ? [...sup.nonNabpSources] : [];

        ndcGroups.push({
            ndc, drgName, strong, form,
            description: buildDesc(drgName, strong, form) || drgName.toUpperCase() || sup.description || '',
            packageSize, insurerRows,
            maxQty: Math.max(...insurerRows.map(r => r.qty)),
            totalRxQty, totalPurchaseQty, diff, status,
            brand: s.brand,
            drugForm: (form || '').toUpperCase(),
            pkgSrc: sup.pkgSrc || '',
            totalInsPaid, totalSupplyCost, dollarDiff, unitPrice,
            nonNabpSources,
            isNonNabp: nonNabpSources.length > 0
        });
    }
    ndcGroups.sort((a, b) => a.description.localeCompare(b.description));
}

