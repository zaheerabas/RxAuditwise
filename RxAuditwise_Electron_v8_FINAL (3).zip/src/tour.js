// ════════════════════════════════════════════════════════════
//  ONBOARDING TOUR — RxAuditwise
// ════════════════════════════════════════════════════════════

const TOUR_KEY = 'rxaw_tour_done_v3';

const TOUR_STEPS = [
    // ── UPLOAD SCREEN STEPS ──────────────────────────────────
    {
        target:   '#card-supplier',
        screen:   'upload',
        title:    '📦 Supplier Files',
        body:     'Drop your <strong>purchase / invoice files</strong> here.<br><br>Supports: McKesson, ABC, Smith Drugs, AmerisourceBergen, Product Movement, Belco, and any standard CSV or Excel.',
        position: 'bottom',
    },
    {
        target:   '#card-billing',
        screen:   'upload',
        title:    '🧾 Billing Files',
        body:     'Drop your <strong>Rx dispense / billing files</strong> here.<br><br>Supports: RxReportPlus, NEW_DATA, Randall Billing, and any file with NDC + insurer + quantity columns.',
        position: 'bottom',
    },
    {
        target:   '.fmt-panel',
        screen:   'upload',
        title:    '🔍 Auto-detect Format',
        body:     '<strong>Auto-detect</strong> works for almost all files — the parser reads column names automatically.<br><br>Only change this if your results look wrong or you have an unusual file format.',
        position: 'bottom',
    },
    {
        target:   '#process-btn',
        screen:   'upload',
        title:    '⚡ Run Reconciliation',
        body:     'Once both files are loaded, this button lights up. Click it to start.<br><br>The progress bar below shows each file being read, then reconciliation runs automatically.',
        position: 'top',
    },
    // ── APP SCREEN STEPS ─────────────────────────────────────
    {
        target:   '.topbar-tabs',
        screen:   'app',
        title:    '📑 Navigation Tabs',
        body:     'Each tab shows a different view of your reconciliation:<br><br>• <strong>Results</strong> — main reconciliation table<br>• <strong>Suppliers</strong> — all purchased NDCs<br>• <strong>Issues</strong> — SHORT and OVER problems<br>• <strong>Dollar</strong> — financial analysis<br>• And more…',
        position: 'bottom',
    },
    {
        target:   '#df-wrap',
        screen:   'app',
        title:    '📅 Date Filter',
        body:     'Filter by date range to narrow your reconciliation window.<br><br>Use presets like <strong>Last Month, 3M, 6M, 1Y, YTD</strong> — or pick <strong>Custom</strong> months.<br><br>When active, only NDCs with data in <em>both</em> supplier and billing files appear.',
        position: 'bottom',
        // df-panel starts closed — we temporarily open it for the spotlight
        beforeShow: function() {
            const el = document.getElementById('df-wrap');
            if (el && !el.classList.contains('open')) { el.classList.add('open'); el._tourShown = true; }
        },
        afterHide: function() {
            const el = document.getElementById('df-wrap');
            if (el && el._tourShown) { el.classList.remove('open'); el._tourShown = false; }
        },
    },
    {
        target:   '#status-filters',
        screen:   'app',
        title:    '🎯 Status Filters',
        body:     'Filter by reconciliation status:<br><br>• <strong>OK</strong> — purchased qty matches billed<br>• <strong>Over</strong> — more purchased than billed<br>• <strong>Short</strong> — less purchased than billed',
        position: 'bottom',
    },
    {
        target:   '.col-filter-caret',
        screen:   'app',
        title:    '▾ Sort & Filter Any Column',
        body:     'Click the small icon next to almost any column header for options tailored to that column — <strong>A→Z</strong> for names, <strong>Highest→Lowest</strong> for numbers, or <strong>OK/Over/Short First</strong> for status columns.<br><br>You can also drag a column header left or right to reorder it.',
        position: 'bottom',
    },
    {
        target:   '.search-wrap',
        screen:   'app',
        title:    '🔍 Search',
        body:     'Search by <strong>NDC number</strong> or <strong>drug name</strong> — applies across all tabs simultaneously.',
        position: 'bottom',
    },
    {
        target:   '#pkg-toggle-btn',
        screen:   'app',
        title:    '÷ Package Divide',
        body:     'Toggle <strong>÷ PKG</strong> to divide all quantities by the package size — switches the view from individual units to <em>packages</em>.',
        position: 'bottom',
    },
    {
        target:   '.export-btn',
        screen:   'app',
        title:    '⬇ Export',
        body:     'Export any tab\'s data as <strong>CSV</strong>, <strong>Excel</strong>, <strong>JSON</strong>, or <strong>PDF</strong>.<br><br>Exported data always matches exactly what\'s on screen — filters, sorts, and PKG divide included.',
        position: 'bottom',
    },
    {
        target:   null,
        screen:   'any',
        title:    '🎉 You\'re all set!',
        body:     'That\'s the full tour. A few tips:<br><br>• Load <strong>multiple supplier files</strong> at once — they\'re combined automatically<br>• The <strong>Issues tab</strong> is your fastest route to SHORT problems<br>• <strong>Non-NABP</strong> flags purchases from non-accredited wholesalers, worth a look<br>• Click the <strong>?</strong> icon any time to replay this tour, or open the <strong>Help Center</strong> from your profile menu for a full reference<br>• Use the <strong>Preview tab</strong> to re-map columns if detection is wrong',
        position: 'center',
    },
];

let _tourStep   = 0;
let _tourActive = false;
let _prevStep   = -1; // track previous step to call afterHide

function tourAutoStart() {
    if (!localStorage.getItem(TOUR_KEY)) {
        setTimeout(() => tourStart(false), 900);
    }
}

function tourStart(manual) {
    _tourActive = true;
    document.getElementById('tour-overlay').style.display = 'block';
    const onApp = document.getElementById('app-screen').style.display !== 'none';

    if (manual && onApp) {
        // Start from first app-screen step
        _tourStep = TOUR_STEPS.findIndex(s => s.screen === 'app' || s.screen === 'any');
        if (_tourStep < 0) _tourStep = 0;
    } else {
        _tourStep = 0;
    }
    _prevStep = -1;
    _tourRender();
    window.addEventListener('resize', _tourReposition);
}

function tourEnd() {
    _tourHideCallback(_prevStep);
    _tourActive = false;
    document.getElementById('tour-overlay').style.display = 'none';
    _tourClearSpotlight();
    localStorage.setItem(TOUR_KEY, '1');
    window.removeEventListener('resize', _tourReposition);
}

function tourNext() {
    // Call afterHide on current step before moving
    _tourHideCallback(_tourStep);
    if (_tourStep < TOUR_STEPS.length - 1) {
        // Skip steps that belong to the wrong screen
        let next = _tourStep + 1;
        const onUpload = document.getElementById('upload-screen').style.display !== 'none';
        const onApp    = document.getElementById('app-screen').style.display !== 'none';
        while (next < TOUR_STEPS.length - 1) {
            const s = TOUR_STEPS[next];
            if (s.screen === 'any') break;
            if (s.screen === 'upload' && onUpload) break;
            if (s.screen === 'app'    && onApp)    break;
            next++;
        }
        _prevStep  = _tourStep;
        _tourStep  = next;
        _tourRender();
    } else {
        tourEnd();
    }
}

function tourPrev() {
    _tourHideCallback(_tourStep);
    if (_tourStep > 0) {
        _prevStep = _tourStep;
        _tourStep--;
        _tourRender();
    }
}

function tourGoTo(i) {
    _tourHideCallback(_tourStep);
    _prevStep = _tourStep;
    _tourStep = i;
    _tourRender();
}

function tourBackdropClick() { tourNext(); }

function _tourHideCallback(idx) {
    if (idx >= 0 && idx < TOUR_STEPS.length && TOUR_STEPS[idx].afterHide) {
        try { TOUR_STEPS[idx].afterHide(); } catch(e) {}
    }
}

// ── Render ─────────────────────────────────────────────────────
function _tourRender() {
    const step  = TOUR_STEPS[_tourStep];
    const total = TOUR_STEPS.length;

    const onUpload = document.getElementById('upload-screen').style.display !== 'none';
    const onApp    = document.getElementById('app-screen').style.display    !== 'none';
    const wrongScreen = (step.screen === 'upload' && !onUpload) ||
                        (step.screen === 'app'    && !onApp);

    // Call beforeShow hook (e.g. reveal df-wrap for spotlight)
    if (!wrongScreen && step.beforeShow) {
        try { step.beforeShow(); } catch(e) {}
    }

    const overrideCenter = wrongScreen || step.position === 'center' || !step.target;

    // Badge + title
    document.getElementById('tour-badge').textContent = `Step ${_tourStep + 1} of ${total}`;
    document.getElementById('tour-title').textContent = step.title;

    // Body
    let bodyHtml = step.body;
    if (wrongScreen && step.screen === 'upload') {
        bodyHtml += `<div style="margin-top:12px;padding-top:10px;border-top:1px solid rgba(255,255,255,.12)">
            <button onclick="tourEnd();openManageFiles();"
                style="width:100%;padding:8px;background:#7c3aed;color:#fff;border:none;border-radius:6px;font-size:12.5px;font-weight:600;cursor:pointer;">
                ⊕ Open Manage Files</button>
            <div style="font-size:10.5px;color:#64748b;text-align:center;margin-top:5px;">Add or change files without losing results</div>
        </div>`;
    }
    document.getElementById('tour-body').innerHTML = bodyHtml;

    // Dots
    document.getElementById('tour-dots').innerHTML = TOUR_STEPS.map((_, i) =>
        `<div class="tour-dot ${i===_tourStep?'active':i<_tourStep?'done':''}" onclick="tourGoTo(${i})"></div>`
    ).join('');

    // Buttons
    document.getElementById('tour-prev').style.visibility = _tourStep === 0 ? 'hidden' : 'visible';
    const nextBtn = document.getElementById('tour-next');
    const isLast  = _tourStep === total - 1;
    nextBtn.textContent = isLast ? '✓ Got it!' : 'Next →';
    nextBtn.className   = 'tour-btn-next' + (isLast ? ' tour-finish' : '');
    const skipBtn = document.querySelector('.tour-btn-skip');
    if (skipBtn) skipBtn.style.display = isLast ? 'none' : '';

    requestAnimationFrame(() => setTimeout(() => _tourPosition(step, overrideCenter), 60));
}

// ── Position spotlight + tooltip ─────────────────────────────
function _tourPosition(step, overrideCenter) {
    const spotlight = document.getElementById('tour-spotlight');
    const tooltip   = document.getElementById('tour-tooltip');
    if (!spotlight || !tooltip) return;

    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const tw = Math.min(320, vw - 28);
    tooltip.style.width = tw + 'px';
    const th = tooltip.offsetHeight || 220;
    const MARGIN = 14, PAD = 8;

    if (overrideCenter) {
        _tourClearSpotlight();
        tooltip.className = 'arrow-none';
        Object.assign(tooltip.style, {
            left: Math.max(MARGIN, (vw - tw) / 2) + 'px',
            top:  Math.max(MARGIN, (vh - th) / 2) + 'px',
            opacity: '1'
        });
        _tourDimBackdrop(true);
        return;
    }

    const target = typeof step.target === 'function'
        ? step.target()
        : document.querySelector(step.target);

    if (!target) {
        _tourClearSpotlight();
        tooltip.className = 'arrow-none';
        Object.assign(tooltip.style, {
            left: Math.max(MARGIN, (vw - tw) / 2) + 'px',
            top:  Math.max(MARGIN, (vh - th) / 2) + 'px',
            opacity: '1'
        });
        _tourDimBackdrop(true);
        return;
    }

    // Ensure element is visible before measuring
    target.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
    const r = target.getBoundingClientRect();

    // If element has no size (hidden / zero dimensions), fall back to center
    if (r.width === 0 && r.height === 0) {
        _tourClearSpotlight();
        tooltip.className = 'arrow-none';
        Object.assign(tooltip.style, {
            left: Math.max(MARGIN, (vw - tw) / 2) + 'px',
            top:  Math.max(MARGIN, (vh - th) / 2) + 'px',
            opacity: '1'
        });
        _tourDimBackdrop(true);
        return;
    }

    // Spotlight
    Object.assign(spotlight.style, {
        left:    (r.left   - PAD) + 'px',
        top:     (r.top    - PAD) + 'px',
        width:   (r.width  + PAD * 2) + 'px',
        height:  (r.height + PAD * 2) + 'px',
        opacity: '1',
    });
    _tourDimBackdrop(false);

    // Tooltip placement
    const pos = step.position || 'bottom';
    let tx = 0, ty = 0, arrowClass = 'arrow-top';

    if (pos === 'bottom') {
        tx = Math.max(MARGIN, Math.min(r.left, vw - tw - MARGIN));
        ty = r.bottom + PAD + MARGIN;
        arrowClass = 'arrow-top';
        if (ty + th > vh - MARGIN) { ty = r.top - PAD - MARGIN - th; arrowClass = 'arrow-bottom'; }
    } else if (pos === 'top') {
        tx = Math.max(MARGIN, Math.min(r.left, vw - tw - MARGIN));
        ty = r.top - PAD - MARGIN - th;
        arrowClass = 'arrow-bottom';
        if (ty < MARGIN) { ty = r.bottom + PAD + MARGIN; arrowClass = 'arrow-top'; }
    } else if (pos === 'right') {
        tx = r.right + PAD + MARGIN;
        ty = Math.max(MARGIN, r.top - 20);
        arrowClass = 'arrow-left';
        if (tx + tw > vw - MARGIN) { tx = r.left - tw - PAD - MARGIN; arrowClass = 'arrow-right'; }
        if (tx < MARGIN) { tx = Math.max(MARGIN, (vw - tw) / 2); ty = r.bottom + PAD + MARGIN; arrowClass = 'arrow-top'; }
    } else if (pos === 'left') {
        tx = r.left - tw - PAD - MARGIN;
        ty = Math.max(MARGIN, r.top - 20);
        arrowClass = 'arrow-right';
        if (tx < MARGIN) { tx = r.right + PAD + MARGIN; arrowClass = 'arrow-left'; }
        if (tx + tw > vw - MARGIN) { tx = Math.max(MARGIN, (vw - tw) / 2); ty = r.bottom + PAD + MARGIN; arrowClass = 'arrow-top'; }
    }

    tx = Math.max(MARGIN, Math.min(tx, vw - tw - MARGIN));
    ty = Math.max(MARGIN, Math.min(ty, vh - th - MARGIN));

    Object.assign(tooltip.style, { left: tx + 'px', top: ty + 'px', opacity: '1' });
    tooltip.className = arrowClass;
}

function _tourDimBackdrop(dim) {
    const bd = document.getElementById('tour-backdrop');
    if (bd) bd.style.background = dim ? 'rgba(0,0,0,0.58)' : 'transparent';
}

function _tourClearSpotlight() {
    const s = document.getElementById('tour-spotlight');
    if (s) Object.assign(s.style, { width:'0', height:'0', opacity:'0', left:'-999px', top:'-999px' });
}

function _tourReposition() {
    if (!_tourActive) return;
    const step = TOUR_STEPS[_tourStep];
    const onUpload = document.getElementById('upload-screen').style.display !== 'none';
    const onApp    = document.getElementById('app-screen').style.display    !== 'none';
    const wrongScreen = (step.screen === 'upload' && !onUpload) || (step.screen === 'app' && !onApp);
    _tourPosition(step, wrongScreen || step.position === 'center' || !step.target);
}

document.addEventListener('keydown', function(e) {
    if (!_tourActive) return;
    if (e.key === 'ArrowRight' || e.key === 'Enter') { e.stopPropagation(); tourNext(); }
    if (e.key === 'ArrowLeft')  { e.stopPropagation(); tourPrev(); }
    if (e.key === 'Escape')     { e.stopPropagation(); tourEnd();  }
}, true);

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tourAutoStart);
} else {
    tourAutoStart();
}
