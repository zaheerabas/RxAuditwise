// ════════════════════════════════════
//  COLUMN ORDER SYSTEM
//  Drag-to-reorder headers; persisted in localStorage
// ════════════════════════════════════

const COL_ORDER_KEY = 'rxaw_col_order_v1';

// Column definitions — key matches what renderTable() uses
const COL_DEFS = [
    { key:'sr',          label:'SR#',            cls:'col-sr',    fixed:true, type:'num' },
    { key:'description', label:'DESCRIPTION',    cls:'col-desc',  sort:'description', type:'text'               },
    { key:'ndc',         label:'NDC',             cls:'col-ndc'                                                       },
    { key:'packageSize', label:'PKG SIZE',        cls:'col-pkg',   sort:'packageSize', type:'num'                },
    { key:'insName',     label:'RX INS NAME',     cls:'col-ins',   sort:'insName', type:'text'                    },
    { key:'binNo',       label:'RX INS BIN',      cls:'col-bin'                                                     },
    { key:'rxQty',       label:'FILLED QTY',      cls:'col-rxq',   sort:'totalRxQty',   id:'th-rxq', type:'num'       },
    { key:'purchaseQty', label:'PURCHASED QTY',   cls:'col-pq',    sort:'totalPurchaseQty', id:'th-pq', type:'num'    },
    { key:'diff',        label:'RECONCILIATION',  cls:'col-diff',  sort:'diff',    id:'th-diff', type:'status'   },
    { key:'status',      label:'STATUS',          cls:'col-stat',  sort:'status',  id:'th-stat', type:'status'   },
    { key:'insPaid',     label:'INS PAID ($)',     cls:'col-price', sort:'totalInsPaid',  priceColor:'#059669', type:'num' },
    { key:'supplyCost',  label:'SUPPLY COST ($)',  cls:'col-price', sort:'totalSupplyCost', priceColor:'var(--rxa-primary,#7c3aed)', type:'num' },
];

// Current column order — array of COL_DEFS keys
let _colOrder = null;

function colGetOrder() {
    if (_colOrder) return _colOrder;
    try {
        const saved = JSON.parse(localStorage.getItem(COL_ORDER_KEY) || 'null');
        if (Array.isArray(saved) && saved.length === COL_DEFS.length
            && COL_DEFS.every(c => saved.includes(c.key))) {
            _colOrder = saved;
            return _colOrder;
        }
    } catch(e) {}
    _colOrder = COL_DEFS.map(c => c.key);
    return _colOrder;
}

function colSaveOrder() {
    localStorage.setItem(COL_ORDER_KEY, JSON.stringify(_colOrder));
}

function colResetOrder() {
    _colOrder = COL_DEFS.map(c => c.key);
    localStorage.removeItem(COL_ORDER_KEY);
    colRenderHeader();
    applyFilters();
}

// Get ordered col defs
function colOrdered() {
    const order = colGetOrder();
    return order.map(k => COL_DEFS.find(c => c.key === k)).filter(Boolean);
}

// ── Render thead ──────────────────────────────────────────────
function colRenderHeader() {
    const row = document.getElementById('main-thead-row');
    if (!row) return;

    // Inject pkg badge text into qty cols if PKG active
    const pkgOn = typeof pkgDivideOn !== 'undefined' && pkgDivideOn;
    const pkgBadge = pkgOn ? ' <span class="pkg-div-badge">÷PKG</span>' : '';

    row.innerHTML = colOrdered().map(col => {
        const id   = col.id ? ` id="${col.id}"` : '';
        const sort = col.sort ? ` onclick="sortBy('${col.sort}')"` : '';
        const style = col.priceColor
            ? ` style="min-width:${col.key==='insPaid'?110:115}px;text-align:right;color:${col.priceColor};cursor:pointer"`
            : (col.fixed ? ' style="cursor:default"' : '');
        const dragAttrs = col.fixed ? '' :
            ` draggable="true"
              ondragstart="colDragStart(event,'${col.key}')"
              ondragover="colDragOver(event,'${col.key}')"
              ondrop="colDrop(event,'${col.key}')"
              ondragend="colDragEnd(event)"
              ondragleave="colDragLeave(event)"
              title="Drag to reorder column"`;

        let label = col.label;
        if (col.key === 'rxQty')       label = 'FILLED QTY' + pkgBadge;
        if (col.key === 'purchaseQty') label = 'PURCHASED QTY' + pkgBadge;
        if (col.key === 'diff')        label = 'RECONCILIATION' + pkgBadge;
        if (col.key === 'status')      label = 'STATUS' + pkgBadge;

        const caret = col.sort ? ` <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'sortByPreset','${col.sort}','${col.type || 'text'}')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span>` : '';

        return `<th class="${col.cls} col-draggable${col.fixed?' col-fixed':''}"${id}${sort}${style}${dragAttrs}>${label}${caret}</th>`;
    }).join('');
}

// ── Drag-and-drop state ────────────────────────────────────────
let _dragKey  = null;
let _dragOver = null;

function colDragStart(e, key) {
    _dragKey = key;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', key);
    // Style the dragged header
    setTimeout(() => e.target.classList.add('col-dragging'), 0);
}

function colDragOver(e, key) {
    if (!_dragKey || _dragKey === key) return;
    // Don't allow drop on fixed columns
    const targetCol = COL_DEFS.find(c => c.key === key);
    if (targetCol && targetCol.fixed) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (_dragOver !== key) {
        // Remove previous indicator
        document.querySelectorAll('.col-drop-left,.col-drop-right').forEach(el => {
            el.classList.remove('col-drop-left', 'col-drop-right');
        });
        _dragOver = key;
        // Show drop indicator on correct side
        const order = colGetOrder();
        const dragIdx  = order.indexOf(_dragKey);
        const targetIdx = order.indexOf(key);
        const th = e.currentTarget;
        th.classList.add(dragIdx < targetIdx ? 'col-drop-right' : 'col-drop-left');
    }
}

function colDragLeave(e) {
    e.currentTarget.classList.remove('col-drop-left', 'col-drop-right');
}

function colDrop(e, targetKey) {
    e.preventDefault();
    document.querySelectorAll('.col-drop-left,.col-drop-right').forEach(el => {
        el.classList.remove('col-drop-left', 'col-drop-right');
    });
    if (!_dragKey || _dragKey === targetKey) return;
    const targetCol = COL_DEFS.find(c => c.key === targetKey);
    if (targetCol && targetCol.fixed) return;

    const order = colGetOrder();
    const fromIdx = order.indexOf(_dragKey);
    const toIdx   = order.indexOf(targetKey);
    if (fromIdx < 0 || toIdx < 0) return;

    // Move: remove from current, insert at new position
    order.splice(fromIdx, 1);
    order.splice(toIdx, 0, _dragKey);
    _colOrder = order;
    colSaveOrder();

    // Re-render header and table
    colRenderHeader();
    renderTable();
    _dragKey = _dragOver = null;
}

function colDragEnd(e) {
    document.querySelectorAll('.col-dragging,.col-drop-left,.col-drop-right').forEach(el => {
        el.classList.remove('col-dragging', 'col-drop-left', 'col-drop-right');
    });
    _dragKey = _dragOver = null;
}

// ── Initialize header on first render ─────────────────────────
// (called from renderAll and applyFilters)

// ════════════════════════════════════
//  PKG DIVIDE — shared state & helpers
// ════════════════════════════════════

let pkgDivideOn = false;

function togglePkgDivide() {
    pkgDivideOn = !pkgDivideOn;

    // Sync ALL ÷PKG buttons (Results + MFP tabs)
    document.querySelectorAll('.pkg-toggle-btn').forEach(btn => {
        btn.classList.toggle('pkg-toggle-active', pkgDivideOn);
    });

    if (pkgDivideOn) {
        document.getElementById('th-rxq').innerHTML  = 'FILLED QTY <span class="pkg-div-badge">÷PKG</span>';
        document.getElementById('th-pq').innerHTML   = 'PURCHASED QTY <span class="pkg-div-badge">÷PKG</span>';
        document.getElementById('th-diff').innerHTML = 'RECONCILIATION <span class="pkg-div-badge">÷PKG</span>';
        document.getElementById('th-stat').innerHTML = 'STATUS <span class="pkg-div-badge">÷PKG</span>';
    } else {
        document.getElementById('th-rxq').textContent  = 'FILLED QTY';
        document.getElementById('th-pq').textContent   = 'PURCHASED QTY';
        document.getElementById('th-diff').textContent = 'RECONCILIATION';
        document.getElementById('th-stat').textContent = 'STATUS';
    }

    // Re-render all tabs that support ÷PKG
    renderTable();
    const mfpTab   = document.getElementById('tab-mfp');
    const finalTab = document.getElementById('tab-final');
    const issTab   = document.getElementById('tab-issues');
    if (mfpTab   && mfpTab.style.display    === 'flex')   renderMFP();
    if (finalTab && finalTab.classList.contains('active')) renderFinalTab();
    if (issTab   && issTab.classList.contains('active'))   renderIssuesTab();
}

// Divide value by pkg, return formatted string
function divByPkg(val, pkg) {
    if (!pkg || pkg === 0) return val != null ? fmt(val) : '—';
    const result = val / pkg;
    return result % 1 === 0 ? result.toFixed(0) : result.toFixed(2);
}

// Build status HTML — always shows amount, ÷PKG when active
function statusHtmlFn(d, pkg) {
    if (pkgDivideOn && pkg > 0) {
        // Divide the diff by pkg size and show result
        const dPkg  = d / pkg;
        const abs   = Math.abs(dPkg);
        const absStr = abs % 1 === 0 ? abs.toFixed(1) : abs.toFixed(2);
        if (d === 0)  return `<span class="st-ok">OK - (0.0)</span>`;
        if (d > 0)    return `<span class="st-over">OVER - (${absStr})</span>`;
        return         `<span class="st-short">SHORT - (${absStr})</span>`;
    }
    // Normal mode — show original amounts
    const abs = Math.abs(d).toFixed(1);
    if (d === 0)  return `<span class="st-ok">OK - (0.0)</span>`;
    if (d > 0)    return `<span class="st-over">OVER - (${abs})</span>`;
    return         `<span class="st-short">SHORT - (${abs})</span>`;
}

// Build diff/reconciliation cell HTML — normal or ÷PKG mode
// SHORT: show only the number (no "SHORT" text) in red
function diffHtmlFn(d, pkg) {
    if (pkgDivideOn && pkg > 0) {
        const dPkg = d / pkg;
        if (dPkg > 0)   return `<span class="di-over">✔</span>`;
        if (dPkg === 0) return `<span class="di-ok">✔</span>`;
        const abs = Math.abs(dPkg);
        const str = abs % 1 === 0 ? abs.toFixed(0) : abs.toFixed(2);
        return `<span class="di-short">-(${str})</span>`;
    }
    if (d > 0)   return `<span class="di-over">✔</span>`;
    if (d === 0) return `<span class="di-ok">✔</span>`;
    return `<span class="di-short">-(${fmt(Math.abs(d))})</span>`;
}

// Format a qty value — normal or ÷PKG
function qtyDisp(val, pkg) {
    if (pkgDivideOn && pkg > 0) return `<span class="pkg-div-val">${divByPkg(val, pkg)}</span>`;
    return fmt(val);
}

// ════════════════════════════════════
//  RESULTS TAB
// ════════════════════════════════════

// ── Dirty flags per tab — set when data changes, cleared when tab renders ──
const _TABS = ['suppliers','raw','final','notbilled','bill','dollar','discarded','issues','mfp'];
const _dirty = {};
function _markAllDirty() { _TABS.forEach(t => { _dirty[t] = true; }); }
function _markDirty(tab) { _dirty[tab] = true; }

function renderAll() {
    buildAllRows();
    populateFilters();
    colRenderHeader(); // ensure headers reflect current column order
    // Only re-render the Results tab immediately (it is always visible after reconcile)
    applyFilters();
    renderSummary();
    // Mark all other tabs dirty — they will re-render only when visited
    _markAllDirty();
    if (typeof updateTabBadges === 'function') updateTabBadges();
}

function buildAllRows() {
    allRows = [];
    for (const grp of ndcGroups) {
        for (const ins of grp.insurerRows) {
            // Per-insurer diff and status: compare THIS insurer's qty vs total purchased
            const insDiff   = grp.totalPurchaseQty - ins.qty;
            const insStatus = insDiff === 0 ? 'ok' : insDiff > 0 ? 'over' : 'short';
            allRows.push({
                type: 'detail',
                description: grp.description, drgName: grp.drgName, strong: grp.strong, form: grp.form,
                ndc: grp.ndc, packageSize: grp.packageSize,
                insName: ins.insName, binNo: ins.binNo,
                rxQty: ins.qty, insPaidRow: ins.insPaid || 0,
                purchaseQty: grp.totalPurchaseQty,
                diff: insDiff,
                status: grp.status,       // NDC-level status (used when no insurer filter)
                insStatus,                // insurer-level status (used when insurer filter active)
                brand: grp.brand, drugForm: grp.drugForm,
                isHL: ins.qty === grp.maxQty,
                ndcGroup: grp
            });
        }
        allRows.push({
            type: 'total',
            description: grp.description, drgName: grp.drgName, strong: grp.strong, form: grp.form,
            ndc: grp.ndc, packageSize: '', insName: '', binNo: '',
            rxQty: grp.totalRxQty, purchaseQty: grp.totalPurchaseQty,
            diff: grp.diff, status: grp.status,
            brand: grp.brand, drugForm: grp.drugForm, isHL: false, ndcGroup: grp,
            totalInsPaid: grp.totalInsPaid || 0, totalSupplyCost: grp.totalSupplyCost || 0
        });
    }
}

function normalizeInsName(name) {
    // Title-case: first letter of each word capitalised, rest lowercase
    if (!name) return name;
    return name.trim().toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

function populateFilters() {
    // Collect raw insurer names, normalize case for dedup, keep canonical form
    const rawIns = allRows.filter(r => r.type === 'detail').map(r => r.insName).filter(Boolean);
    // Dedup case-insensitively: keep first encountered capitalisation for display
    const insMap = new Map();
    for (const name of rawIns) {
        const key = name.trim().toLowerCase();
        if (!insMap.has(key)) insMap.set(key, normalizeInsName(name));
    }
    const ins = [...insMap.values()].sort((a, b) => a.localeCompare(b));

    const frm = [...new Set(allRows.filter(r => r.type === 'detail').map(r => r.drugForm).filter(Boolean))].sort();
    document.getElementById('ins-filter').innerHTML = '<option>All Insurers</option>' + ins.map(i => `<option value="${i.toLowerCase()}">${i}</option>`).join('');
    document.getElementById('form-filter').innerHTML = '<option>All Drug Forms</option>' + frm.map(f => `<option>${f}</option>`).join('');

    // Show/hide brand filter based on whether any brand data exists
    const hasBrand = allRows.some(r => r.brand && r.brand.trim());
    const brandEl = document.getElementById('brand-filter');
    if (brandEl) brandEl.style.display = hasBrand ? '' : 'none';
}

// ── NABP Filter ─────────────────────────────────────────────
let nabpFilterActive = false;

function toggleNABPFilter(btn) {
    nabpFilterActive = !nabpFilterActive;
    btn.classList.toggle('active', nabpFilterActive);
    applyFilters();
}

// Helper: parse a price range filter value into {min, max}
function parsePriceRange(val) {
    if (!val || val === 'all') return null;
    if (val === '0')     return { min: 0,    max: 0 };
    if (val === '5000+') return { min: 5000, max: Infinity };
    const [a, b] = val.split('-').map(Number);
    return { min: a, max: b };
}

function applyFilters() {
    const insF      = document.getElementById('ins-filter').value;
    const frmF      = document.getElementById('form-filter').value;
    const brF       = document.getElementById('brand-filter').value;
    const srch      = document.getElementById('search-box').value.toLowerCase();
    const insPaidF  = (document.getElementById('ins-paid-filter')  || {}).value || 'all';
    const supCostF  = (document.getElementById('sup-cost-filter')  || {}).value || 'all';
    const filterIns     = insF !== 'All Insurers';
    const insPaidRange  = parsePriceRange(insPaidF);
    const supCostRange  = parsePriceRange(supCostF);

    // Helper: does a value fall in a range?
    const inRange = (v, range) => {
        if (!range) return true;
        return v >= range.min && v <= range.max;
    };

    const match = new Set();

    for (const g of ndcGroups) {
        // ── STATUS filter: ALWAYS per-insurer when insurer is selected ──
        if (activeFilter !== 'all') {
            if (filterIns) {
                const insRow = g.insurerRows.find(r => (r.insName || '').trim().toLowerCase() === insF);
                if (!insRow) continue;
                const d   = g.totalPurchaseQty - insRow.qty;
                const st  = d === 0 ? 'ok' : d > 0 ? 'over' : 'short';
                if (st !== activeFilter) continue;
            } else {
                if (g.status !== activeFilter) continue;
            }
        }

        // ── INSURER filter ──
        if (filterIns && !g.insurerRows.some(r => (r.insName || '').trim().toLowerCase() === insF)) continue;

        // ── DRUG FORM / BRAND filters ──
        if (frmF !== 'All Drug Forms' && g.drugForm !== frmF) continue;
        if (brF === 'Brand: Y' && g.brand !== 'Y') continue;
        if (brF === 'Brand: N' && g.brand !== 'N') continue;

        // ── INS PAID range filter ──
        if (insPaidRange) {
            // When insurer filtered: use that insurer's paid amount
            const paid = filterIns
                ? (g.insurerRows.find(r => (r.insName||'').trim().toLowerCase() === insF) || {}).insPaid || 0
                : g.totalInsPaid || 0;
            if (!inRange(paid, insPaidRange)) continue;
        }

        // ── SUPPLY COST range filter ──
        if (supCostRange && !inRange(g.totalSupplyCost || 0, supCostRange)) continue;

        // ── SEARCH filter ──
        if (srch) {
            const normSrch = normalizeNDCSearch(srch);
            if (!g.description.toLowerCase().includes(srch) && !g.ndc.includes(normSrch) && !g.ndc.includes(srch)) continue;
        }

        // ── NABP filter ──
        if (nabpFilterActive && !g.isNonNabp) continue;

        match.add(g.ndc);
    }

    filteredRows = allRows.filter(row => {
        if (!match.has(row.ndc)) return false;
        if (filterIns) {
            if (row.type === 'total') return false;
            if ((row.insName || '').trim().toLowerCase() !== insF) return false;
        }
        return true;
    });

    if (typeof emCacheRows === 'function') emCacheRows('results', filteredRows);
    renderTable();
    renderSummary(match, filterIns ? insF : null);
}

function renderTable() {
    // Render headers in current column order first
    colRenderHeader();
    // Invalidate keyboard nav grid cache — table is about to change
    if (typeof _invalidateGridCache === 'function') _invalidateGridCache();
    const tbody = document.getElementById('table-body');
    const srch  = document.getElementById('search-box').value.toLowerCase();
    const srchN = normalizeNDCSearch(srch); // normalized for NDC matching
    if (!filteredRows.length) {
        tbody.innerHTML = `<tr><td colspan="10" class="empty-state">No records match the current filters.</td></tr>`;
        return;
    }
    const frag = document.createDocumentFragment();
    let sr = 0, curNDC = null;
    for (const row of filteredRows) {
        if (row.ndc !== curNDC) { curNDC = row.ndc; sr = 1; } else sr++;
        const tr  = document.createElement('tr');
        // For total rows: packageSize is '' (empty) so fall back to ndcGroup.packageSize
        const pkg = parseFloat(row.packageSize) > 0
            ? parseFloat(row.packageSize)
            : parseFloat(row.ndcGroup && row.ndcGroup.packageSize || 0);

        const grp      = row.ndcGroup;
        const supTrans = (typeof supTransactions !== 'undefined' && supTransactions[grp.ndc]) || [];
        // encTip: encode for HTML attribute — applied ONCE at data-tip= site
        const encTip = s => s.replace(/&/g,'&amp;').replace(/"/g,'&quot;');
        // mkTip: produce raw JSON string (no encoding — encTip applied at usage)
        const mkTip = obj => JSON.stringify(obj);

        // NDC
        // Sort insurer rows by qty for top insurer
        const _sortedIns = [...grp.insurerRows].sort((a,b) => b.qty - a.qty);
        const ndcTip = mkTip({
            type:             'ndc',
            ndc:              grp.ndc,
            desc:             grp.description || '',
            form:             grp.drugForm || '',
            brand:            grp.brand || '',
            pkg:              pkg || grp.packageSize || 0,
            pkgSrc:           grp.pkgSrc || '',
            status:           grp.status,
            diff:             grp.diff || 0,
            nabp:             grp.isNonNabp ? (grp.nonNabpSources||[]).join(', ') : '',
            totalRxQty:       grp.totalRxQty || 0,
            totalPurchaseQty: grp.totalPurchaseQty || 0,
            totalInsPaid:     grp.totalInsPaid || 0,
            totalSupplyCost:  grp.totalSupplyCost || 0,
            dollarDiff:       grp.dollarDiff || 0,
            unitPrice:        grp.unitPrice || 0,
            insurerCount:     grp.insurerRows.length,
            topInsurer:       _sortedIns.length ? (_sortedIns[0].insName || '') : '',
            topInsurerQty:    _sortedIns.length ? (_sortedIns[0].qty || 0) : 0,
        });

        // Filled Qty
        const filledTip = mkTip({
            type:  'filled',
            total: grp.totalRxQty,
            pkg:   pkg,
            rows:  grp.insurerRows.map(ins => ({ name: ins.insName||'Unknown', qty: ins.qty })),
        });

        // Purchased Qty
        const purchTip = mkTip({
            type:  'purchased',
            total: grp.totalPurchaseQty,
            pkg:   pkg,
            rows:  supTrans.map(t => ({ file: t.file, qty: t.qty, sz: t.sz, total: t.total })),
        });

        // Ins Paid
        const insPaidTip = mkTip({
            type:  'insPaid',
            total: grp.totalInsPaid || 0,
            rows:  grp.insurerRows.map(ins => ({ name: ins.insName||'Unknown', paid: ins.insPaid||0, qty: ins.qty, bins: ins.binNo||'' })),
        });

        // Ins Paid (detail row — single insurer)
        const insDetailTip = mkTip({
            type:  'insDetail',
            name:  row.insName || 'Unknown',
            bin:   row.binNo || '—',
            qty:   row.rxQty || 0,
            paid:  row.insPaidRow || 0,
            diff:  row.diff || 0,
            totalPurchased: grp.totalPurchaseQty,
        });

        // Supply Cost
        const supCostTip = mkTip({
            type:      'supCost',
            total:     grp.totalSupplyCost || 0,
            unitPrice: grp.unitPrice || 0,
            dollarDiff:grp.dollarDiff || 0,
            insPaid:   grp.totalInsPaid || 0,
            rows:      supTrans.map(t => ({ file: t.file, qty: t.qty, sz: t.sz })),
        });

        // ── Build cells as a map, then render in column order ──
        const insTip = mkTip({
            type:  'insDetail',
            name:  row.insName || 'Unknown',
            bin:   row.binNo   || '—',
            qty:   row.rxQty   || 0,
            paid:  row.insPaidRow || 0,
            diff:  row.diff || 0,
            totalPurchased: grp.totalPurchaseQty,
        });
        const h = row.isHL;
        const isTotal = row.type === 'total';

        // Cell HTML per column key
        const CELLS = {
            sr:          () => `<td class="sr-cell">${sr}</td>`,
            description: () => isTotal
                ? `<td class="col-desc">${descCellHtml(row.drgName || row.description, row.strong, row.form, srch, row.ndc)}${grp.isNonNabp ? `<span class="nabp-badge" title="Purchased from non-NABP: ${grp.nonNabpSources.join(', ')}">🏥 Non-NABP</span>` : ''}</td>`
                : `<td class="col-desc">${descCellHtml(row.drgName || row.description, row.strong, row.form, srch, row.ndc)}</td>`,
            ndc:         () => `<td class="ndc-plain tt-cell nav-cell" tabindex="0" onclick="cellClick(this,event);copyText('${row.ndc}')" data-tip="${encTip(ndcTip)}">${row.ndc}</td>`,
            packageSize: () => isTotal ? '<td></td>' : `<td class="qty-cell">${row.packageSize ? row.packageSize.toFixed(3) : ''}</td>`,
            insName:     () => isTotal ? '<td></td>' : `<td class="${h ? 'hl-ins' : ''}">${srch ? hlText(escHtml(row.insName), srch) : escHtml(row.insName)}</td>`,
            binNo:       () => isTotal ? '<td></td>' : `<td class="${h ? 'hl-bin' : ''}" style="white-space:nowrap;font-family:'Courier New',monospace;font-size:11px">${formatBinChips(row.binNo, h)}</td>`,
            rxQty:       () => `<td class="qty-cell${!isTotal && h ? ' hl-qty' : ''} tt-cell nav-cell" onclick="cellClick(this,event)" tabindex="0" data-tip="${encTip(filledTip)}">${qtyDisp(row.rxQty, pkg)}</td>`,
            purchaseQty: () => `<td class="qty-cell tt-cell nav-cell" onclick="cellClick(this,event)" tabindex="0" data-tip="${encTip(purchTip)}">${qtyDisp(row.purchaseQty, pkg)}</td>`,
            diff:        () => isTotal ? '<td></td>' : `<td class="diff-cell">${diffHtmlFn(row.diff, pkg)}</td>`,
            status:      () => isTotal
                ? `<td>${statusHtmlFn(row.diff, pkg)}</td>`
                : `<td class="col-stat" style="font-size:11px;font-weight:600">${row.diff === 0 ? '<span class="di-ok" style="font-size:15px">✔</span>' : row.diff > 0 ? '' : `<span style="color:#dc2626;font-size:10px">-(${fmt(Math.abs(row.diff))})</span>`}</td>`,
            insPaid:     () => isTotal
                ? `<td class="price-cell tt-cell nav-cell" onclick="cellClick(this,event)" tabindex="0" data-tip="${encTip(insPaidTip)}">${fmtDCell(row.totalInsPaid,'#059669')}</td>`
                : `<td class="price-cell tt-cell nav-cell" onclick="cellClick(this,event)" tabindex="0" data-tip="${encTip(insTip)}">${row.insPaidRow > 0 ? fmtDCell(row.insPaidRow,'#059669') : '<span style="color:#e2e8f0">—</span>'}</td>`,
            supplyCost:  () => `<td class="price-cell tt-cell nav-cell" onclick="cellClick(this,event)" tabindex="0" data-tip="${encTip(supCostTip)}">${fmtDCell(grp.totalSupplyCost||0,'var(--rxa-primary,#7c3aed)')}</td>`,
        };

        if (isTotal) tr.className = `row-total status-${row.status}`;
        else         tr.className = 'row-detail';

        // Render cells in current column order
        tr.innerHTML = colOrdered().map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('');
        frag.appendChild(tr);
    }
    tbody.innerHTML = '';
    tbody.appendChild(frag);
    // Wire tooltips for all tt-cell elements
    tbody.querySelectorAll('.tt-cell').forEach(el => {
        el.addEventListener('mouseenter', ttShow);
        el.addEventListener('mouseleave', ttHide);
        el.addEventListener('mousemove',  ttMove);
    });
}

function renderSummary(filteredNdcSet, insFilter) {
    // Use filtered set if provided (after filters applied), else all NDCs
    const visGroups = filteredNdcSet
        ? ndcGroups.filter(g => filteredNdcSet.has(g.ndc))
        : ndcGroups;

    // When insurer is filtered, compute status per-insurer not per-NDC
    // insFilter passed from applyFilters when an insurer is selected
    const getStatus = (g) => {
        if (!insFilter) return g.status;
        const insRow = g.insurerRows.find(r => (r.insName || '').trim().toLowerCase() === insFilter);
        if (!insRow) return g.status;
        const d = g.totalPurchaseQty - insRow.qty;
        return d === 0 ? 'ok' : d > 0 ? 'over' : 'short';
    };
    const ok = visGroups.filter(g => getStatus(g) === 'ok').length;
    const ov = visGroups.filter(g => getStatus(g) === 'over').length;
    const sh = visGroups.filter(g => getStatus(g) === 'short').length;
    const total = visGroups.length;

    const totalSupplyCost = visGroups.reduce((s, g) => s + (g.totalSupplyCost || 0), 0);
    const totalInsPaid    = visGroups.reduce((s, g) => s + (g.totalInsPaid    || 0), 0);
    const totalRxQty      = visGroups.reduce((s, g) => s + (g.totalRxQty      || 0), 0);
    const totalPurchQty   = visGroups.reduce((s, g) => s + (g.totalPurchaseQty|| 0), 0);

    // Match rate always from ALL data (not filtered) — it's a data quality metric
    const billedNdcs = new Set(billingRows.map(r => r.ndc));
    const supNdcs    = new Set(Object.keys(purchaseMap));
    const matched    = [...supNdcs].filter(n => billedNdcs.has(n)).length;
    const matchRate  = supNdcs.size > 0 ? Math.round((matched / supNdcs.size) * 100) : 0;
    const matchColor = matchRate >= 60 ? 'var(--ok)' : matchRate >= 30 ? 'var(--over)' : 'var(--short)';

    // Date range warning — always global
    let dateWarn = '';
    const allRanges = Object.values(parseStats).filter(s => s.dateRange);
    if (allRanges.length > 1) {
        const supRanges  = allRanges.filter(s => s.type === 'supplier');
        const billRanges = allRanges.filter(s => s.type === 'billing');
        if (supRanges.length && billRanges.length) {
            const supMin  = Math.min(...supRanges.map(s => s.dateRange.min.getTime()));
            const supMax  = Math.max(...supRanges.map(s => s.dateRange.max.getTime()));
            const billMin = Math.min(...billRanges.map(s => s.dateRange.min.getTime()));
            const billMax = Math.max(...billRanges.map(s => s.dateRange.max.getTime()));
            if (!(supMin <= billMax && billMin <= supMax))
                dateWarn = `<div class="summary-pill" style="background:#fee2e2;color:#991b1b" title="Date ranges don't overlap">⚠️ Date mismatch</div>`;
        }
    }

    // Is any filter active? Show "filtered" badge
    const isFiltered = filteredNdcSet && filteredNdcSet.size < ndcGroups.length;
    const filteredBadge = isFiltered
        ? `<div class="summary-pill" style="background:#fef3c7;border-color:#fcd34d;color:#92400e;font-size:10.5px">⚡ Filtered: ${total} of ${ndcGroups.length} NDCs</div>`
        : `<div class="summary-pill" style="color:var(--text-muted)">Total NDCs: <strong>${total}</strong></div>`;

    const fmtDS = v => v > 0 ? '$' + v.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}) : '—';

    document.getElementById('summary-bar').innerHTML =
        `<div class="summary-pill"><div class="pill-dot ok"></div><span>OK: <strong class="pill-count">${ok}</strong></span></div>`
      + `<div class="summary-pill"><div class="pill-dot over"></div><span>Over: <strong class="pill-count">${ov}</strong></span></div>`
      + `<div class="summary-pill"><div class="pill-dot short"></div><span>Short: <strong class="pill-count">${sh}</strong></span></div>`
      + filteredBadge
      + `<div class="summary-pill" style="margin-left:4px;color:${matchColor}" title="Supplier NDCs also found in billing">`
      +   `Match rate: <strong>${matchRate}%</strong> (${matched}/${supNdcs.size})</div>`
      + `<div class="summary-pill" style="background:#f5f3ff;border-color:#ddd6fe;margin-left:auto">Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtDS(totalSupplyCost)}</strong></div>`
      + `<div class="summary-pill" style="background:#f0fdf4;border-color:#bbf7d0">Ins Paid: <strong style="color:#059669">${fmtDS(totalInsPaid)}</strong></div>`
      + (nabpFilterActive ? `<div class="summary-pill" style="background:#fef2f2;border-color:#fca5a5;color:#991b1b;font-weight:700">🏥 Non-NABP: ${visGroups.filter(g=>g.isNonNabp).length} NDCs</div>` : (visGroups.some(g=>g.isNonNabp) ? `<div class="summary-pill" style="background:#fef2f2;border-color:#fca5a5;color:#991b1b;font-size:11px" title="Click 🏥 Non-NABP Only to filter">⚠️ ${visGroups.filter(g=>g.isNonNabp).length} non-NABP NDCs</div>` : ''))
      + dateWarn;

    document.getElementById('ndc-count-label').textContent =
        isFiltered ? `Showing: ${total} NDCs (filtered)` : `Showing: ${total} NDCs`;
}

function setFilter(s, btn) {
    activeFilter = s;
    document.querySelectorAll('#status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    applyFilters();
}

function sortBy(field) {
    if (sortCol === field) sortDir *= -1; else { sortCol = field; sortDir = 1; }
    ndcGroups.sort((a, b) => { const av = a[field], bv = b[field]; if (typeof av === 'string') return sortDir * av.localeCompare(bv); return sortDir * ((av || 0) - (bv || 0)); });
    buildAllRows();
    applyFilters();
}
// Determines a ROW's own reconciliation category from its own diff value —
// this is what the Reconciliation/Status column actually displays for that
// specific row, which can differ from the row's NDC group's overall status
// (a group can net to "ok" while one insurer within it is short and another
// is over — sorting by group status alone doesn't cluster what's on screen).
function rowStatusRank(row, orderKey) {
    const st = row.diff === 0 ? 'ok' : row.diff > 0 ? 'over' : 'short';
    return statusRank(st, orderKey);
}

function sortByPreset(field, dir) {
    sortCol = field; sortDir = (typeof dir === 'string') ? 1 : dir;
    if ((field === 'status' || field === 'diff') && typeof dir === 'string') {
        // Group-level pass first (keeps things reasonable before the row-level pass)
        ndcGroups.sort((a, b) => statusRank(a.status, dir) - statusRank(b.status, dir));
        buildAllRows();
        applyFilters();
        // Row-level pass — sorts by what's actually shown in this specific column
        // for each displayed row. Note: for NDCs with multiple insurers, this can
        // separate that NDC's own rows from each other (one insurer's row may be
        // OK while another is Short), since the column is a per-row value.
        filteredRows.sort((a, b) => rowStatusRank(a, dir) - rowStatusRank(b, dir));
        renderTable();
        if (typeof colRenderHeader === 'function') colRenderHeader();
        return;
    }
    if (field === 'insName') {
        // insName isn't a scalar on ndcGroups (it varies per insurer within one
        // NDC) — same structural situation as status/diff above, so sort the
        // actual displayed rows directly instead of trying to sort ndcGroups
        // by a property it doesn't have (which was previously a silent no-op).
        buildAllRows();
        applyFilters();
        filteredRows.sort((a, b) => sortDir * String(a.insName || '').localeCompare(String(b.insName || '')));
        renderTable();
        if (typeof colRenderHeader === 'function') colRenderHeader();
        return;
    }
    ndcGroups.sort((a, b) => { const av = a[field], bv = b[field]; if (typeof av === 'string') return sortDir * av.localeCompare(bv); return sortDir * ((av || 0) - (bv || 0)); });
    buildAllRows();
    applyFilters();
    if (typeof colRenderHeader === 'function') colRenderHeader();
}

// ── Quick Sort buttons ─────────────────────────────────────
let activeQuickSort = 'description';

function quickSort(mode, btn) {
    activeQuickSort = mode;

    // Highlight active button
    document.querySelectorAll('.qs-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');

    // Sort ndcGroups based on mode
    switch (mode) {
        case 'description':
            ndcGroups.sort((a, b) => a.description.localeCompare(b.description));
            break;
        case 'ok':
        case 'over':
        case 'short': {
            // When insurer is filtered: sort by that insurer's status, else NDC-level status
            const insF = document.getElementById('ins-filter').value;
            const filterIns = insF !== 'All Insurers';
            const getGrpStatus = (g) => {
                if (!filterIns) return g.status;
                const ins = g.insurerRows.find(r => (r.insName||'').trim().toLowerCase() === insF);
                if (!ins) return g.status;
                const d = g.totalPurchaseQty - ins.qty;
                return d === 0 ? 'ok' : d > 0 ? 'over' : 'short';
            };
            const order = mode === 'ok'    ? {ok:0,over:1,short:2}
                        : mode === 'over'  ? {over:0,ok:1,short:2}
                        :                   {short:0,ok:1,over:2};
            ndcGroups.sort((a, b) => {
                const sa = getGrpStatus(a), sb = getGrpStatus(b);
                const sd = (order[sa]||0) - (order[sb]||0);
                if (sd !== 0) return sd;
                if (mode === 'over')  return b.totalPurchaseQty - a.totalPurchaseQty;
                if (mode === 'short') return a.diff - b.diff;
                return a.description.localeCompare(b.description);
            });
            break;
        }
        case 'highest':
            ndcGroups.sort((a, b) => b.totalRxQty - a.totalRxQty);
            break;
        case 'lowest':
            ndcGroups.sort((a, b) => a.totalRxQty - b.totalRxQty);
            break;
        case 'mostFilled':
            ndcGroups.sort((a, b) => b.totalRxQty - a.totalRxQty);
            break;
        case 'mostPurchased':
            ndcGroups.sort((a, b) => b.totalPurchaseQty - a.totalPurchaseQty);
            break;
        case 'ndc':
            ndcGroups.sort((a, b) => a.ndc.localeCompare(b.ndc));
            break;

        case 'insPaidDesc':
            ndcGroups.sort((a, b) => (b.totalInsPaid || 0) - (a.totalInsPaid || 0));
            break;
        case 'insPaidAsc':
            ndcGroups.sort((a, b) => (a.totalInsPaid || 0) - (b.totalInsPaid || 0));
            break;
        case 'supCostDesc':
            ndcGroups.sort((a, b) => (b.totalSupplyCost || 0) - (a.totalSupplyCost || 0));
            break;
        case 'supCostAsc':
            ndcGroups.sort((a, b) => (a.totalSupplyCost || 0) - (b.totalSupplyCost || 0));
            break;
    }

    buildAllRows();
    applyFilters();
}

function resetResultsFilters() {
    activeFilter = 'all';
    document.querySelectorAll('#status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('#status-filters .filter-btn.all').classList.add('active');
    document.getElementById('ins-filter').value = 'All Insurers';
    document.getElementById('form-filter').value = 'All Drug Forms';
    const bf = document.getElementById('brand-filter');
    if (bf) bf.selectedIndex = 0;
    const ipf = document.getElementById('ins-paid-filter');
    if (ipf) ipf.value = 'all';
    const scf = document.getElementById('sup-cost-filter');
    if (scf) scf.value = 'all';
    document.getElementById('search-box').value = '';
    globalNDCSearch = '';
    nabpFilterActive = false;
    const nabpBtn = document.getElementById('nabp-filter-btn');
    if (nabpBtn) nabpBtn.classList.remove('active');
    quickSort('description');
}

// ════════════════════════════════════
//  RAW PREVIEW TAB
// ════════════════════════════════════

function rawGlobalSearchFn(v) {
    rawGlobalSearch = v.trim();
    // Sync to per-file searches too
    renderRawPreview();
}

// ── Normalize for search: strip dashes, spaces, ="..." wrappers ──
function rawNorm(s) {
    return String(s || '').replace(/^="?(.*?)"?$/, '$1').replace(/[-\s.]/g, '').toLowerCase();
}
// ── Check if a search term matches a cell value ──
function rawCellMatch(cell, term) {
    const c = String(cell || '').toLowerCase();
    const t = term.toLowerCase();
    if (c.includes(t)) return true;
    // NDC normalization (strip dashes/spaces/dots)
    const cn = rawNorm(c), tn = rawNorm(t);
    if (cn && tn && cn.includes(tn)) return true;
    return false;
}
// ── Check if ANY cell in a row matches ALL terms ──
function rawRowMatches(cells, terms) {
    if (!terms.length) return true;
    // Each term must match at least one cell in the row
    return terms.every(term =>
        cells.some(cell => rawCellMatch(cell, term))
    );
}

const RAW_PAGE = 200; // rows to show per page
let rawPageMap = {}; // bid → current page index

function renderRawPreview() {
    const container = document.getElementById('raw-content');
    if (!rawPreviewData.length) {
        container.innerHTML = `<div class="placeholder-tab"><div class="icon">📄</div><span>No raw data available.</span></div>`;
        return;
    }

    let html = '';

    // ── Parse summary cards ──
    const allStats = Object.entries(parseStats);
    if (allStats.length) {
        html += `<div class="parse-summary-grid">`;
        for (const [fname, st] of allStats) {
            const short = fname.length > 38 ? fname.slice(0, 35) + '…' : fname;
            const typeLabel = st.type === 'billing' ? '🧾 Billing' : '📦 Supplier';
            const typeColor = st.type === 'billing' ? '#1e40af' : 'var(--rxa-primary-700,#5b21b6)';
            const typeBg    = st.type === 'billing' ? '#dbeafe' : '#ede9fe';
            const warns = [];
            if ((st.returns   ||0) > 0) warns.push(`<span class="psc-warn">⚠ ${st.returns} return${st.returns>1?'s':''} excluded</span>`);
            if ((st.dummyNDC  ||0) > 0) warns.push(`<span class="psc-warn">⚠ ${st.dummyNDC} dummy NDC${st.dummyNDC>1?'s':''} skipped</span>`);
            if ((st.zeroDoseExt||0)> 0) warns.push(`<span class="psc-info">ℹ ${st.zeroDoseExt} used billing pkg size</span>`);
            if ((st.dupRx     ||0) > 0) warns.push(`<span class="psc-warn">⚠ ${st.dupRx} duplicate Rx#</span>`);
            const dateStr = st.dateRange ? `<span class="psc-date">📅 ${escHtml(st.dateRange.label)}</span>` : '';
            html += `<div class="parse-summary-card">
                <div class="psc-header">
                    <span class="psc-type" style="background:${typeBg};color:${typeColor}">${typeLabel}</span>
                    <span class="psc-fname" title="${escHtml(fname)}">${escHtml(short)}</span>
                </div>
                <div class="psc-stats">
                    <span class="psc-stat"><strong>${(st.rows||0).toLocaleString()}</strong> rows parsed</span>
                    <span class="psc-stat" style="color:#9ca3af"><strong>${(st.skipped||0).toLocaleString()}</strong> skipped</span>
                    ${dateStr}
                </div>
                ${warns.length ? `<div class="psc-warns">${warns.join('')}</div>` : ''}
            </div>`;
        }
        html += `</div>`;
    }

    // ── Per-file tables ──
    rawPreviewData.forEach((fd, idx) => {
        const bid       = 'raw_' + idx;
        const short     = fd.fileName.length > 55 ? fd.fileName.slice(0, 52) + '…' : fd.fileName;
        const isCol     = rawCollapsed[bid] || false;
        const sheetPart = fd.sheetName
            ? `<span class="raw-hitem"><span class="raw-hkey">Sheet:</span><span class="raw-hval">${escHtml(fd.sheetName)}</span></span>`
            : '';
        const perSearch = rawSearchTerms[bid] || '';
        const typeLabel = fd.type === 'billing' ? '🧾 Billing' : '📦 Supplier';
        const typeBg    = fd.type === 'billing' ? '#dbeafe' : '#ede9fe';
        const typeColor = fd.type === 'billing' ? '#1e40af' : 'var(--rxa-primary-700,#5b21b6)';

        html += `<div class="raw-block" id="${bid}">
            <div class="raw-header">
                <div class="raw-header-left">
                    <span class="psc-type" style="background:${typeBg};color:${typeColor};font-size:10.5px;padding:1px 7px;">${typeLabel}</span>
                    <span class="raw-hitem"><span class="raw-hval filename" title="${escHtml(fd.fileName)}">${escHtml(short)}</span></span>
                    ${sheetPart}
                    <span class="raw-hitem"><span class="raw-hkey">Header row:</span><span class="raw-hval">${fd.headerRow}</span></span>
                    <span class="raw-hitem"><span class="raw-hkey">Total:</span><span class="raw-hval">${fd.totalRows.toLocaleString()} rows</span></span>
                    <span class="raw-hitem"><span class="raw-hkey">Cols:</span><span class="raw-hval">${fd.headers.length}</span></span>
                </div>
                <div class="raw-header-right">
                    <input class="raw-search" id="rs_${bid}"
                        placeholder="Search this file… (NDC, drug, insurer)"
                        value="${escHtml(perSearch)}"
                        oninput="rawSearchFile('${bid}',this.value)"
                        onkeydown="if(event.key==='Escape'){rawSearchFile('${bid}','');this.value='';}">
                    <button class="raw-btn" onclick="exportRawCSV(${idx})" title="Export this file's preview as CSV">⬇ CSV</button>
                    <div class="raw-collapse-btn" onclick="toggleRawCollapse('${bid}')" title="${isCol?'Expand':'Collapse'}">${isCol ? '▶' : '▼'}</div>
                </div>
            </div>`;

        if (!isCol) {
            // Build combined search terms: global + per-file (both must match)
            const terms = [
                ...rawGlobalSearch.trim().split(/\s+/).filter(Boolean),
                ...perSearch.trim().split(/\s+/).filter(Boolean)
            ].filter(Boolean);

            // Filter rows — all terms must match (AND logic), any cell can match each term
            const allRows    = fd.rows;
            const matched    = allRows.filter(cells => rawRowMatches(cells, terms));
            const page       = rawPageMap[bid] || 0;
            const totalMatch = matched.length;
            const pageStart  = page * RAW_PAGE;
            const pageEnd    = Math.min(pageStart + RAW_PAGE, totalMatch);
            const pageRows   = matched.slice(pageStart, pageEnd);
            const totalPages = Math.ceil(totalMatch / RAW_PAGE);

            // Search result info bar
            const infoBar = terms.length
                ? `<div class="raw-search-info">
                    ${totalMatch === 0
                        ? `<span style="color:#dc2626">⚠ No rows match "${escHtml(terms.join(' '))}"</span>`
                        : `<span style="color:#059669">✓ ${totalMatch.toLocaleString()} rows match</span>
                           <span style="color:#6b7280">· showing ${pageStart+1}–${pageEnd}</span>`}
                   </div>`
                : totalMatch > RAW_PAGE
                    ? `<div class="raw-search-info"><span style="color:#6b7280">Showing ${pageStart+1}–${pageEnd} of ${totalMatch.toLocaleString()} rows · search to filter</span></div>`
                    : '';

            // ── Interactive column remapping UI ──
            let mappingHtml = '';
            if (fd.mappingIdx) {
                const m   = fd.mappingIdx;
                const ov  = (typeof columnOverrides !== 'undefined') ? (columnOverrides[fd.fileName] || {}) : {};
                const hdrs = fd.headers;
                // NOTE: this used to be embedded directly into the onchange="..." attribute
                // as JSON.stringify(fd.fileName) — but that produces a string wrapped in
                // literal double-quote characters, which collided with the double-quoted
                // HTML attribute itself. The HTML parser saw the embedded quote as closing
                // the attribute early, silently truncating onchange to "setColOverride("
                // for every dropdown, every file, every time — remapping never actually
                // worked. Using a data-* attribute (safely HTML-escaped) avoids this whole
                // class of bug entirely.

                // Fields to show per file type
                const fieldDefs = fd.type === 'billing'
                    ? [ { key:'ndc',  label:'NDC',     idx: ov.ndc  ?? m.ndc },
                        { key:'qty',  label:'Qty',     idx: ov.qty  ?? m.qty },
                        { key:'ins',  label:'Insurer', idx: ov.ins  ?? m.ins },
                        { key:'bin',  label:'BIN',     idx: ov.bin  ?? m.bin },
                        { key:'date', label:'Date',    idx: ov.date ?? m.date }, ]
                    : [ { key:'ndc',      label:'NDC',      idx: ov.ndc      ?? m.ndc },
                        { key:'qty',      label:'Qty',      idx: ov.qty      ?? m.qty },
                        { key:'desc',     label:'Desc',     idx: ov.desc     ?? m.desc },
                        { key:'size',     label:'Pkg Size', idx: ov.size     ?? m.size },
                        { key:'date',     label:'Date',     idx: ov.date     ?? (m.date ?? -1) },
                        { key:'extPrice', label:'Ext Price',idx: ov.extPrice ?? (m.extPrice ?? -1) }, ];

                const hasOverride = Object.keys(ov).length > 0;
                const optionsHtml = ['<option value="-1">(none)</option>',
                    ...hdrs.map((h,i) => `<option value="${i}">${i}: ${escHtml(h)}</option>`)].join('');

                const dropdowns = fieldDefs.map(f => {
                    const isOverridden = ov[f.key] != null;
                    const val = f.idx >= 0 ? f.idx : -1;
                    const headerLabel = f.idx >= 0 ? escHtml(hdrs[f.idx] || '?') : 'not detected';
                    return `<div class="remap-field${isOverridden ? ' remap-overridden' : ''}">
                        <label class="remap-label">${f.label}</label>
                        <select class="remap-select" data-filename="${escHtml(fd.fileName)}" data-field="${escHtml(f.key)}" onchange="setColOverrideFromSelect(this)" title="Column mapped to ${f.label}">
                            ${optionsHtml.replace(`value="${val}"`, `value="${val}" selected`)}
                        </select>
                        <span class="remap-col-hint">${isOverridden ? '✏️ ' : ''}${headerLabel}</span>
                    </div>`;
                }).join('');

                mappingHtml = `<div class="raw-mapping-wrap">
                    <div class="remap-header">
                        <span class="remap-title">🔗 Column Mapping ${hasOverride ? '<span class="remap-custom-badge">Custom</span>' : '<span class="remap-auto-badge">Auto-detected</span>'}</span>
                        ${hasOverride ? `<button class="remap-reset-btn" data-filename="${escHtml(fd.fileName)}" onclick="resetFileMapping(this)"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Reset to auto</button>` : ''}
                        <span class="remap-hint">Change any field to re-run reconciliation with the new mapping</span>
                    </div>
                    <div class="remap-fields">${dropdowns}</div>
                </div>`;
            }

            html += mappingHtml + infoBar;
            html += `<div class="raw-table-wrap"><table class="raw-table">
                <thead><tr>
                    <th style="width:48px;text-align:center;font-size:10.5px">#</th>
                    ${fd.headers.map((h,ci) => {
                        const isKey = fd.mappingIdx && Object.values(fd.mappingIdx).includes(ci);
                        return `<th style="${isKey?'background:#f0fdf4;color:#15803d;':''}">${escHtml(h)}</th>`;
                    }).join('')}
                </tr></thead>
                <tbody>`;

            if (pageRows.length === 0) {
                html += `<tr><td colspan="${fd.headers.length + 1}" style="text-align:center;padding:24px;color:#9ca3af;">
                    ${terms.length ? 'No matching rows. Try a different search term.' : 'No data rows available.'}
                </td></tr>`;
            } else {
                for (let i = 0; i < pageRows.length; i++) {
                    const cells    = pageRows[i];
                    const origIdx  = allRows.indexOf(cells);
                    html += `<tr>`;
                    html += `<td style="text-align:center;color:var(--text-muted);font-size:10px">${origIdx + 1}</td>`;
                    for (let j = 0; j < fd.headers.length; j++) {
                        const cellVal = String(cells[j] || '');
                        const isKey   = fd.mappingIdx && Object.values(fd.mappingIdx).includes(j);
                        // Highlight all matched terms
                        let display = escHtml(cellVal);
                        for (const term of terms) {
                            display = hlText(display, term);
                            // Also highlight NDC-normalized version
                            if (/^\d{8,13}$/.test(rawNorm(term))) display = hlText(display, term.replace(/-/g,''));
                        }
                        html += `<td title="${escHtml(cellVal)}" style="${isKey?'background:#f0fdf4;font-weight:600;':''}">${display}</td>`;
                    }
                    html += `</tr>`;
                }
            }
            html += `</tbody></table></div>`;

            // Pagination
            if (totalPages > 1) {
                const prevDis = page === 0 ? 'disabled style="opacity:.4"' : '';
                const nextDis = page >= totalPages-1 ? 'disabled style="opacity:.4"' : '';
                html += `<div class="raw-pagination">
                    <button class="raw-btn" onclick="rawChangePage('${bid}',-1)" ${prevDis}>← Prev</button>
                    <span style="font-size:11px;color:#6b7280">Page ${page+1} of ${totalPages} · ${totalMatch.toLocaleString()} rows</span>
                    <button class="raw-btn" onclick="rawChangePage('${bid}',1)" ${nextDis}>Next →</button>
                </div>`;
            }
        }

        html += `</div>`; // raw-block
    });

    container.innerHTML = html;
}

function rawSearchFile(bid, val) {
    rawSearchTerms[bid] = val;
    rawPageMap[bid] = 0; // reset to first page on new search
    renderRawPreview();
    // Restore focus
    setTimeout(() => {
        const el = document.getElementById('rs_' + bid);
        if (el) { el.focus(); el.setSelectionRange(val.length, val.length); }
    }, 10);
}

function rawChangePage(bid, delta) {
    const fd       = rawPreviewData[parseInt(bid.replace('raw_',''))];
    if (!fd) return;
    const terms    = [rawGlobalSearch,...(rawSearchTerms[bid]||'').split(/\s+/)].filter(Boolean);
    const matched  = fd.rows.filter(cells => rawRowMatches(cells, terms));
    const total    = Math.ceil(matched.length / RAW_PAGE);
    rawPageMap[bid] = Math.max(0, Math.min((rawPageMap[bid]||0) + delta, total - 1));
    renderRawPreview();
    // Scroll to the block
    setTimeout(() => {
        const el = document.getElementById(bid);
        if (el) el.scrollIntoView({ behavior:'smooth', block:'start' });
    }, 30);
}

function toggleRawCollapse(bid) {
    rawCollapsed[bid] = !rawCollapsed[bid];
    renderRawPreview();
}

function exportRawCSV(idx) {
    const fd = rawPreviewData[idx];
    if (!fd) return;
    const escape = v => `"${String(v||'').replace(/"/g,'""')}"`;
    const lines  = [fd.headers.map(escape).join(',')];
    for (const r of fd.rows) lines.push(r.map(escape).join(','));
    const a  = document.createElement('a');
    a.href   = URL.createObjectURL(new Blob([lines.join('\n')], { type:'text/csv' }));
    a.download = fd.fileName.replace(/[^a-zA-Z0-9_.-]/g,'_') + '_preview.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
}
