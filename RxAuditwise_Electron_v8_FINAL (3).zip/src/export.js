// ════════════════════════════════════
//  EXPORT — RxAuditwise v4.2
// ════════════════════════════════════

let emActiveTab = 'results', emFmt = 'csv', emCols = [];
let emScope = 'current', emFmtAll = 'csv';
let emAllTabSel = new Set();

// ── Current-view cache ────────────────────────────────────────
// Each render function populates this so export always reflects
// what's currently shown on screen (filtered, sorted, PKG-aware).
// Keys match emActiveTab values. Each entry is an array of plain
// objects that emBuildData reads directly.
const _emViewCache = {};

// Called by render functions to register the current visible rows.
// meta (optional) carries extra context a render function needs to remember
// for export — e.g. MFP's active insurer filter, since the cached NDC groups
// alone don't say which of their insurer rows were actually shown on screen.
const _emViewMeta = {};
function emCacheRows(tab, rows, meta) { _emViewCache[tab] = rows; _emViewMeta[tab] = meta || null; }

const EM_ALL_TABS = [
    { key:'results',   label:'📋 Results'    },
    { key:'suppliers', label:'📦 Suppliers'  },
    { key:'final',     label:'✅ Final'      },
    { key:'bill',      label:'💵 Bill'       },
    { key:'dollar',    label:'💲 Dollar'     },
    { key:'discarded', label:'🗑️ Discarded'  },
    { key:'notbilled', label:'⚠️ Not Billed' },
    { key:'issues',    label:'🔴 Issues'     },
    { key:'mfp',       label:'📋 MFP'        },
];

// ── Row count helpers ────────────────────────────────────
function emCountRows(tab) {
    try {
        // Use cache (current filtered view) when available
        if (_emViewCache[tab]) {
            const c = _emViewCache[tab];
            if (tab === 'results') return c.filter(r => r.type === 'total').length;
            return c.length;
        }
        // Fallback to full data counts
        if (tab === 'results')   return filteredRows.filter(r => r.type === 'total').length;
        if (tab === 'suppliers') return Object.keys(purchaseMap).length;
        if (tab === 'final')     return ndcGroups.length;
        if (tab === 'bill')      return [...new Set(ndcGroups.flatMap(g => g.insurerRows.map(r => r.insName)))].length;
        if (tab === 'discarded') { const s = new Set(Object.keys(purchaseMap)); return [...new Set(billingRows.filter(r => !s.has(r.ndc)).map(r => r.ndc))].length; }
        if (tab === 'issues')    return ndcGroups.filter(g => g.status === 'short').length;
        if (tab === 'notbilled') { const b = new Set(billingRows.map(r => r.ndc)); return Object.keys(purchaseMap).filter(n => !b.has(n)).length; }
        if (tab === 'mfp')       return ndcGroups.filter(g => MFP_NDCS[g.ndc]).length;
        if (tab === 'dollar')    return ndcGroups.length;
    } catch(e) {}
    return 0;
}

// ── Open modal ───────────────────────────────────────────
function openExportModal(tab) {
    emActiveTab = tab;
    emFmt       = 'csv';
    emScope     = 'current';
    emFmtAll    = 'csv';
    emAllTabSel = new Set(EM_ALL_TABS.map(t => t.key));
    emCols      = (EM_COLS[tab] || EM_COLS.results).map(c => ({ ...c }));

    // Reset scope buttons
    document.querySelectorAll('.em-scope-btn').forEach(b => b.classList.remove('active'));
    const scCurrent = document.getElementById('em-scope-current');
    if (scCurrent) scCurrent.classList.add('active');

    // Show single / hide all
    const bodySingle = document.getElementById('em-body-single');
    const bodyAll    = document.getElementById('em-body-all');
    if (bodySingle) bodySingle.style.display = '';
    if (bodyAll)    bodyAll.style.display    = 'none';

    // Tab info
    document.getElementById('em-tab-info').textContent =
        `${EM_TAB_LABELS[tab] || tab} · ${emCountRows(tab)} rows`;

    // Format buttons — reset to CSV
    document.querySelectorAll('#em-fmt-grid .em-fmt').forEach(b => b.classList.remove('active'));
    const csvBtn = document.querySelector('#em-fmt-grid .em-fmt[data-fmt="csv"]');
    if (csvBtn) csvBtn.classList.add('active');

    document.querySelectorAll('#em-fmt-grid-all .em-fmt').forEach(b => b.classList.remove('active'));
    const csvAllBtn = document.querySelector('#em-fmt-grid-all .em-fmt[data-fmt="csv"]');
    if (csvAllBtn) csvAllBtn.classList.add('active');

    // File name + extension
    document.getElementById('em-fname').value = EM_DEFAULTS[tab] || 'NDC_Export';
    document.getElementById('em-ext').textContent = '.csv';

    emRenderCols();
    document.getElementById('export-overlay').style.display = 'flex';
}

function closeExportModal() {
    document.getElementById('export-overlay').style.display = 'none';
}

// ── Scope toggle ─────────────────────────────────────────
function emSetScope(scope, btn) {
    emScope = scope;
    document.querySelectorAll('.em-scope-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('em-body-single').style.display = scope === 'current' ? '' : 'none';
    document.getElementById('em-body-all').style.display    = scope === 'all'     ? '' : 'none';
    if (scope === 'all') emRenderAllTabsGrid();
    emUpdateFooter();
}

// ── Format buttons ───────────────────────────────────────
function emSetFmt(el) {
    emFmt = el.dataset.fmt;
    document.querySelectorAll('#em-fmt-grid .em-fmt').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    const extMap = { csv:'.csv', xlsx:'.xlsx', json:'.json', pdf:'.pdf' };
    document.getElementById('em-ext').textContent = extMap[emFmt] || '.csv';
    emUpdateFooter();
}

function emSetFmtAll(el) {
    emFmtAll = el.dataset.fmt;
    document.querySelectorAll('#em-fmt-grid-all .em-fmt').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    emUpdateFooter();
}

// ── Column grid ──────────────────────────────────────────
function emRenderCols() {
    const grid = document.getElementById('em-col-grid');
    if (!grid) return;
    grid.innerHTML = emCols.map((c, i) => `
        <div class="em-col-item${c.on ? ' on' : ''}" onclick="emToggleCol(${i})">
          <div class="em-checkbox">
            ${c.on ? '<svg width="9" height="7" viewBox="0 0 9 7" fill="none"><path d="M1 3.5L3.5 6L8 1" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : ''}
          </div>
          <span class="em-col-name">${c.label}</span>
        </div>`).join('');
    emUpdateFooter();
}

function emToggleCol(i) {
    emCols[i].on = !emCols[i].on;
    emRenderCols();
}

function emToggleAll() {
    const anyOff = emCols.some(c => !c.on);
    emCols.forEach(c => c.on = anyOff);
    emRenderCols();
}

// ── All-tabs grid ────────────────────────────────────────
function emRenderAllTabsGrid() {
    const grid = document.getElementById('em-all-tabs-grid');
    if (!grid) return;
    grid.innerHTML = EM_ALL_TABS.map(t => `
        <div class="em-col-item${emAllTabSel.has(t.key) ? ' on' : ''}"
             onclick="emToggleAllTab('${t.key}',this)"
             style="font-size:12px;padding:6px 8px;">
          <div class="em-checkbox">
            ${emAllTabSel.has(t.key) ? '<svg width="9" height="7" viewBox="0 0 9 7" fill="none"><path d="M1 3.5L3.5 6L8 1" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : ''}
          </div>
          <span class="em-col-name">${t.label}<br>
            <span style="font-size:10px;color:#9ca3af">${emCountRows(t.key)} rows</span>
          </span>
        </div>`).join('');
    emUpdateFooter();
}

function emToggleAllTab(key, el) {
    if (emAllTabSel.has(key)) emAllTabSel.delete(key);
    else emAllTabSel.add(key);
    el.classList.toggle('on', emAllTabSel.has(key));
    el.querySelector('.em-checkbox').innerHTML = emAllTabSel.has(key)
        ? '<svg width="9" height="7" viewBox="0 0 9 7" fill="none"><path d="M1 3.5L3.5 6L8 1" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
        : '';
    emUpdateFooter();
}

// ── Footer info ──────────────────────────────────────────
function emUpdateFooter() {
    const footerEl = document.getElementById('em-footer-info');
    const exportBtn = document.getElementById('em-export-btn');
    if (!footerEl || !exportBtn) return;

    if (emScope === 'all') {
        const count = emAllTabSel.size;
        footerEl.textContent = `${count} tab${count !== 1 ? 's' : ''} selected · ${emFmtAll.toUpperCase()} format`;
        exportBtn.disabled = count === 0;
        exportBtn.textContent = '⬇ Export ZIP';
    } else {
        const on = emCols.filter(c => c.on).length;
        const fmtLabels = { csv:'CSV', xlsx:'Excel', json:'JSON', pdf:'PDF' };
        footerEl.textContent = `${on} of ${emCols.length} columns · ${fmtLabels[emFmt] || emFmt} format`;
        exportBtn.disabled = on === 0;
        exportBtn.textContent = '⬇ Export';
        document.getElementById('em-selall-btn').textContent =
            emCols.some(c => !c.on) ? 'Select all' : 'Deselect all';
    }
}

// ── Main export dispatcher ───────────────────────────────
function emDoExport() {
    if (emScope === 'all') { emDoExportAll(); return; }

    const btn = document.getElementById('em-export-btn');
    btn.textContent = 'Exporting…'; btn.disabled = true;

    setTimeout(() => {
        try {
            const fname = document.getElementById('em-fname').value.trim() || 'NDC_Export';
            const { headers, rows } = emBuildData();
            const meta = emBuildMeta(emActiveTab, rows.length);

            if      (emFmt === 'csv')  emExportCSV(headers, rows, fname, meta);
            else if (emFmt === 'xlsx') emExportXLSX(headers, rows, fname, meta);
            else if (emFmt === 'json') emExportJSON(headers, rows, fname, meta);
            else if (emFmt === 'pdf')  emExportPDF(headers, rows, fname);

            closeExportModal();
        } catch (err) {
            alert('Export error: ' + err.message);
            console.error(err);
        }
        btn.textContent = '⬇ Export'; btn.disabled = false;
    }, 50);
}

// ── Metadata builder (shared) ────────────────────────────
function emBuildMeta(tab, rowCount) {
    const runDate  = new Date().toLocaleString();
    const supFiles = supplierFiles.map(f => f.name).join('; ') || '—';
    const billFiles= billingFiles.map(f => f.name).join('; ')  || '—';
    const contact  = typeof licGetCachedContact === 'function' ? licGetCachedContact() : {};
    const org      = contact.adminOrg || 'RxAuditwise';
    const website  = contact.adminWebsite || 'www.rxauditwise.com';
    const email    = contact.adminEmail || 'info@rxauditwise.com';
    const phone    = contact.adminPhone || '';
    const address  = contact.adminAddress || '';
    return [
        ['RxAuditwise v4.2', `Publisher: ${org}`, `Author: RxAuditwise Pharmacy Reconciliation`],
        [`Exported: ${runDate}`, `Tab: ${EM_TAB_LABELS[tab] || tab}`, `Rows: ${rowCount}`],
        [`Supplier files: ${supFiles}`, `Billing files: ${billFiles}`],
        [`Contact: ${email}${phone ? ' | ' + phone : ''}`, `Website: ${website}`, address ? `Address: ${address}` : ''],
        [],
    ];
}

// ── Build data ───────────────────────────────────────────
// ── Build data (uses current view cache) ────────────────────────
function emBuildData() {
    const on      = emCols.filter(c => c.on).map(c => c.key);
    const headers = emCols.filter(c => c.on).map(c => c.label);
    const rows    = [];
    const cache   = _emViewCache[emActiveTab];
    const fmt2    = v => (v != null && !isNaN(parseFloat(v))) ? Number(v).toFixed(2) : (v ?? '');
    // Shared O(1) lookup, built once — every branch below that needs to find
    // a group by NDC uses this instead of ndcGroups.find() (an O(n) scan that
    // was running once per exported row, i.e. O(n²) on large reconciliations).
    const ndcMap  = new Map(ndcGroups.map(g => [g.ndc, g]));

    // RESULTS: export exactly what the screen shows — same values, same format
    if (emActiveTab === 'results') {
        const pkgOn = typeof pkgDivideOn !== 'undefined' && pkgDivideOn;

        // Update headers when PKG active
        if (pkgOn) {
            const hMap = {
                'Rx qty filled':  'Rx qty (÷PKG)',
                'Purchase qty':   'Purchase qty (÷PKG)',
                'Difference':     'Reconciliation (÷PKG)',
                'Status':         'Status (÷PKG)',
            };
            headers.forEach((h, i) => { if (hMap[h]) headers[i] = hMap[h]; });
        }

        // Helper: divide by pkg — returns number string exactly as shown on screen
        const pd = (val, pkg) => {
            if (!pkgOn || !pkg || pkg === 0) return val != null ? val : '';
            const r = val / pkg;
            return r % 1 === 0 ? r.toFixed(0) : r.toFixed(2);
        };

        // Helper: format STATUS exactly as screen shows (e.g. "SHORT - (1.0)")
        const fmtStatus = (d, pkg) => {
            const v = pkgOn && pkg > 0 ? d / pkg : d;
            const abs = Math.abs(v);
            const absStr = abs % 1 === 0 ? abs.toFixed(1) : abs.toFixed(2);
            if (v === 0) return 'OK - (0.0)';
            if (v > 0)   return 'OVER - (' + absStr + ')';
            return              'SHORT - (' + absStr + ')';
        };

        // Helper: format RECONCILIATION/DIFF cell for detail rows — screen shows "-(n)" not "SHORT"
        // For total rows the diff column is EMPTY (screen shows blank), status column shows "SHORT-(n)"
        const fmtDiff = (d, pkg) => {
            if (d === 0) return '✔';
            if (d > 0)   return '✔';
            const v = pkgOn && pkg > 0 ? d / pkg : d;
            const abs = Math.abs(v);
            return '-(' + (abs % 1 === 0 ? abs.toFixed(0) : abs.toFixed(2)) + ')';
        };

        let sr = 0, curNDC = null;
        for (const row of filteredRows) {
            if (row.ndc !== curNDC) { curNDC = row.ndc; sr = 1; } else sr++;
            const pkg  = row.packageSize || (row.ndcGroup && row.ndcGroup.packageSize) || 0;
            const d    = row.diff;
            const isTotal  = row.type === 'total';
            const isDetail = row.type === 'detail';

            // Quantities — apply PKG divide exactly as screen does
            const rxQtyOut  = pd(row.rxQty,      pkg);
            const purQtyOut = pd(row.purchaseQty, pkg);

            // For DETAIL rows:
            //   - pkg size shown, insurer shown, BIN shown
            //   - diff column: shows "-(n)" when short, "✔" when ok/over  
            //   - status column: EMPTY (screen shows blank for detail rows)
            //   - insPaid: per-insurer paid
            //   - supplyCost: shown

            // For TOTAL rows:
            //   - pkg size EMPTY, insurer EMPTY, BIN EMPTY
            //   - diff column: EMPTY (screen shows blank td)
            //   - status column: "SHORT - (n)" / "OVER - (n)" / "OK - (0.0)"
            //   - insPaid: total for NDC
            //   - supplyCost: total

            let pkgSizeOut, insNameOut, binNoOut, diffOut, statusOut, insPaidOut, supCostOut;

            if (isDetail) {
                pkgSizeOut = row.packageSize ? row.packageSize : '';
                insNameOut = row.insName || '';
                binNoOut   = row.binNo   || '';
                diffOut    = fmtDiff(d, pkg);
                statusOut  = '';    // detail rows have EMPTY status column on screen
                insPaidOut = fmt2(row.insPaidRow || 0);
                supCostOut = fmt2((row.ndcGroup && row.ndcGroup.totalSupplyCost) || 0);
            } else {
                // total row
                pkgSizeOut = '';
                insNameOut = '';   // screen shows [TOTAL] label but it's blank in the insurer column
                binNoOut   = '';
                diffOut    = '';   // reconciliation column is BLANK on total rows
                statusOut  = fmtStatus(d, pkg);
                insPaidOut = fmt2(row.totalInsPaid  || 0);
                supCostOut = fmt2(row.totalSupplyCost || 0);
            }

            const obj = {
                sr,
                description:  row.description || row.drgName || '',
                ndc:          row.ndc,
                packageSize:  pkgSizeOut,
                insName:      insNameOut,
                binNo:        binNoOut,
                rxQty:        rxQtyOut,
                purchaseQty:  purQtyOut,
                diff:         diffOut,
                status:       statusOut,
                units:        isTotal ? (d < 0 && pkg > 0 ? (Math.abs(d) / pkg).toFixed(2) : '') : '',
                brand:        row.brand    || '',
                drugForm:     row.drugForm || '',
                insPaid:      insPaidOut,
                supplyCost:   supCostOut,
            };
            rows.push(on.map(k => obj[k] ?? ''));
        }
    }
    // SUPPLIERS: use cache (filtered+sorted by render function)
    else if (emActiveTab === 'suppliers') {
        const src = cache || Object.keys(purchaseMap).sort((a,b)=>(purchaseMap[a].description||'').localeCompare(purchaseMap[b].description||'')).map(ndc=>({ndc}));
        src.forEach((r, i) => {
            const sup=purchaseMap[r.ndc]||{}; const transactions=supTransactions[r.ndc]||[]; const fileTotals=supFileTotals[r.ndc]||{};
            const pkgSizes=[...new Set(transactions.map(t=>t.sz))].sort((a,b)=>a-b).map(sz=>sz===Math.floor(sz)?Math.floor(sz):sz);
            const calc=transactions.map(t=>`(${t.qty}x${t.sz===Math.floor(t.sz)?Math.floor(t.sz):t.sz})`).join(' + ');
            const suppliersStr=Object.entries(fileTotals).map(([f,t])=>`${f}(${t})`).join('; ');
            const obj={sr:i+1,ndc:r.ndc,description:sup.description||r.desc||'',pkgSize:pkgSizes.join(', '),
                suppliers:suppliersStr,calc,supplyCost:fmt2(sup.totalExtPrice||0),total:sup.totalQty||0};
            rows.push(on.map(k=>obj[k]??'')); });
    }
    // FINAL: use cache (filter: status, search; sort: finalSortCol) — PKG aware
    else if (emActiveTab === 'final') {
        const pkgOn = typeof pkgDivideOn !== 'undefined' && pkgDivideOn;
        if (pkgOn) {
            const hMap = {'Needed':'Needed (÷PKG)','Ordered':'Ordered (÷PKG)','Variance':'Variance (÷PKG)'};
            headers.forEach((h,i) => { if (hMap[h]) headers[i] = hMap[h]; });
        }
        const ePkg = (val, pkg) => {
            if (!pkgOn || !pkg || pkg === 0) return val != null ? val : '';
            const r = val / pkg; return r % 1 === 0 ? Number(r.toFixed(0)) : Number(r.toFixed(3));
        };
        const src = cache || [...ndcGroups].sort((a,b)=>a.description.localeCompare(b.description));
        src.forEach((r, i) => {
            const g=ndcMap.get(r.ndc)||r;
            const pkg=r.packageSize??g.packageSize??0;
            const insurers=r.insurers?r.insurers.join('; '):[...new Set((g.insurerRows||[]).map(x=>x.insName).filter(Boolean))].join('; ');
            const variance=r.variance??g.diff??0;
            const statusStr=(r.status||g.status)==='ok'?'OK':(r.status||g.status)==='over'
                ? 'OVER (' + Math.abs(pkgOn && pkg > 0 ? variance/pkg : variance).toFixed(1) + ')'
                : 'SHORT (' + Math.abs(pkgOn && pkg > 0 ? variance/pkg : variance).toFixed(1) + ')';
            const inits=pkg>0&&(r.needed??g.totalRxQty)>0?Math.round((r.needed??g.totalRxQty)/pkg):'';
            const obj={sr:i+1,ndc:r.ndc||g.ndc,description:r.desc||r.description||g.description,packageSize:pkg||'',
                insurers,initsPerPkg:inits,
                needed:   ePkg(r.needed??g.totalRxQty, pkg),
                ordered:  ePkg(r.ordered??g.totalPurchaseQty, pkg),
                variance: ePkg(variance, pkg),
                totalSupplyCost:fmt2(r.totalSupplyCost??g.totalSupplyCost??0),
                totalInsPaid:fmt2(r.totalInsPaid??g.totalInsPaid??0), status:statusStr};
            rows.push(on.map(k=>obj[k]??''));
        });
    }
    // BILL: use cache
    else if (emActiveTab === 'bill') {
        const src = cache || (()=>{ const insMap={};
            for(const grp of ndcGroups){for(const ins of grp.insurerRows){const key=ins.insName||'UNKNOWN';if(!insMap[key])insMap[key]={insName:ins.insName,bins:new Set(),ndcs:new Set(),totalRxQty:0,totalPurchaseQty:0,totalInsPaid:0,totalSupplyCost:0,ok:0,over:0,short:0};for(const b of ins.bins)insMap[key].bins.add(b);insMap[key].ndcs.add(grp.ndc);insMap[key].totalRxQty+=ins.qty;insMap[key].totalInsPaid+=(ins.insPaid||0);insMap[key][grp.status]++;}for(const ins of grp.insurerRows){const key=ins.insName||'UNKNOWN';if(insMap[key]&&!insMap[key]['_p'+grp.ndc]){insMap[key]['_p'+grp.ndc]=true;insMap[key].totalPurchaseQty+=grp.totalPurchaseQty;insMap[key].totalSupplyCost+=(grp.totalSupplyCost||0);}}}
            return Object.values(insMap).sort((a,b)=>b.totalRxQty-a.totalRxQty); })();
        src.forEach((r,i)=>{ const binsStr=r.bins instanceof Set?[...r.bins].sort().join(', '):(r.bins||''); const ndcCount=r.ndcs instanceof Set?r.ndcs.size:(r.ndcCount||0);
            const obj={sr:i+1,insName:r.insName,bins:binsStr,ndcCount,totalRxQty:r.totalRxQty,totalPurchaseQty:r.totalPurchaseQty,totalInsPaid:fmt2(r.totalInsPaid||0),totalSupplyCost:fmt2(r.totalSupplyCost||0),ok:r.ok||0,over:r.over||0,short:r.short||0};
            rows.push(on.map(k=>obj[k]??'')); });
    }
    // DISCARDED: use cache or rebuild
    else if (emActiveTab === 'discarded') {
        const supplied=new Set(Object.keys(purchaseMap));
        const buildDisc=()=>{ const discMap={};
            for(const r of billingRows){if(supplied.has(r.ndc))continue;if(!discMap[r.ndc])discMap[r.ndc]={ndc:r.ndc,desc:r.drgName||'',strong:r.strong||'',form:r.form||'',insurerData:{},total:0,totalPaid:0};const ins=r.insName||'UNKNOWN';if(!discMap[r.ndc].insurerData[ins])discMap[r.ndc].insurerData[ins]={qty:0,paid:0};discMap[r.ndc].insurerData[ins].qty+=r.qty;discMap[r.ndc].insurerData[ins].paid+=(r.insPaid||0);discMap[r.ndc].total+=r.qty;discMap[r.ndc].totalPaid+=(r.insPaid||0);}
            return Object.values(discMap).sort((a,b)=>(a.desc||'').localeCompare(b.desc||'')); };
        const src = cache || buildDisc();
        src.forEach((r,i)=>{ const desc=buildDesc(r.desc||r.description,r.strong,r.form)||(r.desc||r.description||''
);
            const insurers=Object.entries(r.insurerData||{}).sort((a,b)=>b[1].qty-a[1].qty);
            if(!insurers.length){rows.push(on.map(k=>({sr:i+1,ndc:r.ndc,description:desc,insurer:'\u2014',billedQty:0,insPaid:'0.00',total:r.total,totalPaid:fmt2(r.totalPaid||0),status:'NO SUPPLIER'}[k]??'')));}
            else{insurers.forEach(([ins,data],j)=>{const obj={sr:j===0?i+1:'',ndc:j===0?r.ndc:'',description:j===0?desc:'',insurer:ins,billedQty:data.qty,insPaid:fmt2(data.paid),total:j===0?r.total:'',totalPaid:j===0?fmt2(r.totalPaid||0):'',status:'NO SUPPLIER'};rows.push(on.map(k=>obj[k]??'')); });}
        });
    }
    // ISSUES: use cache (filtered short rows, sorted by issSortCol) — PKG aware
    else if (emActiveTab === 'issues') {
        const pkgOn = typeof pkgDivideOn !== 'undefined' && pkgDivideOn;
        if (pkgOn) {
            const hMap = {'Billed qty':'Billed qty (÷PKG)','Purchased qty':'Purchased qty (÷PKG)',
                          'Gap (units)':'Gap (÷PKG)','Pkgs short':'Pkgs short (÷PKG)'};
            headers.forEach((h,i) => { if (hMap[h]) headers[i] = hMap[h]; });
        }
        const ePkg = (val, pkg) => {
            if (!pkgOn || !pkg || pkg === 0) return val != null ? val : '';
            const r = val / pkg; return r % 1 === 0 ? Number(r.toFixed(0)) : Number(r.toFixed(3));
        };
        // Cache holds BOTH short and over rows (tagged via _issType) since the
        // Issues tab displays both as separate tables — exporting only one
        // would silently drop half of what's shown on screen.
        const src = cache || ndcGroups.filter(g=>g.status==='short').map(g=>({...g,_issType:'short'})).sort((a,b)=>Math.abs(a.diff)-Math.abs(b.diff));
        src.forEach((r,i)=>{ const g=ndcMap.get(r.ndc)||r; const pkg=r.packageSize??g.packageSize??0;
            const isOver = r._issType === 'over';
            const gapAmt = isOver ? (r.overAmt ?? Math.abs(g.diff ?? 0)) : (r.shortAmt ?? Math.abs(g.diff ?? 0));
            const units  = isOver ? (r.pkgsOver ?? (pkg>0?Math.floor(gapAmt/pkg):'')) : (r.unitsNeeded ?? (pkg>0?Math.ceil(gapAmt/pkg):''));
            const topIns=r.topInsurer||([...(g.insurerRows||[])].sort((a,b)=>b.qty-a.qty)[0]?.insName||'');
            const obj={sr:i+1,ndc:r.ndc||g.ndc,description:r.desc||r.description||g.description,pkgSize:pkg||'',
                needed:   ePkg(r.needed??g.totalRxQty, pkg),
                ordered:  ePkg(r.ordered??g.totalPurchaseQty, pkg),
                shortAmt: (isOver ? '+' : '') + ePkg(gapAmt, pkg),
                unitsNeeded: pkgOn ? units : units,
                totalInsPaid:fmt2(g.totalInsPaid||0),totalSupplyCost:fmt2(g.totalSupplyCost||0),topInsurer:topIns,
                type: isOver ? 'OVER' : 'SHORT'};
            rows.push(on.map(k=>obj[k]??''));
        });
    }
    // NOT BILLED: use cache
    else if (emActiveTab === 'notbilled') {
        const billed=new Set(billingRows.map(r=>r.ndc));
        const src=cache||Object.keys(purchaseMap).filter(n=>!billed.has(n)).sort((a,b)=>(purchaseMap[a].description||'').localeCompare(purchaseMap[b].description||'')).map(ndc=>({ndc}));
        src.forEach((r,i)=>{ const sup=purchaseMap[r.ndc]||{}; const transactions=supTransactions[r.ndc]||[]; const fileTotals=supFileTotals[r.ndc]||{};
            const pkgSizes=[...new Set(transactions.map(t=>t.sz))].sort((a,b)=>a-b).map(sz=>sz===Math.floor(sz)?Math.floor(sz):sz);
            const calc=transactions.map(t=>`(${t.qty}x${t.sz===Math.floor(t.sz)?Math.floor(t.sz):t.sz})`).join(' + ');
            const suppliersStr=Object.entries(fileTotals).map(([f,t])=>`${f}(${t})`).join('; ');
            const obj={sr:i+1,ndc:r.ndc,description:sup.description||'',pkgSize:pkgSizes.join(', '),suppliers:suppliersStr,calc,supplyCost:fmt2(sup.totalExtPrice||0),total:sup.totalQty||0,status:'NOT BILLED'};
            rows.push(on.map(k=>obj[k]??'')); });
    }
    // DOLLAR: use cache (filtered by dolStatusFilter, sorted by dolSortCol, searched)
    else if (emActiveTab === 'dollar') {
        const src=cache||ndcGroups;
        src.forEach((r,i)=>{ const g=ndcMap.get(r.ndc)||r;
            const insPaid=r.totalInsPaid??g.totalInsPaid??0; const supCost=r.totalSupplyCost??g.totalSupplyCost??0; const dolDiff=r.dollarDiff??g.dollarDiff??0;
            const ds=!insPaid&&!supCost?'NO DATA':Math.abs(dolDiff)<0.01?'MATCH':dolDiff>0?'COST > PAID':'PAID > COST';
            const obj={sr:i+1,ndc:r.ndc||g.ndc,description:r.description||r.desc||g.description,packageSize:r.packageSize??g.packageSize??''
                ,totalRxQty:r.totalRxQty??g.totalRxQty,totalInsPaid:fmt2(insPaid),totalSupplyCost:fmt2(supCost),dollarDiff:(dolDiff>=0?'+':'')+dolDiff.toFixed(2),dolStatus:ds};
            rows.push(on.map(k=>obj[k]??'')); });
    }
    // MFP: use cache (filtered by mfpActiveYear + mfpActiveStatus + mfpSearch) — PKG aware
    else if (emActiveTab === 'mfp') {
        const pkgOn = typeof pkgDivideOn !== 'undefined' && pkgDivideOn;
        if (pkgOn) {
            const hMap = {'Rx qty filled':'Rx qty (÷PKG)','Purchase qty':'Purchase qty (÷PKG)',
                          'Difference':'Difference (÷PKG)','Status':'Status (÷PKG)'};
            headers.forEach((h,i) => { if (hMap[h]) headers[i] = hMap[h]; });
        }
        const ePkg = (val, pkg) => {
            if (!pkgOn || !pkg || pkg === 0) return val != null ? val : '';
            const r = val / pkg; return r % 1 === 0 ? Number(r.toFixed(0)) : Number(r.toFixed(3));
        };
        const mfpGrps=cache?cache.map(r=>ndcMap.get(r.ndc)||r):ndcGroups.filter(g=>MFP_NDCS[g.ndc]);
        const mfpInsFilter = (_emViewMeta['mfp'] && _emViewMeta['mfp'].insFilter) || null;
        let sr=0,curNDC=null;
        for(const grp of mfpGrps){
            const insRowsToExport = mfpInsFilter ? (grp.insurerRows||[]).filter(r => r.insName === mfpInsFilter) : (grp.insurerRows||[]);
            for(const ins of insRowsToExport){
            if(grp.ndc!==curNDC){curNDC=grp.ndc;sr=1;}else sr++;
            const pkg = grp.packageSize || 0;
            const d=grp.totalPurchaseQty-ins.qty;
            const dDisp = pkgOn && pkg > 0 ? d/pkg : d;
            const absStr = v => { const a = Math.abs(v); return a % 1 === 0 ? a.toFixed(1) : a.toFixed(2); };
            const diffStr = dDisp > 0 ? 'OVER' : dDisp === 0 ? 'OK' : 'SHORT (' + absStr(dDisp) + ')';
            const obj={sr,description:grp.description,ndc:grp.ndc,packageSize:pkg||'',
                insName:ins.insName,binNo:ins.binNo,
                rxQty:      ePkg(ins.qty, pkg),
                purchaseQty:ePkg(grp.totalPurchaseQty, pkg),
                diff:diffStr,status:grp.status.toUpperCase(),
                insPaid:fmt2(ins.insPaid||0),supplyCost:fmt2(grp.totalSupplyCost||0),
                year:(MFP_NDCS[grp.ndc]||[]).join(', ')};
            rows.push(on.map(k=>obj[k]??''));
        }}
    }
    return { headers, rows };
}

// ── Format exporters ─────────────────────────────────────
function emExportCSV(headers, rows, fname, meta) {
    const esc   = v => `"${String(v??'').replace(/"/g,'""')}"`;
    const lines = [];
    if (meta) meta.forEach(row => lines.push(row.map(esc).join(',')));
    lines.push(headers.map(esc).join(','));
    rows.forEach(r => lines.push(r.map(esc).join(',')));
    emDownload(new Blob([lines.join('\n')], { type:'text/csv' }), fname+'.csv');
}

function emExportJSON(headers, rows, fname, meta) {
    const out = {
        publisher:'RxAuditwise', author:'Pharmacy Reconciliation Tool',
        exported: new Date().toLocaleString(),
        data: rows.map(r => { const o={}; headers.forEach((h,i)=>o[h]=r[i]??''); return o; })
    };
    emDownload(new Blob([JSON.stringify(out,null,2)], { type:'application/json' }), fname+'.json');
}

function emExportXLSX(headers, rows, fname, meta) {
    if (typeof XLSX === 'undefined') { alert('Excel library not loaded.'); return; }
    const allRows = [];
    if (meta) meta.forEach(row => allRows.push(row));
    allRows.push(headers);
    rows.forEach(r => allRows.push(r));
    const ws = XLSX.utils.aoa_to_sheet(allRows);
    ws['!cols'] = headers.map((h,i) => ({ wch: Math.min(40, Math.max(h.length, ...rows.map(r=>String(r[i]??'').length))+2) }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, (emActiveTab||'sheet').slice(0,31));
    XLSX.writeFile(wb, fname+'.xlsx');
}

function emExportPDF(headers, rows, fname) {
    const jspdf = window.jspdf || window.jsPDF;
    if (!jspdf) { alert('PDF library not loaded.'); return; }
    const { jsPDF } = jspdf;

    // ── Orientation: landscape for wide tables ──
    const orientation = headers.length > 6 ? 'landscape' : 'portrait';
    const doc = new jsPDF({ orientation, unit: 'pt', format: 'a4' });
    const PW  = orientation === 'landscape' ? 841.89 : 595.28;

    // ── Colours matching the screen ──
    const C = {
        primary:   [124, 58,  237],   // purple header
        shortRow:  [255, 228, 230],   // red-50  — SHORT detail rows
        shortTot:  [254, 202, 202],   // red-200 — SHORT total row
        okRow:     [220, 252, 231],   // green-100
        overRow:   [255, 237, 213],   // orange-100
        altRow:    [248, 248, 252],   // very light lavender — even rows
        white:     [255, 255, 255],
        textDark:  [30,  30,  30],
        textMuted: [100, 100, 100],
        shortText: [185, 28,  28],    // red-700
        okText:    [21,  128, 61],    // green-700
        overText:  [180, 83,  9],     // orange-700
    };

    // ── Column index detection ──
    const statusColIdx  = headers.findIndex(h => /^status/i.test(h));
    const diffColIdx    = headers.findIndex(h => /^difference/i.test(h) || /^reconciliation/i.test(h) || /^variance/i.test(h));
    const insNameColIdx = headers.findIndex(h => /insurer.?name/i.test(h) || /^insurer$/i.test(h));
    const srColIdx      = headers.findIndex(h => /^sr#?$/i.test(h));
    const ndcColIdx      = headers.findIndex(h => /^ndc$/i.test(h));

    // ── Determine row status from ANY column that has status text ──
    // For Results: detail rows have empty status but diff="-(n)", total rows have status="SHORT-(n)"
    function rowStatus(rowArr) {
        // Check status column first (total rows)
        const stat = statusColIdx >= 0 ? String(rowArr[statusColIdx] ?? '').toUpperCase() : '';
        if (/SHORT/.test(stat)) return 'short';
        if (/OVER/.test(stat))  return 'over';
        if (/^OK/.test(stat))   return 'ok';

        // Check diff column (detail rows have "-(n)" for short)
        const diff = diffColIdx >= 0 ? String(rowArr[diffColIdx] ?? '') : '';
        if (/^-\(/.test(diff))  return 'short';   // "-(" means short
        if (/SHORT/.test(diff.toUpperCase())) return 'short';
        if (/OVER/.test(diff.toUpperCase()))  return 'over';

        // Check all columns for any status text
        for (const cell of rowArr) {
            const v = String(cell ?? '').toUpperCase();
            if (/SHORT/.test(v)) return 'short';
            if (/OVER/.test(v) && !/CAREOVER|COVEROVER/.test(v)) return 'over';
        }
        return '';
    }

    // Detect if row is a "total" summary row (blank insName, has status)
    function isTotalRow(rowArr) {
        const ins = insNameColIdx >= 0 ? String(rowArr[insNameColIdx] ?? '') : '';
        const stat = statusColIdx >= 0 ? String(rowArr[statusColIdx] ?? '') : '';
        return ins === '' && stat !== '';
    }

    // ── Header: logo area + title ──
    const runDate = new Date().toLocaleString();
    const tabLabel = EM_TAB_LABELS[emActiveTab] || emActiveTab;

    // Purple header bar
    doc.setFillColor(...C.primary);
    doc.rect(0, 0, PW, 44, 'F');

    // White title text in header bar
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('RxAuditwise v4.2', 28, 20);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('— ' + tabLabel, 28 + doc.getTextWidth('RxAuditwise v4.2') + 4, 20);

    // Sub info in header
    const _contact = typeof licGetCachedContact === 'function' ? licGetCachedContact() : {};
    const _org     = _contact.adminOrg || 'RxAuditwise';
    const _website = _contact.adminWebsite || 'www.rxauditwise.com';
    doc.setFontSize(7.5);
    doc.setTextColor(220, 200, 255);
    doc.text('Publisher: ' + _org + '   ·   ' + _website + '   ·   Exported: ' + runDate + '   ·   ' + rows.length + ' rows', 28, 34);

    // ── Summary pills (row counts by status) ──
    let startY = 52;
    if (emActiveTab === 'results' || emActiveTab === 'final' || emActiveTab === 'mfp') {
        // Count by DISTINCT NDC, not by row — several tabs (MFP especially) have
        // multiple rows sharing one NDC (one per insurer), all carrying the same
        // status text, which would otherwise inflate the count well past what
        // the on-screen summary bar shows for the same data.
        const ndcStatusMap = {};
        rows.forEach(r => {
            const ndc = ndcColIdx >= 0 ? r[ndcColIdx] : null;
            if (ndc == null) return;
            const stat = statusColIdx >= 0 ? String(r[statusColIdx] ?? '').toUpperCase() : '';
            if (/SHORT/.test(stat)) ndcStatusMap[ndc] = 'short';
            else if (/^OVER/.test(stat)) ndcStatusMap[ndc] = 'over';
            else if (/^OK/.test(stat)) ndcStatusMap[ndc] = 'ok';
        });
        const statusVals = Object.values(ndcStatusMap);
        const shortCount = statusVals.filter(s => s === 'short').length;
        const okCount    = statusVals.filter(s => s === 'ok').length;
        const overCount  = statusVals.filter(s => s === 'over').length;

        const totalNdcCount = ndcColIdx >= 0 ? new Set(rows.map(r => r[ndcColIdx])).size : rows.length;
        const pills = [
            { label: 'OK: ' + okCount,       bg: [220,252,231], tc: [21,128,61]  },
            { label: 'Over: ' + overCount,    bg: [255,237,213], tc: [180,83,9]   },
            { label: 'Short: ' + shortCount,  bg: [255,228,230], tc: [185,28,28]  },
            { label: 'Total: ' + totalNdcCount + ' NDCs',
              bg: [237,233,254], tc: [109,40,217] },
        ];

        let px = 28;
        for (const p of pills) {
            const tw = doc.setFontSize(7).getTextWidth(p.label) + 12;
            doc.setFillColor(...p.bg);
            doc.roundedRect(px, startY, tw, 13, 3, 3, 'F');
            doc.setTextColor(...p.tc);
            doc.setFont('helvetica', 'bold');
            doc.text(p.label, px + 6, startY + 9);
            px += tw + 6;
        }
        startY += 20;
    }

    // ── autoTable with row coloring via didParseCell / willDrawCell ──
    doc.autoTable({
        head:     [headers],
        body:     rows.map(r => r.map(v => String(v ?? ''))),
        startY:   startY,
        margin:   { left: 28, right: 28 },
        tableWidth: 'auto',

        styles: {
            fontSize:    6.5,
            cellPadding: { top: 2.5, bottom: 2.5, left: 3, right: 3 },
            overflow:    'ellipsize',
            valign:      'middle',
            lineWidth:   0.1,
            lineColor:   [220, 210, 245],
        },

        headStyles: {
            fillColor:  C.primary,
            textColor:  255,
            fontStyle:  'bold',
            fontSize:   7,
            cellPadding: { top: 4, bottom: 4, left: 3, right: 3 },
        },

        // Per-row background + text colouring — matches screen exactly
        didParseCell: function(data) {
            if (data.section !== 'body') return;
            const rowArr = rows[data.row.index];
            if (!rowArr) return;
            const status = rowStatus(rowArr);
            const isTot  = isTotalRow(rowArr);
            const colKey = data.column.index;

            // Row background
            if (isTot) {
                if      (status === 'short') data.cell.styles.fillColor = C.shortTot;
                else if (status === 'over')  data.cell.styles.fillColor = [253, 186, 116];
                else if (status === 'ok')    data.cell.styles.fillColor = [187, 247, 208];
                else                         data.cell.styles.fillColor = [237, 233, 254];
                data.cell.styles.fontStyle = 'bold';
            } else if (status === 'short') {
                data.cell.styles.fillColor = data.row.index % 2 === 0 ? C.shortRow : [255, 237, 239];
            } else if (status === 'over') {
                data.cell.styles.fillColor = data.row.index % 2 === 0 ? C.overRow : [255, 243, 230];
            } else if (status === 'ok') {
                data.cell.styles.fillColor = data.row.index % 2 === 0 ? C.okRow : [236, 253, 245];
            } else {
                data.cell.styles.fillColor = data.row.index % 2 === 0 ? C.altRow : C.white;
            }

            // Status column: coloured bold text
            if (colKey === statusColIdx) {
                const txt = String(data.cell.raw ?? '').toUpperCase();
                if (/SHORT/.test(txt))     { data.cell.styles.textColor = C.shortText; data.cell.styles.fontStyle = 'bold'; }
                else if (/OVER/.test(txt)) { data.cell.styles.textColor = C.overText;  data.cell.styles.fontStyle = 'bold'; }
                else if (/^OK/.test(txt))  { data.cell.styles.textColor = C.okText;    data.cell.styles.fontStyle = 'bold'; }
            }

            // Diff/Reconciliation column: red for "-(n)" short values
            if (colKey === diffColIdx) {
                const txt = String(data.cell.raw ?? '');
                if (txt.startsWith('-(') || /SHORT/i.test(txt)) {
                    data.cell.styles.textColor = C.shortText;
                    data.cell.styles.fontStyle = 'bold';
                } else if (/OVER/i.test(txt)) {
                    data.cell.styles.textColor = C.overText;
                }
            }

            // Ins Paid column: green
            const insPaidIdx = headers.findIndex(h => /ins.?paid/i.test(h));
            if (colKey === insPaidIdx) {
                const v = String(data.cell.raw ?? '');
                if (v && v !== '0.00' && v !== '') data.cell.styles.textColor = [5, 150, 105];
            }

            // Supply Cost column: purple
            const supCostIdx = headers.findIndex(h => /supply.?cost/i.test(h));
            if (colKey === supCostIdx) {
                const v = String(data.cell.raw ?? '');
                if (v && v !== '0.00' && v !== '') data.cell.styles.textColor = [109, 40, 217];
            }
        },
    });

    // ── Footer on each page ──
    const pageCount = doc.internal.getNumberOfPages();
    const _footerContact = (_contact.adminEmail || 'info@rxauditwise.com');
    for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(6.5);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(160, 160, 160);
        doc.text(
            'RxAuditwise v4.2  ·  ' + _org + '  ·  ' + _website + '  ·  ' + _footerContact + '  ·  Page ' + i + ' of ' + pageCount,
            28,
            doc.internal.pageSize.getHeight() - 10
        );
        doc.text(runDate, PW - 28, doc.internal.pageSize.getHeight() - 10, { align: 'right' });
    }

    doc.save(fname + '.pdf');
}

function emDownload(blob, filename) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

// ── Export ALL tabs as ZIP ────────────────────────────────
async function emDoExportAll() {
    const btn = document.getElementById('em-export-btn');
    btn.textContent = 'Building ZIP…'; btn.disabled = true;

    try {
        const zipFname = (document.getElementById('em-fname-all').value.trim() || 'RxAuditwise_Export');
        const fmt      = emFmtAll;
        const files    = [];

        for (const tabDef of EM_ALL_TABS) {
            if (!emAllTabSel.has(tabDef.key)) continue;

            // Temporarily set active tab + all-cols-on
            const savedTab  = emActiveTab;
            const savedCols = emCols;
            emActiveTab = tabDef.key;
            emCols      = (EM_COLS[tabDef.key] || EM_COLS.results).map(c => ({ ...c, on:true }));

            try {
                const { headers, rows } = emBuildData();
                const meta = emBuildMeta(tabDef.key, rows.length);

                if (fmt === 'csv') {
                    const esc   = v => `"${String(v??'').replace(/"/g,'""')}"`;
                    const lines = [];
                    meta.forEach(row => lines.push(row.map(esc).join(',')));
                    lines.push(headers.map(esc).join(','));
                    rows.forEach(r => lines.push(r.map(esc).join(',')));
                    const blob = new Blob([lines.join('\n')], { type:'text/csv' });
                    files.push({ name:`${EM_DEFAULTS[tabDef.key]||tabDef.key}.csv`, blob });

                } else if (fmt === 'xlsx') {
                    const allRows = [...meta, headers, ...rows];
                    const ws = XLSX.utils.aoa_to_sheet(allRows);
                    ws['!cols'] = headers.map((h,i) => ({ wch:Math.min(40, Math.max(h.length,...rows.map(r=>String(r[i]??'').length))+2) }));
                    const wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(wb, ws, tabDef.key.slice(0,31));
                    const wbout = XLSX.write(wb, { bookType:'xlsx', type:'array' });
                    files.push({ name:`${EM_DEFAULTS[tabDef.key]||tabDef.key}.xlsx`, blob: new Blob([wbout], { type:'application/octet-stream' }) });
                }
            } catch (tabErr) {
                console.warn(`Skip ${tabDef.key}:`, tabErr.message);
            }

            emActiveTab = savedTab;
            emCols      = savedCols;
        }

        await emPackageZip(files, zipFname+'.zip');
        closeExportModal();

    } catch (err) {
        alert('Export All error: ' + err.message);
        console.error(err);
    }

    btn.textContent = '⬇ Export ZIP'; btn.disabled = false;
}

async function emPackageZip(files, zipName) {
    if (typeof fflate !== 'undefined') {
        const zipObj = {};
        for (const f of files) {
            const ab = await f.blob.arrayBuffer();
            zipObj[f.name] = new Uint8Array(ab);
        }
        const zipped = fflate.zipSync(zipObj);
        emDownload(new Blob([zipped], { type:'application/zip' }), zipName);
    } else {
        // Fallback: individual downloads
        for (const f of files) {
            await new Promise(res => setTimeout(res, 180));
            emDownload(f.blob, f.name);
        }
    }
}

// ── Backdrop click closes modal ──────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    const overlay = document.getElementById('export-overlay');
    if (overlay) overlay.addEventListener('click', e => { if (e.target === overlay) closeExportModal(); });
});
