// ════════════════════════════════════
//  EMBEDDED MFP NDC LIST
// ════════════════════════════════════
const MFP_NDCS = {"00003089321":["2026"],"00003089331":["2026"],"00003089341":["2026"],"00003089421":["2026"],"00003089431":["2026"],"00003089441":["2026"],"00003089470":["2026"],"00003089828":["2026"],"00003102812":["2026"],"00003102828":["2026"],"00003102884":["2026"],"00003376474":["2026"],"58406001001":["2026"],"58406001004":["2026"],"58406002101":["2026"],"58406002104":["2026"],"58406003201":["2026"],"58406003204":["2026"],"58406004401":["2026"],"58406004404":["2026"],"58406004424":["2026"],"58406005501":["2026"],"58406005504":["2026"],"58406042534":["2026"],"58406042541":["2026"],"58406043501":["2026"],"58406043504":["2026"],"58406044501":["2026"],"58406044504":["2026"],"58406044601":["2026"],"58406044604":["2026"],"58406045501":["2026"],"58406045504":["2026"],"58406045601":["2026"],"58406045604":["2026"],"00078065920":["2026"],"00078065935":["2026"],"00078065961":["2026"],"00078065967":["2026"],"00078069620":["2026"],"00078069635":["2026"],"00078069661":["2026"],"00078069667":["2026"],"00078077720":["2026"],"00078077735":["2026"],"00078077761":["2026"],"00078077767":["2026"],"00078123120":["2026"],"00078123820":["2026"],"71610080632":["2026"],"71610080737":["2026"],"71610081032":["2026"],"00003142711":["2026"],"00003142712":["2026"],"00003142713":["2026"],"00003142714":["2026"],"00003142791":["2026"],"00003142811":["2026"],"00003142812":["2026"],"00003142813":["2026"],"00003142814":["2026"],"00003142891":["2026"],"00310620530":["2026"],"00310620590":["2026"],"00310621030":["2026"],"00310621039":["2026"],"00310621090":["2026"],"66993045630":["2026"],"66993045730":["2026"],"57962000712":["2026"],"57962001428":["2026"],"57962007028":["2026"],"57962014009":["2026"],"57962014012":["2026"],"57962028028":["2026"],"57962042028":["2026"],"57962056028":["2026"],"00006011201":["2026"],"00006011228":["2026"],"00006011231":["2026"],"00006011254":["2026"],"00006022101":["2026"],"00006022128":["2026"],"00006022131":["2026"],"00006022154":["2026"],"00006027701":["2026"],"00006027702":["2026"],"00006027714":["2026"],"00006027727":["2026"],"00006027728":["2026"],"00006027730":["2026"],"00006027731":["2026"],"00006027733":["2026"],"00006027754":["2026"],"00006027774":["2026"],"00006027782":["2026"],"00597015230":["2026"],"00597015237":["2026"],"00597015290":["2026"],"00597015330":["2026"],"00597015337":["2026"],"00597015390":["2026"],"00169210011":["2026"],"00169210112":["2026"],"00169210125":["2026"],"00169320111":["2026"],"00169320415":["2026"],"00169320511":["2026"],"00169320515":["2026"],"00169320611":["2026"],"00169320615":["2026"],"00169330312":["2026"],"00169633910":["2026"],"00169750111":["2026"],"73070010011":["2026"],"73070010210":["2026"],"73070010215":["2026"],"73070010310":["2026"],"73070010315":["2026"],"57894005427":["2026"],"57894006002":["2026"],"57894006003":["2026"],"57894006102":["2026"],"57894006103":["2026"],"57894044001":["2026"],"57894044003":["2026"],"57894044101":["2026"],"57894044401":["2026"],"50458057501":["2026"],"50458057701":["2026"],"50458057710":["2026"],"50458057718":["2026"],"50458057760":["2026"],"50458057801":["2026"],"50458057810":["2026"],"50458057830":["2026"],"50458057890":["2026"],"50458057901":["2026"],"50458057910":["2026"],"50458057930":["2026"],"50458057989":["2026"],"50458057990":["2026"],"50458058001":["2026"],"50458058010":["2026"],"50458058030":["2026"],"50458058090":["2026"],"50458058451":["2026"],"55154142200":["2026"],"55154142308":["2026"],"55154142400":["2026"],"55154142408":["2026"],"68546017060":["2027"],"68546017160":["2027"],"68546017260":["2027"],"68546047056":["2027"],"68546047156":["2027"],"68546047256":["2027"],"68546047356":["2027"],"68546047456":["2027"],"68546047556":["2027"],"68546047656":["2027"],"68546047729":["2027"],"68546047956":["2027"],"68546049052":["2027"],"00173085910":["2027"],"00173085914":["2027"],"00173088210":["2027"],"00173088214":["2027"],"00173091610":["2027"],"66993013597":["2027"],"66993013697":["2027"],"00310051260":["2027"],"00310351260":["2027"],"00069018721":["2027"],"00069018821":["2027"],"00069018921":["2027"],"00069028403":["2027"],"00069028407":["2027"],"00069048603":["2027"],"00069048607":["2027"],"00069068803":["2027"],"00069068807":["2027"],"00006007861":["2027"],"00006007862":["2027"],"00006007882":["2027"],"00006008061":["2027"],"00006008062":["2027"],"00006008082":["2027"],"00006008131":["2027"],"00006008154":["2027"],"00006008182":["2027"],"00006057501":["2027"],"00006057552":["2027"],"00006057561":["2027"],"00006057562":["2027"],"00006057582":["2027"],"00006057701":["2027"],"00006057752":["2027"],"00006057761":["2027"],"00006057762":["2027"],"00006057782":["2027"],"00456120130":["2027"],"00456120230":["2027"],"00456120330":["2027"],"00597014360":["2027"],"00597014560":["2027"],"55513013728":["2027"],"55513013750":["2027"],"55513013760":["2027"],"55513036955":["2027"],"55513049751":["2027"],"55513049760":["2027"],"55513050855":["2027"],"55513051641":["2027"],"55513051804":["2027"],"55513051930":["2027"],"59572063027":["2027"],"59572063106":["2027"],"59572063128":["2027"],"59572063255":["2027"],"00169413001":["2027"],"00169413013":["2027"],"00169413211":["2027"],"00169413212":["2027"],"00169413602":["2027"],"00169413611":["2027"],"00169418103":["2027"],"00169418113":["2027"],"00169430301":["2027"],"00169430313":["2027"],"00169430330":["2027"],"00169430701":["2027"],"00169430713":["2027"],"00169430730":["2027"],"00169431401":["2027"],"00169431413":["2027"],"00169431430":["2027"],"00169450101":["2027"],"00169450114":["2027"],"00169450501":["2027"],"00169450514":["2027"],"00169451701":["2027"],"00169451714":["2027"],"00169452401":["2027"],"00169452414":["2027"],"00169452501":["2027"],"00169452514":["2027"],"00169477211":["2027"],"00169477212":["2027"],"59572050100":["2027"],"59572050121":["2027"],"59572050200":["2027"],"59572050221":["2027"],"59572050300":["2027"],"59572050321":["2027"],"59572050400":["2027"],"59572050421":["2027"],"00597014010":["2027"],"00597014030":["2027"],"00597014061":["2027"],"00597014090":["2027"],"00173088710":["2027"],"00173088714":["2027"],"00173089310":["2027"],"00173089314":["2027"],"61874011511":["2027"],"61874011517":["2027"],"61874011520":["2027"],"61874011530":["2027"],"61874011531":["2027"],"61874011563":["2027"],"61874011590":["2027"],"61874013011":["2027"],"61874013020":["2027"],"61874013030":["2027"],"61874013031":["2027"],"61874013063":["2027"],"61874013090":["2027"],"61874014511":["2027"],"61874014530":["2027"],"61874014563":["2027"],"61874014590":["2027"],"61874016011":["2027"],"61874016030":["2027"],"61874016063":["2027"],"61874016090":["2027"],"61874017008":["2027"],"70518315700":["2027"],"70518315701":["2027"],"65649030103":["2027"],"65649030104":["2027"],"65649030105":["2027"],"65649030141":["2027"],"65649030203":["2027"],"65649030302":["2027"],"65649030303":["2027"],"65649030304":["2027"],"00469012599":["2027"],"00469062599":["2027"],"00469072560":["2027"],"00173086906":["2028"],"00173086910":["2028"],"00173086961":["2028"],"66993013497":["2028"],"50090624700":["2028"],"61958250101":["2028"],"61958250102":["2028"],"61958250103":["2028"],"61958250501":["2028"],"61958250601":["2028"],"70518308000":["2028"],"70518308001":["2028"],"70518308002":["2028"],"70518308003":["2028"],"00023114501":["2028"],"00023114502":["2028"],"00023391950":["2028"],"00023392102":["2028"],"00023392103":["2028"],"00023923201":["2028"],"50474070061":["2028"],"50474070062":["2028"],"50474071079":["2028"],"50474071080":["2028"],"50474071081":["2028"],"50474075010":["2028"],"00078063941":["2028"],"00078063968":["2028"],"00078063997":["2028"],"00078063998":["2028"],"00078105697":["2028"],"00078105699":["2028"],"00078107068":["2028"],"00078107096":["2028"],"00078116861":["2028"],"64764010710":["2028"],"64764010711":["2028"],"64764010820":["2028"],"64764010821":["2028"],"64764030020":["2028"],"59676060012":["2028"],"59676060056":["2028"],"59676060099":["2028"],"59676060414":["2028"],"59676060430":["2028"],"00078086001":["2028"],"00078086714":["2028"],"00078086742":["2028"],"00078087421":["2028"],"00078087463":["2028"],"62856070405":["2028"],"62856070430":["2028"],"62856070805":["2028"],"62856070830":["2028"],"62856071005":["2028"],"62856071030":["2028"],"62856071205":["2028"],"62856071230":["2028"],"62856071405":["2028"],"62856071430":["2028"],"62856071805":["2028"],"62856071830":["2028"],"62856072005":["2028"],"62856072030":["2028"],"62856072405":["2028"],"62856072430":["2028"],"00003218710":["2028"],"00003218713":["2028"],"00003218811":["2028"],"00003218851":["2028"],"00003218890":["2028"],"00003218891":["2028"],"00003281411":["2028"],"00003281811":["2028"],"59148003513":["2028"],"59148003607":["2028"],"59148003613":["2028"],"59148003707":["2028"],"59148003713":["2028"],"59148003807":["2028"],"59148003813":["2028"],"59148003907":["2028"],"59148003913":["2028"],"59148004007":["2028"],"59148004013":["2028"],"59148004207":["2028"],"59148004414":["2028"],"70518354800":["2028"],"00002143301":["2028"],"00002143361":["2028"],"00002143380":["2028"],"00002143401":["2028"],"00002143461":["2028"],"00002143480":["2028"],"00002223601":["2028"],"00002223661":["2028"],"00002223680":["2028"],"00002318201":["2028"],"00002318261":["2028"],"00002318280":["2028"],"50090348300":["2028"],"50090348400":["2028"],"50090546700":["2028"],"50090645300":["2028"],"50090645600":["2028"],"50090657100":["2028"],"50090758900":["2028"],"00002448354":["2028"],"00002448362":["2028"],"00002481554":["2028"],"00002481562":["2028"],"00002533754":["2028"],"00002533762":["2028"],"00002533763":["2028"],"00002621654":["2028"],"00069050114":["2028"],"00069050130":["2028"],"00069050230":["2028"],"00069100101":["2028"],"00069100102":["2028"],"00069100103":["2028"],"00069100201":["2028"],"00069100202":["2028"],"00069100203":["2028"],"00069102901":["2028"],"00069102902":["2028"],"63539001202":["2028"],"63539001602":["2028"],"63539050114":["2028"],"63539050130":["2028"],"63539050230":["2028"],"50242004062":["2028"],"50242004086":["2028"],"50242021401":["2028"],"50242021403":["2028"],"50242021455":["2028"],"50242021486":["2028"],"50242021501":["2028"],"50242021503":["2028"],"50242021555":["2028"],"50242021586":["2028"],"50242022701":["2028"],"50242022755":["2028"],"50242022786":["2028"],"50242022799":["2028"]};

// ════════════════════════════════════
//  INSURER / BIN LOOKUP
// ════════════════════════════════════
const INSURER_BINS = {
    "Prime":["610455","011552","017449","012833","016499","004915","015905","018844"],
    "Medicaid":["004740"],
    "Caremark":["610235","028272","020388","020115","610591","020107","610415","004336","021338","610239","610502","020099","020123","025201","026696","026150","027547","027555","027570","028512","028406"],
    "MedImpact":["006053","003585","015574","017142","012312","009893","610303","017134","610342","019272","637639","027489","014244","610288","018852","017529","019926","019819","021783","021072","021791","610306","610748","018661","023187","013477","610346","019389","016359","015566","019983","014582","019975","022287","800004","017944","600518","019950","019074","026069","017267","018547","020040","023491","020594","611793","019611"],
    "Express Script":["003858","610014","610031","610056","013865","400023","010033","013337","013344","610053","610575","012924","017010"],
    "Optum":["004261","610279","610494","610613","016580","610011","610652","023153","022485","025796","012592","019827","017522","020321","800010","001553","014293","610127","004428","005947","009992","011297","011867","012353","004469","006524","008985","010553","011321","012155","012502","004919","007110","009117","010876","011677","021684","003452","012163","012882","005757","007887","009299","011198","011792","012295","012924","012957","013907","014186","014189","017933","600428","603017","610182","610593","610679","610604","014681","015839","018643","600471","603286","610140","610527","610619","014872","015756","020768","003650","009951","018704","601577","606464","610171","610548","610621","610704","015814","017267","060646","601683","610173","610560","020149","024045","021049","021916","021825","610097"],
    "Humana":["015599","015581","610649"]
};

const BIN_TO_INSURER = {};
for (const [n, bins] of Object.entries(INSURER_BINS))
    for (const b of bins) BIN_TO_INSURER[b] = n;

// ════════════════════════════════════
//  COLUMN DETECTION PATTERNS
// ════════════════════════════════════
const PATTERNS = {
    ndc:        [/^ndc$/i, /ndc.?upc/i, /\bndc\b/i, /national.?drug.?code/i, /drug.?code/i],
    // Priority: exact "Description" first; "Generic Name" demoted to fallback so Smith Drugs DESCRIPTION col wins.
    description:[/^description$/i, /^trade.?name$/i, /product.?desc/i, /drgname/i, /drug.?name/i, /item.?name/i, /item.?description/i, /product.?name/i, /generic.?description/i, /^particulars$/i, /display.?name/i, /^name$/i, /^generic.?name$/i, /description/i],
    // qty: Quantity must come before size to avoid grabbing "Units" as qty on Smith Drugs files.
    // "Units Purchased" = total units (qty × pkg size) — NOT the order qty; excluded intentionally.
    qty:        [/^invoice.?quantity.?\(filled\)$/i, /^invoice.?qty.?filled$/i, /^ship(ped)?.?qty$/i, /shipped.?qty/i, /qty.?ship/i, /^quantity.?process/i, /^qty.?process/i, /^qty.?order/i, /^quantity.?order/i, /^qty$/i, /^quant(ity)?$/i, /^quantity$/i, /shipped$/i],
    // size: Smith Drugs uses "Units" (units per pkg) and "Size" (format string e.g. "1X30 TB2").
    // "Units Purchased" is intentionally excluded — it's qty×size, not pkg size.
    size:       [/unit.?size.?qty/i, /unit.?size/i, /pack.?size/i, /pack(age)?.?size/i, /pkg.?size/i, /^size$/i, /^units$/i],
    // Smith Drugs specific: "Units Purchased" = Quantity × Units (total dispensed units, not pkg size)
    unitsPurchased: [/^units.?purchased$/i],
    // McKesson: Invoiced Dose Quantity (Extended) ÷ Invoice Quantity (Filled) = pkg size
    doseQtyExt: [/invoiced.?dose.?quantity.?\(extended\)/i, /invoiced.?dose.?qty.?ext/i, /dose.?quantity.?extended/i],
    rxno:       [/^rxno$/i, /^rx.?no$/i, /^rx.?number$/i, /^prescription.?no/i],
    date:       [/^datef$/i, /^date$/i, /^invoice.?month$/i, /fill.?date/i, /dispense.?date/i, /invoice.?date/i, /date.?fill/i, /^order.?date$/i],
    invoiceDate:[/invoice.?credit.?date/i, /^invoice.?month$/i, /invoice.?date/i, /^datef$/i, /^date$/i, /^order.?date$/i, /^status.?changed/i],
    insName:    [/insname/i, /ins.?name/i, /insurer.?name/i, /payer.?name/i, /plan.?name/i, /rx.?ins.?name/i, /insurer/i, /payer/i],
    binNo:      [/priinsbinno/i, /^binno$/i, /bin.?no/i, /rx.?ins.?bin/i, /^bin$/i],
    drugStrong: [/drugstrong/i, /drug.?strength/i, /^strength$/i, /^strong/i],
    drugForm:   [/drugform/i, /dosage.?form/i, /drug.?form/i, /^form$/i],
    pkgSize:    [/packagesize/i, /pack(age)?.?size/i, /pkg.?size/i],
    brand:      [/^brand$/i, /brand.?flag/i, /brand.?ind/i, /^brand.?or.?generic$/i],
    // Smith Drugs: "Order Type" column — skip RETURN rows
    // Invoice_Review: "Purchase/Return" and "Invoice Type" columns
    orderType:  [/^order.?type$/i, /^purchase.?return$/i, /^invoice.?type$/i],
    sourceName: [/^source.?name$/i, /^supplier.?name$/i, /^vendor.?name$/i, /^wholesaler$/i, /^source$/i],
    extPrice:   [/^extended.?price/i, /ext.?price/i, /purchase.?dollars/i, /gross.?purchases/i,
                 /^total.?cost$/i, /^total.?processed$/i, /^invoice\ \$$/i, /^invoice\$$/i, /^invoice.?amount/i],
    unitPrice:  [/^price.?per.?package/i, /^unit.?price.?\(current.?invoice\)/i, /^unit.?price$/i, /invoiced.?price.?per.?dose/i,
                 /^item.?price$/i, /^price$/i],
    costCol:    [/^mar.*cost$/i, /^apr.*cost$/i, /^jan.*cost$/i, /^feb.*cost$/i, /^jun.*cost$/i,
                 /^jul.*cost$/i, /^aug.*cost$/i, /^sep.*cost$/i, /^oct.*cost$/i, /^nov.*cost$/i, /^dec.*cost$/i,
                 /^\d{4}.*cost$/i, /cost$/i],
    totalInsPaid: [/^totalrxamount$/i, /^totalinspaid$/i, /total.?ins.?paid/i, /total.?rx.?amount/i, /ins.?paid/i],
};

// ════════════════════════════════════
//  EXPORT MODAL COLUMN DEFINITIONS
// ════════════════════════════════════
const EM_COLS = {
    results: [
        {key:'sr',label:'Sr#',on:true},{key:'description',label:'Description',on:true},{key:'ndc',label:'NDC',on:true},
        {key:'packageSize',label:'Package size',on:true},{key:'insName',label:'Insurer name',on:true},
        {key:'binNo',label:'BIN codes',on:true},{key:'rxQty',label:'Rx qty filled',on:true},
        {key:'purchaseQty',label:'Purchase qty',on:true},{key:'diff',label:'Difference',on:true},
        {key:'status',label:'Status',on:true},{key:'insPaid',label:'Ins paid ($)',on:true},{key:'supplyCost',label:'Supply cost ($)',on:true},
        {key:'units',label:'Units / pkg',on:false},{key:'brand',label:'Brand',on:false},{key:'drugForm',label:'Drug form',on:false},
    ],
    suppliers: [
        {key:'sr',label:'Sr#',on:true},{key:'ndc',label:'NDC',on:true},{key:'description',label:'Description',on:true},
        {key:'pkgSize',label:'Pkg size',on:true},{key:'suppliers',label:'Supplier files',on:true},
        {key:'calc',label:'Calculation',on:true},{key:'supplyCost',label:'Supply cost ($)',on:true},{key:'total',label:'Total qty',on:true},
    ],
    final: [
        {key:'sr',label:'Sr#',on:true},{key:'ndc',label:'NDC',on:true},{key:'description',label:'Description',on:true},
        {key:'packageSize',label:'Pkg size',on:true},{key:'insurers',label:'Insurers',on:true},
        {key:'initsPerPkg',label:'INITS/PKG',on:true},{key:'needed',label:'Needed',on:true},
        {key:'ordered',label:'Ordered',on:true},{key:'variance',label:'Variance',on:true},{key:'totalSupplyCost',label:'Supply cost ($)',on:true},{key:'totalInsPaid',label:'Ins paid ($)',on:true},{key:'status',label:'Status',on:true},
    ],
    bill: [
        {key:'sr',label:'Sr#',on:true},{key:'insName',label:'Insurer name',on:true},{key:'bins',label:'BIN codes',on:true},
        {key:'ndcCount',label:'NDC count',on:true},{key:'totalRxQty',label:'Billed qty',on:true},
        {key:'totalPurchaseQty',label:'Purchase qty',on:true},{key:'ok',label:'OK',on:true},
        {key:'totalInsPaid',label:'Ins paid ($)',on:true},{key:'totalSupplyCost',label:'Supply cost ($)',on:true},{key:'over',label:'Over',on:true},{key:'short',label:'Short',on:true},
    ],
    discarded: [
        {key:'sr',label:'Sr#',on:true},{key:'ndc',label:'NDC',on:true},{key:'description',label:'Description',on:true},
        {key:'insurer',label:'Insurer',on:true},{key:'billedQty',label:'Billed qty',on:true},{key:'insPaid',label:'Ins paid ($)',on:true},
        {key:'total',label:'Total billed',on:true},{key:'totalPaid',label:'Total ins paid ($)',on:true},{key:'status',label:'Status',on:true},
    ],
    issues: [
        {key:'sr',label:'Sr#',on:true},{key:'ndc',label:'NDC',on:true},{key:'description',label:'Description',on:true},
        {key:'type',label:'Type (SHORT/OVER)',on:true},
        {key:'pkgSize',label:'Pkg size',on:false},{key:'needed',label:'Billed qty',on:true},
        {key:'ordered',label:'Purchased qty',on:true},{key:'shortAmt',label:'Gap/Excess (units)',on:true},
        {key:'unitsNeeded',label:'Pkgs short/over',on:true},{key:'totalInsPaid',label:'Ins paid ($)',on:true},{key:'totalSupplyCost',label:'Supply cost ($)',on:true},{key:'topInsurer',label:'Top insurer',on:true},
    ],
    notbilled: [
        {key:'sr',label:'Sr#',on:true},{key:'ndc',label:'NDC',on:true},{key:'description',label:'Description',on:true},
        {key:'pkgSize',label:'Pkg size',on:true},{key:'suppliers',label:'Supplier files',on:true},
        {key:'calc',label:'Calculation',on:true},{key:'supplyCost',label:'Supply cost ($)',on:true},
        {key:'total',label:'Ordered qty',on:true},{key:'status',label:'Status',on:true},
    ],
    mfp: [
        {key:'sr',label:'Sr#',on:true},{key:'description',label:'Description',on:true},{key:'ndc',label:'NDC',on:true},
        {key:'packageSize',label:'Package size',on:false},{key:'insName',label:'Insurer name',on:true},
        {key:'binNo',label:'BIN codes',on:true},{key:'rxQty',label:'Rx qty filled',on:true},
        {key:'purchaseQty',label:'Purchase qty',on:true},{key:'diff',label:'Difference',on:true},
        {key:'status',label:'Status',on:true},{key:'insPaid',label:'Ins paid ($)',on:true},{key:'supplyCost',label:'Supply cost ($)',on:true},{key:'year',label:'MFP year',on:true},
    ],
    dollar: [
        {key:'sr',label:'Sr#',on:true},{key:'ndc',label:'NDC',on:true},{key:'description',label:'Description',on:true},
        {key:'packageSize',label:'Pkg size',on:false},{key:'totalRxQty',label:'Rx qty',on:true},
        {key:'totalInsPaid',label:'Ins paid ($)',on:true},{key:'totalSupplyCost',label:'Supply cost ($)',on:true},
        {key:'dollarDiff',label:'$ difference',on:true},{key:'dolStatus',label:'Status',on:true},
    ],
};

const EM_DEFAULTS = {results:'NDC_Results',suppliers:'Suppliers_Combined',final:'Final_Variance',bill:'Bill_By_Insurer',dollar:'Dollar_Reconciliation',discarded:'Discarded_No_Supplier',issues:'Issues_SHORT',notbilled:'Not_Billed_NDCs',mfp:'MFP_Results'};
const EM_TAB_LABELS = {results:'Results tab',suppliers:'Suppliers tab',final:'Final tab',bill:'Bill tab',dollar:'Dollar tab',discarded:'Discarded tab',issues:'Issues tab',notbilled:'Not Billed tab',mfp:'MFP tab'};

// Labels shown in the browser tab (document.title) per screen/tab
const PAGE_TITLE_MAP = {
    login:'Sign In', upload:'Upload Files', results:'Results', mfp:'MFP', raw:'Preview',
    suppliers:'Suppliers', final:'Final', bill:'Bill', dollar:'Dollar',
    discarded:'Discarded', notbilled:'Not Billed', issues:'Issues',
    gate:'Access Restricted'
};

// ══════════════════════════════════════
//  NON-NABP WHOLESALER LIST
//  Source: NABP_Accreditation.docx
//  If a file has a "Source Name" column AND the source name matches
//  any entry below → that NDC is flagged as Non-NABP.
//  Any source name NOT in this list → treated as NABP (accredited).
// ══════════════════════════════════════
const NON_NABP_WHOLESALERS = new Set([
    'american',
    'hhcrx',
    'matrix',
    'ne medical',
    'path medical supply',
    'pmw',
    'prestige medical supply',
    'surplus diabetic',
    'velocity distributors lllc',
    'velocity distributors llc',
    'velocity distributors',
    'wasatch rx'
]);

// Returns true if the source name is in the Non-NABP list
// Only called when the file actually has a Source Name column (sourceI >= 0)
function isNonNABP(name) {
    if (!name) return false; // blank source = don't flag
    return NON_NABP_WHOLESALERS.has(String(name).trim().toLowerCase());
}
