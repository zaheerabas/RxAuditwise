
// ══════════════════════════════════════
//  COLUMN DRAG-TO-REORDER — ALL TABS
//  Generic system that works for Suppliers,
//  Final, Issues, Not Billed, Bill, Dollar, MFP
// ══════════════════════════════════════
const TAB_COL_DEFS = {
    suppliers: [
        { key:'sr',    label:'Sr#',           fixed:true },
        { key:'ndc',   label:'NDC', },
        { key:'desc',  label:'Description',   sort:'desc', type:'text' },
        { key:'pkg',   label:'Pkg Size',      sort:'pkgSize', type:'num' },
        { key:'files', label:'Suppliers (files)' },
        { key:'calc',  label:'Calculation' },
        { key:'cost',  label:'Supply Cost ($)', sort:'totalExtPrice', type:'num' },
        { key:'qty',   label:'Total Qty',     sort:'total', type:'num' },
    ],
    final: [
        { key:'sr',       label:'Sr#',         fixed:true },
        { key:'ndc',      label:'NDC', },
        { key:'desc',     label:'Description', sort:'desc', type:'text' },
        { key:'pkg',      label:'Pkg Size',    sort:'packageSize', type:'num' },
        { key:'insurers', label:'Insurers' },
        { key:'inits',    label:'Initials/Pkg', sort:'initsPerPkg', type:'num' },
        { key:'needed',   label:'Needed',      sort:'needed', type:'num' },
        { key:'ordered',  label:'Ordered',     sort:'ordered', type:'num' },
        { key:'variance', label:'Variance',    sort:'variance', type:'status' },
        { key:'cost',     label:'Supply Cost ($)', sort:'totalSupplyCost', type:'num' },
        { key:'paid',     label:'Ins Paid ($)',    sort:'totalInsPaid', type:'num' },
        { key:'status',   label:'Status',      sort:'status', type:'status' },
    ],
    issues: [
        { key:'sr',      label:'Sr#',        fixed:true },
        { key:'ndc',     label:'NDC', },
        { key:'desc',    label:'Description',sort:'desc', type:'text' },
        { key:'pkg',     label:'Pkg Size',   sort:'packageSize', type:'num' },
        { key:'needed',  label:'Billed Qty', sort:'needed', type:'num' },
        { key:'ordered', label:'Purchased',  sort:'ordered', type:'num' },
        { key:'short',   label:'Short Qty',  sort:'shortAmt', type:'num' },
        { key:'units',   label:'Pkgs Short', sort:'units', type:'num' },
        { key:'paid',    label:'Ins Paid ($)',  sort:'totalInsPaid', type:'num' },
        { key:'cost',    label:'Supply Cost ($)', sort:'totalSupplyCost', type:'num' },
        { key:'insurer', label:'Top Insurer', sort:'topInsurer', type:'text' },
    ],
    notbilled: [
        { key:'sr',    label:'Sr#',         fixed:true },
        { key:'ndc',   label:'NDC', },
        { key:'desc',  label:'Description', sort:'desc', type:'text' },
        { key:'pkg',   label:'Pkg Size',    sort:'pkgSize', type:'num' },
        { key:'files', label:'Supplier Files' },
        { key:'calc',  label:'Calculation' },
        { key:'cost',  label:'Supply Cost ($)', sort:'totalExtPrice', type:'num' },
        { key:'qty',   label:'Total Qty',   sort:'total', type:'num' },
        { key:'status', label:'Status' },
    ],
    bill: [
        { key:'sr',      label:'Sr#',          fixed:true },
        { key:'insurer', label:'Insurer',       sort:'insName', type:'text' },
        { key:'bins',    label:'BIN Codes' },
        { key:'ndcs',    label:'NDC Count',     sort:'ndcCount', type:'num' },
        { key:'rxqty',   label:'Rx Qty',        sort:'totalRxQty', type:'num' },
        { key:'purqty',  label:'Purchase Qty',  sort:'totalPurchaseQty', type:'num' },
        { key:'paid',    label:'Ins Paid ($)',  sort:'totalInsPaid', type:'num' },
        { key:'cost',    label:'Supply Cost ($)', sort:'totalSupplyCost', type:'num' },
        { key:'ok',      label:'OK',      sort:'ok', type:'num' },
        { key:'over',    label:'Over',    sort:'over', type:'num' },
        { key:'short',   label:'Short',   sort:'short', type:'num' },
    ],
    dollar: [
        { key:'sr',      label:'Sr#',        fixed:true },
        { key:'ndc',     label:'NDC', },
        { key:'desc',    label:'Description',sort:'description', type:'text' },
        { key:'pkg',     label:'Pkg Size',   sort:'packageSize', type:'num' },
        { key:'rxqty',   label:'Rx Qty',     sort:'totalRxQty', type:'num' },
        { key:'paid',    label:'Ins Paid ($)',    sort:'totalInsPaid', type:'num' },
        { key:'cost',    label:'Supply Cost ($)', sort:'totalSupplyCost', type:'num' },
        { key:'diff',    label:'Dollar Diff',     sort:'dollarDiff', type:'num' },
        { key:'status',  label:'Status' },
    ],
};

const _tabColOrder  = {}; // tab -> array of keys
const _tabColDrag   = {}; // tab -> {dragKey, dragOver}
const TAB_COL_STORE = 'rxaw_tab_col_order_v1';

function tabColGetOrder(tab) {
    if (_tabColOrder[tab]) return _tabColOrder[tab];
    try {
        const saved = JSON.parse(localStorage.getItem(TAB_COL_STORE) || '{}');
        if (saved[tab] && Array.isArray(saved[tab])) {
            const defs = TAB_COL_DEFS[tab];
            if (defs && saved[tab].length === defs.length && defs.every(c => saved[tab].includes(c.key))) {
                _tabColOrder[tab] = saved[tab];
                return _tabColOrder[tab];
            }
        }
    } catch(e) {}
    _tabColOrder[tab] = (TAB_COL_DEFS[tab] || []).map(c => c.key);
    return _tabColOrder[tab];
}

function tabColSave(tab) {
    try {
        const all = JSON.parse(localStorage.getItem(TAB_COL_STORE) || '{}');
        all[tab] = _tabColOrder[tab];
        localStorage.setItem(TAB_COL_STORE, JSON.stringify(all));
    } catch(e) {}
}

function tabColOrdered(tab) {
    const order = tabColGetOrder(tab);
    return order.map(k => (TAB_COL_DEFS[tab] || []).find(c => c.key === k)).filter(Boolean);
}

function tabColReset(tab, rerenderFn) {
    _tabColOrder[tab] = (TAB_COL_DEFS[tab] || []).map(c => c.key);
    tabColSave(tab);
    if (rerenderFn) rerenderFn();
}

// Build a draggable <thead> HTML string for a given tab
function tabColHeader(tab, sortCol, sortDir, sortFnName, labelOverrides, theadStyle) {
    const pkgOn = typeof pkgDivideOn !== 'undefined' && pkgDivideOn;
    const cols  = tabColOrdered(tab);
    const presetFnName = sortFnName ? sortFnName.replace(/Sort$/, 'SortPreset') : null;
    const thClass = (col) => {
        if (!col.sort) return '';
        if (sortCol === col.sort) return sortDir === 1 ? ' asc' : ' desc';
        return '';
    };

    return '<tr>' + cols.map(col => {
        const sortAttr = col.sort && sortFnName ? ` onclick="${sortFnName}('${col.sort}')"` : '';
        const dragAttrs = col.fixed ? '' :
            ` draggable="true"
              ondragstart="tabColDragStart(event,'${tab}','${col.key}')"
              ondragover="tabColDragOver(event,'${tab}','${col.key}')"
              ondrop="tabColDrop(event,'${tab}','${col.key}',${sortFnName ? "'" + sortFnName + "'" : 'null'})"
              ondragend="tabColDragEnd('${tab}')"
              ondragleave="tabColDragLeave(event,'${tab}')"
              title="Drag to reorder"`;

        let label = (labelOverrides && labelOverrides[col.key]) || col.label;
        if (pkgOn && ['needed','ordered','variance','rxqty','purqty','short','units'].includes(col.key)) {
            label += ' <span class="pkg-div-badge">÷PKG</span>';
        }

        // Small caret next to the label opens an explicit "A→Z / Z→A" or
        // "Highest→Lowest / Lowest→Highest" menu, so sort options are discoverable
        // without needing to know that clicking the header itself toggles direction.
        let caret = '';
        if (col.sort && presetFnName) {
            const colType = col.type || 'text';
            caret = ` <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'${presetFnName}','${col.sort}','${colType}')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span>`;
        }

        const cls = ['col-draggable', col.fixed ? 'col-fixed' : '', thClass(col)].filter(Boolean).join(' ');
        const styleAttr = theadStyle ? ` style="${theadStyle}"` : '';
        return `<th class="${cls}"${styleAttr}${sortAttr}${dragAttrs}>${label}${caret}</th>`;
    }).join('') + '</tr>';
}

// Drag handlers for other tabs
function tabColDragStart(e, tab, key) {
    if (!_tabColDrag[tab]) _tabColDrag[tab] = {};
    _tabColDrag[tab].dragKey = key;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', key);
    setTimeout(() => e.target.classList.add('col-dragging'), 0);
}

function tabColDragOver(e, tab, key) {
    const d = _tabColDrag[tab];
    if (!d || !d.dragKey || d.dragKey === key) return;
    const targetCol = (TAB_COL_DEFS[tab] || []).find(c => c.key === key);
    if (targetCol && targetCol.fixed) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (d.dragOver !== key) {
        const theadRow = e.target.closest('tr');
        if (theadRow) theadRow.querySelectorAll('.col-drop-left,.col-drop-right').forEach(el => {
            el.classList.remove('col-drop-left','col-drop-right');
        });
        d.dragOver = key;
        const order = tabColGetOrder(tab);
        const fromIdx = order.indexOf(d.dragKey);
        const toIdx   = order.indexOf(key);
        e.currentTarget.classList.add(fromIdx < toIdx ? 'col-drop-right' : 'col-drop-left');
    }
}

function tabColDragLeave(e, tab) {
    e.currentTarget.classList.remove('col-drop-left','col-drop-right');
}

function tabColDrop(e, tab, targetKey, rerenderFn) {
    e.preventDefault();
    const d = _tabColDrag[tab] || {};
    document.querySelectorAll('.col-drop-left,.col-drop-right').forEach(el => {
        el.classList.remove('col-drop-left','col-drop-right');
    });
    if (!d.dragKey || d.dragKey === targetKey) return;
    const targetCol = (TAB_COL_DEFS[tab] || []).find(c => c.key === targetKey);
    if (targetCol && targetCol.fixed) return;

    const order = tabColGetOrder(tab);
    const fromIdx = order.indexOf(d.dragKey);
    const toIdx   = order.indexOf(targetKey);
    if (fromIdx < 0 || toIdx < 0) return;
    order.splice(fromIdx, 1);
    order.splice(toIdx, 0, d.dragKey);
    _tabColOrder[tab] = order;
    tabColSave(tab);

    d.dragKey = null; d.dragOver = null;
    // Re-render the appropriate tab
    const rerender = {
        suppliers: renderSuppliersTab, final: renderFinalTab,
        issues: renderIssuesTab, notbilled: renderNotBilledTab,
        bill: renderBillTab, dollar: renderDollarTab,
    };
    if (rerender[tab]) rerender[tab]();
}

function tabColDragEnd(tab) {
    document.querySelectorAll('.col-dragging,.col-drop-left,.col-drop-right').forEach(el => {
        el.classList.remove('col-dragging','col-drop-left','col-drop-right');
    });
    if (_tabColDrag[tab]) { _tabColDrag[tab].dragKey = null; _tabColDrag[tab].dragOver = null; }
}
// ════════════════════════════════════
//  SHARED DOLLAR FORMATTER
// ════════════════════════════════════
function fmtD(v) {
    if (!v || isNaN(v) || v === 0) return '';
    return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtDCell(v, color) {
    if (!v || isNaN(v) || v === 0) return '<span class="mono" style="color:#cbd5e1;font-size:11px">—</span>';
    const s = '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return `<span class="mono" style="color:${color||'#059669'};font-weight:600;font-size:11px">${s}</span>`;
}

// ════════════════════════════════════
//  SUPPLIERS TAB
// ════════════════════════════════════

function renderSuppliersTab() {
    // Built once per render — avoids scanning all of ndcGroups (an O(n) linear
    // search) for every single row below, which was O(n²) overall and the
    // single biggest render-time cost on large reconciliations.
    const ndcMap = new Map(ndcGroups.map(g => [g.ndc, g]));
    const rows = Object.keys(purchaseMap).map(ndc => {
        const sup = purchaseMap[ndc];
        const transactions = supTransactions[ndc] || [];
        const fileTotals = supFileTotals[ndc] || {};
        const pkgSizes = [...new Set(transactions.map(t => t.sz))].sort((a, b) => a - b);
        const grp = ndcMap.get(ndc);
        return { ndc, desc: sup.description, total: sup.totalQty, totalExtPrice: sup.totalExtPrice || 0, transactions, fileTotals, pkgSizes, form: (grp && grp.drugForm) || sup.form || '' };
    });
    const supForms = [...new Set(rows.map(r => r.form).filter(Boolean))].sort();
    let sorted = [...rows];
    if (supSortCol === 'pkgSize') {
        sorted.sort((a, b) => { const aSize = a.pkgSizes.length ? a.pkgSizes[0] : 0; const bSize = b.pkgSizes.length ? b.pkgSizes[0] : 0; return supSortDir * (aSize - bSize); });
    } else {
        sorted.sort((a, b) => { const av = a[supSortCol], bv = b[supSortCol]; if (av == null && bv == null) return 0; if (typeof av === 'string') return supSortDir * av.localeCompare(bv); return supSortDir * ((av || 0) - (bv || 0)); });
    }
    let filtered = supSearch ? sorted.filter(r => { const n = normalizeNDCSearch(supSearch); return r.ndc.includes(n) || r.ndc.includes(supSearch) || r.desc.toLowerCase().includes(supSearch.toLowerCase()); }) : sorted;
    if (supFormFilter !== 'all') filtered = filtered.filter(r => r.form === supFormFilter);

    function suppliersCell(fileTotals) {
        const entries = Object.entries(fileTotals);
        if (!entries.length) return '—';
        return entries.map(([fname, ftotal]) => { const short = fname.length > 25 ? fname.slice(0, 22) + '…' : fname; return `<span class="sup-file-entry"><span class="sup-file-name">${escHtml(short)}</span> <span class="sup-file-total">(${ftotal.toLocaleString()})</span></span>`; }).join('');
    }
    function calcCell(transactions) { if (!transactions.length) return '—'; return transactions.map(t => `(${t.qty}x${t.sz === Math.floor(t.sz) ? Math.floor(t.sz) : t.sz})`).join(' + '); }
    function pkgSizeCell(pkgSizes) { if (!pkgSizes.length) return '—'; return pkgSizes.map(sz => sz === Math.floor(sz) ? Math.floor(sz) : sz).join(', '); }
    function thClass(col) { return supSortCol === col ? (supSortDir === 1 ? 'asc' : 'desc') : ''; }

    let html = `<div class="sup-outer"><div class="sup-header"><div class="sup-title">Suppliers: <span>${supplierFiles.length}</span></div><div style="font-size:11px;color:var(--text-muted);margin-left:12px;background:var(--bg);padding:4px 10px;border-radius:4px;border:1px solid var(--border)">Total Supply Cost: <strong style="color:#059669">${fmtD(Object.values(purchaseMap).reduce((s,p)=>s+(p.totalExtPrice||0),0))}</strong></div>
    <select class="select-filter" style="margin-left:10px;" onchange="supSetForm(this.value)"><option value="all">All Drug Forms</option>${supForms.map(f => `<option value="${escHtml(f)}" ${supFormFilter===f?'selected':''}>${escHtml(f)}</option>`).join('')}</select>
    <div class="sup-header-spacer"></div><button class="qs-btn" onclick="tabColReset('suppliers',renderSuppliersTab)" title="Reset column order" style="font-size:10px;color:#6b7280;"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Cols</button><div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="sup-search-inp" placeholder="Search this view..." value="${escHtml(supSearch)}" oninput="supSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'sup-search-inp\').value=\'\';supSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div><button class="export-btn" onclick="openExportModal('suppliers')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button></div><div class="sup-table-wrap"><table class="sup-table"><thead>${tabColHeader('suppliers', supSortCol, supSortDir, 'supSort')}</thead><tbody>`;
    if (typeof emCacheRows === 'function') emCacheRows('suppliers', filtered);
    // Same O(1)-lookup fix for billingRows — was also being linearly scanned once per row.
    const billingByNdc = new Map();
    for (const b of billingRows) { if (!billingByNdc.has(b.ndc)) billingByNdc.set(b.ndc, b); }
    filtered.forEach((r, i) => {
        const grp = ndcMap.get(r.ndc);
        const bRow = billingByNdc.get(r.ndc);
        const sup  = purchaseMap[r.ndc] || {};
        const nameDisp   = bRow && bRow.drgName ? bRow.drgName : (r.desc || sup.description || '');
        const strongDisp = (bRow && bRow.strong) ? bRow.strong : (sup.strong || '');
        const formDisp   = (bRow && bRow.form)   ? bRow.form   : (sup.form   || (grp ? grp.drugForm : '') || '');
        // IMPROVEMENT 9: pkg size source badge
        const pSrc = grp ? grp.pkgSrc : (purchaseMap[r.ndc] ? purchaseMap[r.ndc].pkgSrc : '');
        const CELLS = {
            sr:    () => `<td style="text-align:center;font-weight:700;color:var(--text-muted);font-size:11px">${i + 1}</td>`,
            ndc:   () => `<td><span class="sup-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td>`,
            desc:  () => `<td>${descCellHtml(nameDisp, strongDisp, formDisp, supSearch)}</td>`,
            pkg:   () => `<td style="text-align:right;font-variant-numeric:tabular-nums;">${pkgSizeCell(r.pkgSizes)}${pkgSrcBadge(pSrc)}</td>`,
            files: () => `<td class="sup-files">${suppliersCell(r.fileTotals)}</td>`,
            calc:  () => `<td class="sup-calc">${escHtml(calcCell(r.transactions))}</td>`,
            cost:  () => `<td style="text-align:right;padding:6px 10px;">${fmtDCell(r.totalExtPrice,'var(--rxa-primary,#7c3aed)')}</td>`,
            qty:   () => `<td class="sup-total">${r.total.toLocaleString()}</td>`,
        };
        html += '<tr>' + tabColOrdered('suppliers').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + '</tr>';
    });
    html += `</tbody></table></div></div>`;
    document.getElementById('suppliers-content').innerHTML = html;
    const inp = document.getElementById('sup-search-inp'); if (inp && supSearch) { inp.focus(); inp.setSelectionRange(supSearch.length, supSearch.length); }
}

const supSearchFn = debounce(v => { supSearch = v; renderSuppliersTab(); }, 200);
function supSetForm(v) { supFormFilter = v; renderSuppliersTab(); }
function supSortPreset(col, dir) { supSortCol = col; supSortDir = dir; renderSuppliersTab(); }
function supSort(col) { if (supSortCol === col) { supSortDir *= -1; } else { supSortCol = col; supSortDir = col === 'desc' || col === 'ndc' || col === 'pkgSize' ? 1 : -1; } renderSuppliersTab(); }

// ════════════════════════════════════
//  MFP TAB
// ════════════════════════════════════

// MFP year filter: 'all'=all, '2026'=2026 only, '2027'=up to 2027, '2028'=up to 2028
function setMFPYear(year, btn) {
    mfpActiveYear = year;
    document.querySelectorAll('#mfp-year-filters .year-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderMFP();
}

// Returns the set of years included for a given filter selection
function mfpYearSet(filter) {
    if (filter === 'all')   return null;           // null = no year filter
    if (filter === '2026')  return new Set(['2026']);
    if (filter === '2027')  return new Set(['2026','2027']);
    if (filter === '2028')  return new Set(['2026','2027','2028']);
    return new Set([filter]);
}

function setMFPStatus(status, btn) {
    mfpActiveStatus = status;
    document.querySelectorAll('#mfp-status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderMFP();
}

function initMFPFilters() {
    const mfpGrps = ndcGroups.filter(g => MFP_NDCS[g.ndc]);
    const ins = [...new Set(mfpGrps.flatMap(g => g.insurerRows.map(r => r.insName)).filter(Boolean))].sort();
    const frm = [...new Set(mfpGrps.map(g => g.drugForm).filter(Boolean))].sort();
    document.getElementById('mfp-ins-filter').innerHTML = '<option>All Insurers</option>' + ins.map(i => `<option>${i}</option>`).join('');
    document.getElementById('mfp-form-filter').innerHTML = '<option>All Drug Forms</option>' + frm.map(f => `<option>${f}</option>`).join('');
}

const mfpSearchFn = debounce(() => renderMFP(), 200);
function renderMFP() {
    const insF = document.getElementById('mfp-ins-filter').value;
    const frmF = document.getElementById('mfp-form-filter').value;
    const srch = document.getElementById('mfp-search').value.toLowerCase();
    const filterIns = insF !== 'All Insurers';
    let mfpGrps = ndcGroups.filter(g => {
        if (!MFP_NDCS[g.ndc]) return false;
        // Cumulative year filter: 2026=only 2026, 2027=up to 2027, 2028=up to 2028
        if (mfpActiveYear !== 'all') {
            const allowed = mfpYearSet(mfpActiveYear);
            const ndcYears = MFP_NDCS[g.ndc] || [];
            // NDC must have at least one year in the allowed set
            if (!ndcYears.some(y => allowed.has(y))) return false;
        }
        if (mfpActiveStatus !== 'all' && g.status !== mfpActiveStatus) return false;
        if (filterIns && !g.insurerRows.some(r => r.insName === insF)) return false;
        if (frmF !== 'All Drug Forms' && g.drugForm !== frmF) return false;
        if (srch) {
            const nS = normalizeNDCSearch(srch);
            if (!g.description.toLowerCase().includes(srch) && !g.ndc.includes(nS) && !g.ndc.includes(srch)) return false;
        }
        return true;
    });
    mfpGrps.sort((a, b) => {
        if (mfpSortCol === 'desc') return mfpSortDir * a.description.localeCompare(b.description);
        if (mfpSortCol === 'status' && typeof mfpSortDir === 'string') return statusRank(a.status, mfpSortDir) - statusRank(b.status, mfpSortDir);
        const av = a[mfpSortCol], bv = b[mfpSortCol];
        if (av == null && bv == null) return 0;
        if (typeof av === 'string') return mfpSortDir * av.localeCompare(bv);
        return mfpSortDir * ((av || 0) - (bv || 0));
    });
    const ok = mfpGrps.filter(g => g.status === 'ok').length;
    const ov = mfpGrps.filter(g => g.status === 'over').length;
    const sh = mfpGrps.filter(g => g.status === 'short').length;
    const mfpTotalInsPaid = mfpGrps.reduce((s,g)=>s+(g.totalInsPaid||0),0);
    const mfpTotalSupCost = mfpGrps.reduce((s,g)=>s+(g.totalSupplyCost||0),0);
    document.getElementById('mfp-summary-bar').innerHTML = `<div class="summary-pill"><div class="pill-dot ok"></div><span>OK: <strong class="pill-count">${ok}</strong></span></div><div class="summary-pill"><div class="pill-dot over"></div><span>Over: <strong class="pill-count">${ov}</strong></span></div><div class="summary-pill"><div class="pill-dot short"></div><span>Short: <strong class="pill-count">${sh}</strong></span></div><div class="summary-pill" style="margin-left:8px;color:var(--text-muted)">MFP NDCs matched: <strong>${mfpGrps.length}</strong></div><div class="summary-pill" style="color:var(--mfp);font-weight:600">Year: ${mfpActiveYear === 'all' ? 'All' : mfpActiveYear === '2026' ? '2026' : mfpActiveYear === '2027' ? '2026–2027' : mfpActiveYear === '2028' ? '2026–2028' : mfpActiveYear}</div><div class="summary-pill" style="margin-left:auto;background:#f0fdf4;border-color:#bbf7d0">Ins Paid: <strong style="color:#059669">${fmtD(mfpTotalInsPaid)}</strong></div><div class="summary-pill" style="background:#f5f3ff;border-color:#ddd6fe">Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtD(mfpTotalSupCost)}</strong></div>`;
    if (typeof emCacheRows === 'function') emCacheRows('mfp', mfpGrps, { insFilter: filterIns ? insF : null });
    const tbody = document.getElementById('mfp-body');
    if (!mfpGrps.length) { tbody.innerHTML = `<tr><td colspan="11" class="empty-state">No MFP records match.</td></tr>`; return; }
    const frag = document.createDocumentFragment();
    let sr = 0, curNDC = null;
    for (const grp of mfpGrps) {
        const insRows = filterIns ? grp.insurerRows.filter(r => r.insName === insF) : grp.insurerRows;
        for (const ins of insRows) {
            if (grp.ndc !== curNDC) { curNDC = grp.ndc; sr = 1; } else sr++;
            const isHL = ins.qty === grp.maxQty, d = grp.totalPurchaseQty - ins.qty;
            const mfpPkg = grp.packageSize || 0;
            const tr = document.createElement('tr'); tr.className = 'row-detail';
            const insPaidRow = ins.insPaid || 0;
            tr.innerHTML = `<td class="sr-cell">${sr}</td><td class="col-desc">${descCellHtml(grp.drgName || grp.description, grp.strong, grp.form, srch)}</td><td class="ndc-plain" onclick="copyText('${grp.ndc}')">${grp.ndc}</td><td class="qty-cell">${grp.packageSize ? grp.packageSize.toFixed(3) : ''}</td><td class="${isHL ? 'hl-ins' : ''}">${ins.insName}</td><td class="${isHL ? 'hl-bin' : ''}" style="white-space:nowrap">${ins.binNo}</td><td class="qty-cell${isHL ? ' hl-qty' : ''}">${qtyDisp(ins.qty, mfpPkg)}</td><td class="qty-cell">${qtyDisp(grp.totalPurchaseQty, mfpPkg)}</td><td class="diff-cell">${diffHtmlFn(d, mfpPkg)}</td><td></td><td style="text-align:right;padding:4px 8px">${insPaidRow > 0 ? fmtDCell(insPaidRow,'#059669') : '<span style="color:#e2e8f0">—</span>'}</td><td style="text-align:right;padding:4px 8px">${fmtDCell(grp.totalSupplyCost||0,'var(--rxa-primary,#7c3aed)')}</td>`;
            frag.appendChild(tr);
        }
        if (!filterIns) {
            sr++;
            const d = grp.diff;
            const pkg = grp.packageSize || 0;
            const tr = document.createElement('tr'); tr.className = `row-total status-${grp.status}`;
            tr.innerHTML = `<td class="sr-cell">${sr}</td><td class="col-desc">${descCellHtml(grp.drgName || grp.description, grp.strong, grp.form, '')}</td><td class="ndc-plain" onclick="copyText('${grp.ndc}')">${grp.ndc}</td><td></td><td></td><td></td><td class="qty-cell">${qtyDisp(grp.totalRxQty, pkg)}</td><td class="qty-cell">${qtyDisp(grp.totalPurchaseQty, pkg)}</td><td></td><td>${statusHtmlFn(d, pkg)}</td><td style="text-align:right;padding:4px 8px">${fmtDCell(grp.totalInsPaid||0,'#059669')}</td><td style="text-align:right;padding:4px 8px">${fmtDCell(grp.totalSupplyCost||0,'var(--rxa-primary,#7c3aed)')}</td>`;
            frag.appendChild(tr);
        }
    }
    tbody.innerHTML = ''; tbody.appendChild(frag);
}

// ════════════════════════════════════
//  FINAL TAB
// ════════════════════════════════════

function renderFinalTab() {
    const container = document.getElementById('final-content');
    if (!ndcGroups.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">✅</div><span>No data — upload and reconcile files first.</span></div>`; return; }
    let rows = [...ndcGroups].map(g => {
        const insurerNames = [...new Set(g.insurerRows.map(r => r.insName).filter(Boolean))];
        const pkg = g.packageSize || 0;
        const initsPerPkg = pkg > 0 && g.totalRxQty > 0 ? Math.round(g.totalRxQty / pkg) : null;
        return { ndc: g.ndc, desc: g.description, drgName: g.drgName, strong: g.strong, form: g.form, needed: g.totalRxQty, ordered: g.totalPurchaseQty, variance: g.diff, status: g.status, packageSize: pkg, insurers: insurerNames, initsPerPkg, totalSupplyCost: g.totalSupplyCost || 0, totalInsPaid: g.totalInsPaid || 0, dollarDiff: g.dollarDiff || 0 };
    });
    const finalInsurers = [...new Set(rows.flatMap(r => r.insurers))].sort();
    if (finalStatusFilter !== 'all') rows = rows.filter(r => r.status === finalStatusFilter);
    if (finalInsFilter !== 'all') rows = rows.filter(r => r.insurers.includes(finalInsFilter));
    if ((finalSortCol === 'status' || finalSortCol === 'variance') && typeof finalSortDir === 'string') {
        rows.sort((a, b) => statusRank(a.status, finalSortDir) - statusRank(b.status, finalSortDir));
    } else {
        rows.sort((a, b) => { let av = a[finalSortCol], bv = b[finalSortCol]; if (typeof av === 'string') return finalSortDir * av.localeCompare(bv); return finalSortDir * ((av || 0) - (bv || 0)); });
    }
    if (finalSearch) { const s = finalSearch.toLowerCase(); const nS = normalizeNDCSearch(s); rows = rows.filter(r => r.ndc.includes(nS) || r.ndc.includes(s) || r.desc.toLowerCase().includes(s) || r.insurers.some(i => i.toLowerCase().includes(s))); }
    const okAll = ndcGroups.filter(g => g.status === 'ok').length, ovAll = ndcGroups.filter(g => g.status === 'over').length, shAll = ndcGroups.filter(g => g.status === 'short').length;
    function thCls(col) { return finalSortCol === col ? (finalSortDir === 1 ? 'asc' : 'desc') : ''; }
    const fBtn = (s, label, color, bg) => `<button onclick="setFinalStatus('${s}')" style="padding:4px 11px;border-radius:4px;border:1px solid ${finalStatusFilter === s ? color : 'var(--border)'};background:${finalStatusFilter === s ? color : bg || 'var(--surface)'};color:${finalStatusFilter === s ? '#fff' : color};font-size:12px;font-weight:600;cursor:pointer;transition:all .15s">${label}</button>`;
    let html = `<div class="final-outer"><div class="final-header"><div class="final-title">Variance: <span>Needed vs Ordered</span></div><div style="display:flex;gap:8px;align-items:center;margin:0 8px;background:rgba(var(--rxa-primary-rgb,124,58,237),.11);padding:4px 4px;border-radius:4px;">${fBtn('all', 'All', '#374151')}${fBtn('ok', 'OK', '#16a34a')}${fBtn('over', 'Over', '#b45309')}${fBtn('short', 'Short', '#dc2626')}</div>
    <select class="select-filter" onchange="finalSetIns(this.value)"><option value="all">All Insurers</option>${finalInsurers.map(ins => `<option value="${escHtml(ins)}" ${finalInsFilter===ins?'selected':''}>${escHtml(ins)}</option>`).join('')}</select>
    <div class="final-header-spacer"></div><button class="qs-btn" onclick="tabColReset('final',renderFinalTab)" title="Reset column order" style="font-size:10px;color:#6b7280;"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Cols</button><div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="final-search-inp" placeholder="Search NDC, name, insurer..." value="${escHtml(finalSearch)}" oninput="finalSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'final-search-inp\').value=\'\';finalSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div><button class="export-btn" onclick="openExportModal('final')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button></div><div style="background:var(--surface);border-bottom:1px solid var(--border);padding:5px 16px;display:flex;gap:14px;flex-shrink:0;align-items:center"><div class="summary-pill"><div class="pill-dot ok"></div><span>OK: <strong class="pill-count">${okAll}</strong></span></div><div class="summary-pill"><div class="pill-dot over"></div><span>Over: <strong class="pill-count">${ovAll}</strong></span></div><div class="summary-pill"><div class="pill-dot short"></div><span>Short: <strong class="pill-count">${shAll}</strong></span></div><div class="summary-pill" style="margin-left:8px;color:var(--text-muted)">Showing: <strong>${rows.length}</strong></div><div class="summary-pill" style="margin-left:auto"><span>Total Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtD(rows.reduce((s,r)=>s+r.totalSupplyCost,0))}</strong></span></div><div class="summary-pill"><span>Total Ins Paid: <strong style="color:#059669">${fmtD(rows.reduce((s,r)=>s+r.totalInsPaid,0))}</strong></span></div></div><div class="final-table-wrap"><table class="final-table"><thead>${tabColHeader('final', finalSortCol, finalSortDir, 'finalSort')}</thead><tbody>`;
    if (typeof emCacheRows === 'function') emCacheRows('final', rows);
    rows.forEach((r, i) => {
        const rowCls = r.status === 'ok' ? 'final-row-ok' : r.status === 'over' ? 'final-row-over' : 'final-row-short';
        const pkg = r.packageSize || 0;
        const insChips = r.insurers.map(ins => `<span style="display:inline-block;background:rgba(0,0,0,.06);padding:1px 5px;border-radius:3px;font-size:10px;margin:1px 2px 1px 0;white-space:nowrap">${finalSearch ? hlText(escHtml(ins), finalSearch) : escHtml(ins)}</span>`).join('');
        let varDisp;
        if (pkgDivideOn && pkg > 0) {
            const vPkg   = r.variance / pkg;
            const abs    = Math.abs(vPkg);
            const absStr = abs % 1 === 0 ? abs.toFixed(1) : abs.toFixed(2);
            varDisp = vPkg === 0 ? '0.0'
                : vPkg > 0 ? `<span class="pkg-div-val">+${absStr}</span>`
                : `<span class="pkg-div-val" style="color:var(--short)">-${absStr}</span>`;
        } else {
            const abs = Math.abs(r.variance).toFixed(1);
            varDisp = r.variance === 0 ? '0.0'
                : r.variance > 0 ? `+${abs}`
                : `-${abs}`;
        }
        // Use shared statusHtmlFn so STATUS always shows amount (÷PKG or normal)
        const statDisp = statusHtmlFn(r.variance, pkg);
        const CELLS = {
            sr:       () => `<td style="text-align:center;font-weight:700;font-size:11px">${i + 1}</td>`,
            ndc:      () => `<td><span class="final-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td>`,
            desc:     () => `<td style="min-width:220px">${descCellHtml(r.drgName || r.desc, r.strong, r.form, finalSearch)}</td>`,
            pkg:      () => `<td class="final-num">${r.packageSize ? r.packageSize.toFixed(3) : ''}</td>`,
            insurers: () => `<td style="font-size:11px">${insChips || '—'}</td>`,
            inits:    () => `<td class="final-num">${r.initsPerPkg != null ? r.initsPerPkg : ''}</td>`,
            needed:   () => `<td class="final-num">${qtyDisp(r.needed, pkg)}</td>`,
            ordered:  () => `<td class="final-num">${qtyDisp(r.ordered, pkg)}</td>`,
            variance: () => `<td class="final-num">${varDisp}</td>`,
            cost:     () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalSupplyCost,'var(--rxa-primary,#7c3aed)')}</td>`,
            paid:     () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalInsPaid,'#059669')}</td>`,
            status:   () => `<td style="font-weight:700;font-size:12px">${statDisp}</td>`,
        };
        html += `<tr class="${rowCls}">` + tabColOrdered('final').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + `</tr>`;
    });
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('final-search-inp'); if (inp && finalSearch) { inp.focus(); inp.setSelectionRange(finalSearch.length, finalSearch.length); }
}

function setFinalStatus(s) { finalStatusFilter = s; renderFinalTab(); }
function finalSetIns(v) { finalInsFilter = v; renderFinalTab(); }
const finalSearchFn = debounce(v => { finalSearch = v; renderFinalTab(); }, 200);
function finalSortPreset(col, dir) { finalSortCol = col; finalSortDir = dir; renderFinalTab(); }
function finalSort(col) { if (col === 'sr') return; if (finalSortCol === col) { finalSortDir *= -1; } else { finalSortCol = col; finalSortDir = (col === 'desc' || col === 'ndc' || col === 'status') ? 1 : -1; } renderFinalTab(); }

// ════════════════════════════════════
//  NOT BILLED TAB
// ════════════════════════════════════

function renderNotBilledTab() {
    const container = document.getElementById('notbilled-content');
    if (!Object.keys(purchaseMap).length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">⚠️</div><span>No data — upload and reconcile files first.</span></div>`; return; }
    const billedNdcs = new Set(billingRows.map(r => r.ndc));
    let rows = Object.keys(purchaseMap).filter(ndc => !billedNdcs.has(ndc)).map(ndc => {
        const sup = purchaseMap[ndc]; const fileTotals = supFileTotals[ndc] || {};
        const transactions = supTransactions[ndc] || [];
        const pkgSizes = [...new Set(transactions.map(t => t.sz))].sort((a, b) => a - b);
        const totalExtPrice = sup.totalExtPrice || 0;
        const supM = purchaseMap[ndc] || {};
        return { ndc, desc: supM.description, nameDisp: supM.description || '', strongDisp: supM.strong || '', formDisp: supM.form || '', totalQty: supM.totalQty, totalExtPrice: supM.totalExtPrice || 0, fileTotals, transactions, pkgSizes };
    });
    const nbForms = [...new Set(rows.map(r => r.formDisp).filter(Boolean))].sort();
    rows.sort((a, b) => {
        if (nbSortCol === 'ndc') return nbSortDir * a.ndc.localeCompare(b.ndc);
        if (nbSortCol === 'pkgSize') return nbSortDir * ((a.pkgSizes.length ? a.pkgSizes[0] : 0) - (b.pkgSizes.length ? b.pkgSizes[0] : 0));
        if (nbSortCol === 'desc') return nbSortDir * a.desc.localeCompare(b.desc);
        if (nbSortCol === 'total') return nbSortDir * (a.totalQty - b.totalQty);
        const av = a[nbSortCol], bv = b[nbSortCol];
        if (av == null && bv == null) return 0;
        if (typeof av === 'string') return nbSortDir * av.localeCompare(bv);
        return nbSortDir * ((av || 0) - (bv || 0));
    });
    if (nbSearch) { const s = nbSearch.toLowerCase(); const nS = normalizeNDCSearch(s); rows = rows.filter(r => r.ndc.includes(nS) || r.ndc.includes(s) || r.desc.toLowerCase().includes(s)); }
    if (nbFormFilter !== 'all') rows = rows.filter(r => r.formDisp === nbFormFilter);
    if (typeof emCacheRows === 'function') emCacheRows('notbilled', rows);
    function thCls(col) { return nbSortCol === col ? (nbSortDir === 1 ? 'asc' : 'desc') : ''; }
    function fileChips(fileTotals) { return Object.entries(fileTotals).map(([f, t]) => { const sh = f.length > 22 ? f.slice(0, 19) + '…' : f; return `<span class="nb-file-chip">${escHtml(sh)} (${t.toLocaleString()})</span>`; }).join(''); }
    function pkgSizeCell(pkgSizes) { if (!pkgSizes.length) return '—'; return pkgSizes.map(sz => sz === Math.floor(sz) ? Math.floor(sz) : sz).join(', '); }
    function calcCell(transactions) { if (!transactions.length) return '—'; return transactions.map(t => `(${t.qty}x${t.sz === Math.floor(t.sz) ? Math.floor(t.sz) : t.sz})`).join(' + '); }
    let html = `<div class="nb-outer"><div class="nb-header"><div class="nb-title">Not Billed: <span>${rows.length} NDCs</span> &nbsp;<small style="font-size:11px;font-weight:400;color:var(--text-muted)">— Ordered by supplier but no billing record found</small></div>
    <select class="select-filter" style="margin:0 10px;" onchange="nbSetForm(this.value)"><option value="all">All Drug Forms</option>${nbForms.map(f => `<option value="${escHtml(f)}" ${nbFormFilter===f?'selected':''}>${escHtml(f)}</option>`).join('')}</select>
    <div class="nb-header-spacer"></div><button class="qs-btn" onclick="tabColReset('notbilled',renderNotBilledTab)" title="Reset column order" style="font-size:10px;color:#6b7280;"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Cols</button><div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="nb-search-inp" placeholder="Search NDC or description..." value="${escHtml(nbSearch)}" oninput="nbSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'nb-search-inp\').value=\'\';nbSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div><button class="export-btn" onclick="openExportModal('notbilled')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button></div><div class="nb-summary-bar"><div class="nb-summary-pill">Total Unmatched NDCs: <strong>${rows.length}</strong></div><div class="nb-summary-pill" style="margin-left:8px;">Total Ordered Qty: <strong>${rows.reduce((s, r) => s + r.totalQty, 0).toLocaleString()}</strong></div><div class="nb-summary-pill" style="margin-left:8px">Total Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtD(rows.reduce((s,r)=>s+(r.totalExtPrice||0),0))}</strong></div></div><div class="nb-table-wrap"><table class="nb-table"><thead>${tabColHeader('notbilled', nbSortCol, nbSortDir, 'nbSort')}</thead><tbody>`;
    if (!rows.length) { html += `<tr><td colspan="9" class="empty-state" style="background:#fff7ed">🎉 All supplier NDCs have matching billing records.</td></tr>`; }
    else { rows.forEach((r, i) => {
        const CELLS = {
            sr:    () => `<td style="text-align:center;font-weight:700;font-size:11px;color:#92400e">${i + 1}</td>`,
            ndc:   () => `<td><span class="nb-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td>`,
            desc:  () => `<td>${descCellHtml(r.nameDisp, r.strongDisp, r.formDisp, nbSearch)}</td>`,
            pkg:   () => `<td style="text-align:right;font-variant-numeric:tabular-nums;">${pkgSizeCell(r.pkgSizes)}</td>`,
            files: () => `<td>${fileChips(r.fileTotals)}</td>`,
            calc:  () => `<td class="sup-calc">${escHtml(calcCell(r.transactions))}</td>`,
            cost:  () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalExtPrice,'var(--rxa-primary,#7c3aed)')}</td>`,
            qty:   () => `<td class="nb-num" style="color:#b45309">${r.totalQty.toLocaleString()}</td>`,
            status: () => `<td style="text-align:center"><span class="nb-badge">NOT BILLED</span></td>`,
        };
        html += '<tr>' + tabColOrdered('notbilled').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + '</tr>';
    }); }
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('nb-search-inp'); if (inp && nbSearch) { inp.focus(); inp.setSelectionRange(nbSearch.length, nbSearch.length); }
}

const nbSearchFn = debounce(v => { nbSearch = v; renderNotBilledTab(); }, 200);
function nbSortPreset(col, dir) { nbSortCol = col; nbSortDir = dir; renderNotBilledTab(); }
function nbSetForm(v) { nbFormFilter = v; renderNotBilledTab(); }
function nbSort(col) { if (nbSortCol === col) { nbSortDir *= -1; } else { nbSortCol = col; nbSortDir = (col === 'total' || col === 'pkgSize' || col === 'extPrice') ? -1 : 1; } renderNotBilledTab(); }

// ════════════════════════════════════
//  BILL TAB
// ════════════════════════════════════

function renderBillTab() {
    const container = document.getElementById('bill-content');
    if (!ndcGroups.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">💵</div><span>No data — run reconciliation first.</span></div>`; return; }
    const insMap = {};
    for (const grp of ndcGroups) {
        for (const ins of grp.insurerRows) { const key = ins.insName || 'UNKNOWN'; if (!insMap[key]) insMap[key] = { insName: ins.insName, bins: new Set(), ndcs: new Set(), totalRxQty: 0, totalPurchaseQty: 0, totalInsPaid: 0, totalSupplyCost: 0, ok: 0, over: 0, short: 0 }; for (const b of ins.bins) insMap[key].bins.add(b); insMap[key].ndcs.add(grp.ndc); insMap[key].totalRxQty += ins.qty; insMap[key].totalInsPaid += (ins.insPaid || 0); insMap[key][grp.status]++; }
        for (const ins of grp.insurerRows) { const key = ins.insName || 'UNKNOWN'; if (insMap[key] && !insMap[key]['_ndcPurchase' + grp.ndc]) { insMap[key]['_ndcPurchase' + grp.ndc] = true; insMap[key].totalPurchaseQty += grp.totalPurchaseQty; insMap[key].totalSupplyCost += (grp.totalSupplyCost || 0); } }
    }
    let rows = Object.values(insMap).map(r => ({ insName: r.insName, bins: [...r.bins].sort(), ndcCount: r.ndcs.size, totalRxQty: r.totalRxQty, totalPurchaseQty: r.totalPurchaseQty, totalInsPaid: r.totalInsPaid || 0, totalSupplyCost: r.totalSupplyCost || 0, ok: r.ok, over: r.over, short: r.short }));
    rows.sort((a, b) => { if (billSortCol === 'insName') return billSortDir * a.insName.localeCompare(b.insName); if (billSortCol === 'ndcCount') return billSortDir * (a.ndcCount - b.ndcCount); if (billSortCol === 'totalInsPaid') return billSortDir * (a.totalInsPaid - b.totalInsPaid); if (billSortCol === 'totalSupplyCost') return billSortDir * (a.totalSupplyCost - b.totalSupplyCost); if (billSortCol === 'ok') return billSortDir * (a.ok - b.ok); if (billSortCol === 'over') return billSortDir * (a.over - b.over); if (billSortCol === 'short') return billSortDir * (a.short - b.short); if (billSortCol === 'totalPurchaseQty') return billSortDir * (a.totalPurchaseQty - b.totalPurchaseQty); return billSortDir * (a.totalRxQty - b.totalRxQty); });
    if (billSearch) { const s = billSearch.toLowerCase(); rows = rows.filter(r => r.insName.toLowerCase().includes(s) || r.bins.some(b => b.includes(s))); }
    if (billIssuesOnly) rows = rows.filter(r => r.over > 0 || r.short > 0);
    if (typeof emCacheRows === 'function') emCacheRows('bill', rows);
    const hl = v => billSearch ? hlText(escHtml(String(v)), billSearch) : escHtml(String(v));
    const totalRxQty = rows.reduce((s, r) => s + r.totalRxQty, 0); const totalPurchaseQty = rows.reduce((s, r) => s + r.totalPurchaseQty, 0); const totalNDCs = new Set(ndcGroups.map(g => g.ndc)).size;
    function thCls(col) { return billSortCol === col ? (billSortDir === 1 ? 'asc' : 'desc') : ''; }
    let html = `<div class="bill-outer"><div class="bill-header"><div class="bill-title">Bill: <span>By Insurer / Payer</span></div>
    <label style="display:flex;align-items:center;gap:6px;margin:0 10px;font-size:12px;font-weight:600;color:${billIssuesOnly?'#dc2626':'var(--text-muted)'};cursor:pointer;white-space:nowrap;">
        <input type="checkbox" ${billIssuesOnly?'checked':''} onchange="billSetIssuesOnly(this.checked)" style="cursor:pointer;"> ⚠ Has Issues Only
    </label>
    <div style="flex:1"></div><button class="qs-btn" onclick="tabColReset('bill',renderBillTab)" title="Reset column order" style="font-size:10px;color:#6b7280;"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Cols</button><div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="bill-search-inp" placeholder="Search insurer or BIN..." value="${escHtml(billSearch)}" oninput="billSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'bill-search-inp\').value=\'\';billSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div><button class="export-btn" onclick="openExportModal('bill')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button></div><div class="bill-summary-bar"><div class="summary-pill"><span>Insurers: <strong class="pill-count">${rows.length}</strong></span></div><div class="summary-pill"><span>Total NDCs: <strong class="pill-count">${totalNDCs}</strong></span></div><div class="summary-pill"><span>Total Ins Paid: <strong style="color:#059669">${fmtD(rows.reduce((s,r)=>s+r.totalInsPaid,0))}</strong></span></div><div class="summary-pill"><span>Total Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtD(rows.reduce((s,r)=>s+r.totalSupplyCost,0))}</strong></span></div></div><div class="bill-table-wrap"><table class="bill-table"><thead>${tabColHeader('bill', billSortCol, billSortDir, 'billSort')}</thead><tbody>`;
    rows.forEach((r, i) => {
        const CELLS = {
            sr:      () => `<td style="text-align:center;font-weight:700;color:var(--text-muted);font-size:11px">${i + 1}</td>`,
            insurer: () => `<td class="bill-ins-name">${hl(r.insName)}</td>`,
            bins:    () => `<td class="bill-bin-chips">${r.bins.map(b => `<span>${escHtml(b)}</span>`).join('')}</td>`,
            ndcs:    () => `<td class="bill-num">${r.ndcCount.toLocaleString()}</td>`,
            rxqty:   () => `<td class="bill-num">${r.totalRxQty.toLocaleString()}</td>`,
            purqty:  () => `<td class="bill-num" style="color:var(--primary);font-weight:700">${r.totalPurchaseQty.toLocaleString()}</td>`,
            paid:    () => `<td style="text-align:right;padding:6px 10px">${fmtDCell(r.totalInsPaid,'#059669')}</td>`,
            cost:    () => `<td style="text-align:right;padding:6px 10px">${fmtDCell(r.totalSupplyCost,'var(--rxa-primary,#7c3aed)')}</td>`,
            ok:      () => `<td style="text-align:center">${r.ok ? `<span class="bill-ok-pill">${r.ok}</span>` : ''}</td>`,
            over:    () => `<td style="text-align:center">${r.over ? `<span class="bill-over-pill">${r.over}</span>` : ''}</td>`,
            short:   () => `<td style="text-align:center">${r.short ? `<span class="bill-short-pill">${r.short}</span>` : ''}</td>`,
        };
        html += '<tr>' + tabColOrdered('bill').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + '</tr>';
    });
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('bill-search-inp'); if (inp && billSearch) { inp.focus(); inp.setSelectionRange(billSearch.length, billSearch.length); }
}

const billSearchFn = debounce(v => { billSearch = v; renderBillTab(); }, 200);
function billSortPreset(col, dir) { billSortCol = col; billSortDir = dir; renderBillTab(); }
function billSetIssuesOnly(checked) { billIssuesOnly = checked; renderBillTab(); }
function billSort(col) { if (billSortCol === col) { billSortDir *= -1; } else { billSortCol = col; billSortDir = (col === 'insName') ? 1 : -1; } renderBillTab(); }

// ════════════════════════════════════
//  DISCARDED TAB
// ════════════════════════════════════

function renderDiscardedTab() {
    const container = document.getElementById('discarded-content');
    if (!billingRows.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">🗑️</div><span>No data — run reconciliation first.</span></div>`; return; }
    const suppliedNdcs = new Set(Object.keys(purchaseMap)); const discMap = {};
    for (const r of billingRows) {
        if (suppliedNdcs.has(r.ndc)) continue;
        if (!discMap[r.ndc]) discMap[r.ndc] = { ndc: r.ndc, desc: r.drgName || '', strong: r.strong || '', form: r.form || '', insurerQty: {}, total: 0 };
        const ins = r.insName || 'UNKNOWN'; if (!discMap[r.ndc].insurerQty[ins]) discMap[r.ndc].insurerQty[ins] = { qty: 0, paid: 0 }; discMap[r.ndc].insurerQty[ins].qty += r.qty; discMap[r.ndc].insurerQty[ins].paid += (r.insPaid || 0); discMap[r.ndc].total += r.qty; discMap[r.ndc].totalPaid = (discMap[r.ndc].totalPaid || 0) + (r.insPaid || 0);
        if (!discMap[r.ndc].desc && r.drgName) discMap[r.ndc].desc = r.drgName;
        if (!discMap[r.ndc].strong && r.strong) discMap[r.ndc].strong = r.strong;
        if (!discMap[r.ndc].form && r.form) discMap[r.ndc].form = r.form;
    }
    let rows = Object.values(discMap).map(r => ({ ...r, insurers: Object.entries(r.insurerQty).map(([ins,v])=>[ins,v.qty,v.paid]).sort((a, b) => b[1] - a[1]) }));
    const discInsurers = [...new Set(rows.flatMap(r => r.insurers.map(([ins]) => ins)))].sort();
    const discForms = [...new Set(rows.map(r => r.form).filter(Boolean))].sort();
    rows.sort((a, b) => {
        if (discSortCol === 'ndc') return discSortDir * a.ndc.localeCompare(b.ndc);
        if (discSortCol === 'total') return discSortDir * (a.total - b.total);
        if (discSortCol === 'totalPaid') return discSortDir * ((a.totalPaid||0) - (b.totalPaid||0));
        // Per-insurer columns (Insurer/Billed Qty/Ins Paid) are shown per row via
        // rowspan, so sorting the NDC-level list by them uses the row's top
        // insurer — insurers[] is already sorted by qty descending, so [0] is it.
        if (discSortCol === 'insurer') return discSortDir * (a.insurers[0]?.[0]||'').localeCompare(b.insurers[0]?.[0]||'');
        if (discSortCol === 'insQty')   return discSortDir * ((a.insurers[0]?.[1]||0) - (b.insurers[0]?.[1]||0));
        if (discSortCol === 'insPaid')  return discSortDir * ((a.insurers[0]?.[2]||0) - (b.insurers[0]?.[2]||0));
        return discSortDir * (a.desc || '').localeCompare(b.desc || '');
    });
    if (discSearch) { const s = discSearch.toLowerCase(); const nS = normalizeNDCSearch(s); rows = rows.filter(r => r.ndc.includes(nS) || r.ndc.includes(s) || (r.desc || '').toLowerCase().includes(s) || r.insurers.some(([ins]) => ins.toLowerCase().includes(s))); }
    if (discInsFilter !== 'all') rows = rows.filter(r => r.insurers.some(([ins]) => ins === discInsFilter)).map(r => ({ ...r, insurers: r.insurers.filter(([ins]) => ins === discInsFilter) }));
    if (discFormFilter !== 'all') rows = rows.filter(r => r.form === discFormFilter);
    if (typeof emCacheRows === 'function') emCacheRows('discarded', rows.map(r => ({...r, insurerData: Object.fromEntries(r.insurers.map(([ins,qty,paid]) => [ins,{qty,paid}]))})));
    function thCls(col) { return discSortCol === col ? (discSortDir === 1 ? 'asc' : 'desc') : ''; }
    let html = `<div class="disc-outer"><div class="disc-header"><div class="disc-title">Discarded: <span>${rows.length} NDCs</span> &nbsp;<small style="font-size:11px;font-weight:400;color:var(--rxa-primary-600,#6d28d9)">— Billed/dispensed but no supplier purchase record found</small></div>
    <select class="select-filter" style="margin:0 10px;" onchange="discSetIns(this.value)"><option value="all">All Insurers</option>${discInsurers.map(ins => `<option value="${escHtml(ins)}" ${discInsFilter===ins?'selected':''}>${escHtml(ins)}</option>`).join('')}</select>
    <select class="select-filter" style="margin-right:10px;" onchange="discSetForm(this.value)"><option value="all">All Drug Forms</option>${discForms.map(f => `<option value="${escHtml(f)}" ${discFormFilter===f?'selected':''}>${escHtml(f)}</option>`).join('')}</select>
    <div style="flex:1"></div><div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="disc-search-inp" placeholder="Search NDC, description or insurer..." value="${escHtml(discSearch)}" oninput="discSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'disc-search-inp\').value=\'\';discSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div><button class="export-btn" onclick="openExportModal('discarded')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button></div><div class="disc-summary-bar"><span>Total Unmatched: <strong>${rows.length}</strong></span><span>Total Billed Qty: <strong>${rows.reduce((s, r) => s + r.total, 0).toLocaleString()}</strong></span><span style="margin-left:12px">Total Ins Paid: <strong style="color:#059669">${fmtD(rows.reduce((s,r)=>s+(r.totalPaid||0),0))}</strong></span></div><div class="disc-table-wrap"><table class="disc-table"><thead><tr><th style="width:44px;text-align:center">Sr#</th><th style="width:108px" onclick="discSort('ndc')" class="${thCls('ndc')}">NDC</th><th style="min-width:220px" onclick="discSort('desc')" class="${thCls('desc')}">Description <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'discSortPreset','desc','text')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span></th><th style="min-width:180px">Insurer <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'discSortPreset','insurer','text')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span></th><th style="width:110px;text-align:right">Billed QTY <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'discSortPreset','insQty','num')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span></th><th style="width:110px;text-align:right;color:#059669">Ins Paid ($) <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'discSortPreset','insPaid','num')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span></th><th style="width:110px;text-align:right" onclick="discSort('total')" class="${thCls('total')}">Total Billed <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'discSortPreset','total','num')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span></th><th style="width:120px;text-align:right;color:#059669">Total Ins Paid <span class="col-filter-caret" onclick="event.stopPropagation();colHeaderShowMenu(event,'discSortPreset','totalPaid','num')" title="Sort options"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 4h18a1 1 0 0 1 .8 1.6l-6.8 8.7V19a1 1 0 0 1-.45.84l-3 2A1 1 0 0 1 10 21v-6.7L3.2 5.6A1 1 0 0 1 4 4z"/></svg></span></th><th style="width:110px;text-align:center">Status</th></tr></thead><tbody>`;
    if (!rows.length) { html += `<tr><td colspan="7" class="empty-state" style="background:#fdf4ff">🎉 All billed NDCs have matching supplier records.</td></tr>`; }
    else { rows.forEach((r, i) => { const rowspan = r.insurers.length || 1; if (r.insurers.length === 0) { html += `<tr><td style="text-align:center;font-weight:700;font-size:11px;color:var(--rxa-primary-600,#6d28d9)">${i + 1}</td><td><span class="disc-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td>${descCellHtml(r.desc, r.strong, r.form, discSearch)}</td><td>—</td><td class="disc-num">0</td><td class="disc-num">—</td><td class="disc-num">${r.total.toLocaleString()}</td><td class="disc-num">—</td><td style="text-align:center"><span class="disc-badge">NO SUPPLIER</span></td></tr>`; } else { r.insurers.forEach(([insName, qty, paid], j) => { html += `<tr>`; if (j === 0) { html += `<td rowspan="${rowspan}" style="text-align:center;font-weight:700;font-size:11px;color:var(--rxa-primary-600,#6d28d9);vertical-align:top;padding-top:8px">${i + 1}</td><td rowspan="${rowspan}" style="vertical-align:top;padding-top:8px"><span class="disc-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td rowspan="${rowspan}" style="vertical-align:top;padding-top:8px;min-width:220px">${descCellHtml(r.desc, r.strong, r.form, discSearch)}</td>`; } html += `<td><span style="display:inline-block;background:#ede9fe;color:var(--rxa-primary-600,#6d28d9);padding:1px 6px;border-radius:3px;font-size:10.5px;font-weight:600">${discSearch ? hlText(escHtml(insName), discSearch) : escHtml(insName)}</span></td><td class="disc-num">${qty.toLocaleString()}</td><td class="disc-num" style="font-size:11px">${fmtDCell(paid,'#059669')}</td>`; if (j === 0) { html += `<td rowspan="${rowspan}" class="disc-num" style="font-size:13px;vertical-align:middle">${r.total.toLocaleString()}</td><td rowspan="${rowspan}" style="text-align:right;padding:6px 8px;vertical-align:middle">${fmtDCell(r.totalPaid||0,'#059669')}</td><td rowspan="${rowspan}" style="text-align:center;vertical-align:middle"><span class="disc-badge">NO SUPPLIER</span></td>`; } html += `</tr>`; }); } }); }
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('disc-search-inp'); if (inp && discSearch) { inp.focus(); inp.setSelectionRange(discSearch.length, discSearch.length); }
}

const discSearchFn = debounce(v => { discSearch = v; renderDiscardedTab(); }, 200);
function discSortPreset(col, dir) { discSortCol = col; discSortDir = dir; renderDiscardedTab(); }
function discSetIns(v) { discInsFilter = v; renderDiscardedTab(); }
function discSetForm(v) { discFormFilter = v; renderDiscardedTab(); }
function discSort(col) { if (discSortCol === col) { discSortDir *= -1; } else { discSortCol = col; discSortDir = (col === 'total') ? -1 : 1; } renderDiscardedTab(); }

// ════════════════════════════════════
//  ISSUES TAB
// ════════════════════════════════════

function renderIssuesTab() {
    const container = document.getElementById('issues-content');
    if (!ndcGroups.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">⚠️</div><span>No data — run reconciliation first.</span></div>`; return; }

    // IMPROVEMENT 11: show both SHORT and OVER
    let shortRows = ndcGroups.filter(g => g.status === 'short').map(g => {
        const shortAmt = Math.abs(g.diff); const pkg = g.packageSize || 0;
        const unitsNeeded = pkg > 0 ? Math.ceil(shortAmt / pkg) : null;
        const topIns = [...g.insurerRows].sort((a, b) => b.qty - a.qty)[0];
        return { ndc: g.ndc, desc: g.description, drgName: g.drgName, strong: g.strong, form: g.form, shortAmt, needed: g.totalRxQty, ordered: g.totalPurchaseQty, packageSize: pkg, unitsNeeded, topInsurer: topIns ? topIns.insName : '', insurerCount: g.insurerRows.length, type: 'short', totalInsPaid: g.totalInsPaid || 0, totalSupplyCost: g.totalSupplyCost || 0 };
    });
    let overRows = ndcGroups.filter(g => g.status === 'over').map(g => {
        const overAmt = Math.abs(g.diff); const pkg = g.packageSize || 0;
        const pkgsOver = pkg > 0 ? Math.floor(overAmt / pkg) : null;
        const topIns = [...g.insurerRows].sort((a, b) => b.qty - a.qty)[0];
        return { ndc: g.ndc, desc: g.description, drgName: g.drgName, strong: g.strong, form: g.form, overAmt, needed: g.totalRxQty, ordered: g.totalPurchaseQty, packageSize: pkg, pkgsOver, topInsurer: topIns ? topIns.insName : '', insurerCount: g.insurerRows.length, type: 'over', totalInsPaid: g.totalInsPaid || 0, totalSupplyCost: g.totalSupplyCost || 0 };
    });

    if (issSearch) {
        const s = issSearch.toLowerCase(); const nS = normalizeNDCSearch(s);
        shortRows = shortRows.filter(r => r.ndc.includes(nS) || r.ndc.includes(s) || r.desc.toLowerCase().includes(s) || r.topInsurer.toLowerCase().includes(s));
        overRows  = overRows.filter(r => r.ndc.includes(nS) || r.ndc.includes(s) || r.desc.toLowerCase().includes(s) || r.topInsurer.toLowerCase().includes(s));
    }
    if (issTypeFilter === 'short') overRows = [];
    if (issTypeFilter === 'over')  shortRows = [];
    if (issSortCol === 'desc') {
        shortRows.sort((a, b) => issSortDir * a.desc.localeCompare(b.desc));
        overRows.sort((a, b) => issSortDir * a.desc.localeCompare(b.desc));
    } else if (issSortCol === 'shortAmt' || issSortCol === 'overAmt') {
        // "Gap"/"Excess" occupy the same visual column across both tables but are
        // different fields — sort each table by its own matching field.
        shortRows.sort((a, b) => issSortDir * (a.shortAmt - b.shortAmt));
        overRows.sort((a, b) => issSortDir * (a.overAmt - b.overAmt));
    } else if (issSortCol === 'units') {
        // "Pkgs Short"/"Pkgs Over" — same dual-field situation as shortAmt/overAmt above.
        shortRows.sort((a, b) => issSortDir * ((a.unitsNeeded||0) - (b.unitsNeeded||0)));
        overRows.sort((a, b) => issSortDir * ((a.pkgsOver||0) - (b.pkgsOver||0)));
    } else {
        const cmp = (a, b) => {
            const av = a[issSortCol], bv = b[issSortCol];
            if (av == null && bv == null) return 0;
            if (typeof av === 'string') return issSortDir * av.localeCompare(bv);
            return issSortDir * ((av || 0) - (bv || 0));
        };
        shortRows.sort(cmp);
        overRows.sort(cmp);
    }

    if (typeof emCacheRows === 'function') {
        emCacheRows('issues', [
            ...shortRows.map(r => ({ ...r, _issType: 'short' })),
            ...overRows.map(r => ({ ...r, _issType: 'over' })),
        ]);
    }
    const totalShort = shortRows.reduce((s, r) => s + r.shortAmt, 0);
    const totalOver  = overRows.reduce((s, r) => s + r.overAmt, 0);

    function thCls(col) { return issSortCol === col ? (issSortDir === 1 ? 'asc' : 'desc') : ''; }

    let html = `<div class="iss-outer"><div class="iss-header"><div class="iss-title">Issues: <span>${shortRows.length} SHORT · ${overRows.length} OVER NDCs</span></div>
    <div style="display:flex;gap:4px;align-items:center;margin:0 10px;background:rgba(var(--rxa-primary-rgb,124,58,237),.11);padding:4px;border-radius:4px;">
        <button onclick="issSetType('all')" style="padding:4px 11px;border-radius:4px;border:1px solid ${issTypeFilter==='all'?'#374151':'var(--border)'};background:${issTypeFilter==='all'?'#374151':'var(--surface)'};color:${issTypeFilter==='all'?'#fff':'#374151'};font-size:12px;font-weight:600;cursor:pointer;">All</button>
        <button onclick="issSetType('short')" style="padding:4px 11px;border-radius:4px;border:1px solid ${issTypeFilter==='short'?'#dc2626':'var(--border)'};background:${issTypeFilter==='short'?'#dc2626':'var(--surface)'};color:${issTypeFilter==='short'?'#fff':'#dc2626'};font-size:12px;font-weight:600;cursor:pointer;">Short Only</button>
        <button onclick="issSetType('over')" style="padding:4px 11px;border-radius:4px;border:1px solid ${issTypeFilter==='over'?'#1e40af':'var(--border)'};background:${issTypeFilter==='over'?'#1e40af':'var(--surface)'};color:${issTypeFilter==='over'?'#fff':'#1e40af'};font-size:12px;font-weight:600;cursor:pointer;">Over Only</button>
    </div>
    <div style="flex:1"></div><button class="qs-btn" onclick="tabColReset('issues',renderIssuesTab)" title="Reset column order" style="font-size:10px;color:#6b7280;"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Cols</button><div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="iss-search-inp" placeholder="Search NDC, description or insurer..." value="${escHtml(issSearch)}" oninput="issSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'iss-search-inp\').value=\'\';issSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div><button class="export-btn" onclick="openExportModal('issues')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button></div>
    <div class="iss-summary-bar"><span>SHORT NDCs: <strong>${shortRows.length}</strong></span><span>Total Gap (units): <strong>${totalShort.toLocaleString()}</strong></span><span style="margin-left:12px;color:#1e40af">OVER NDCs: <strong>${overRows.length}</strong></span><span style="color:#1e40af">Excess Units: <strong>${totalOver.toLocaleString()}</strong></span><span style="margin-left:auto;background:#f0fdf4;border:1px solid #bbf7d0;padding:3px 10px;border-radius:4px">Total Ins Paid: <strong style="color:#059669">${fmtD([...shortRows,...overRows].reduce((s,r)=>s+(r.totalInsPaid||0),0))}</strong></span><span style="background:#f5f3ff;border:1px solid #ddd6fe;padding:3px 10px;border-radius:4px">Total Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtD([...shortRows,...overRows].reduce((s,r)=>s+(r.totalSupplyCost||0),0))}</strong></span></div>
    <div style="flex:1;overflow-y:auto;">`;

    // SHORT table
    html += `<div style="padding:8px 16px 4px;font-weight:700;font-size:12px;color:var(--short);background:#fff1f2;border-bottom:1px solid #fecdd3;">⬇ SHORT — purchased less than billed (${shortRows.length})</div>
    <div><table class="iss-table"><thead>${tabColHeader('issues', issSortCol, issSortDir, 'issSort', {short:'Gap (units)'})}</thead><tbody>`;
    if (!shortRows.length) { html += `<tr><td colspan="11" class="empty-state" style="background:#fff1f2">🎉 No SHORT issues found.</td></tr>`; }
    else { shortRows.forEach((r, i) => {
        const pctGap = r.needed > 0 ? ((r.shortAmt / r.needed) * 100).toFixed(1) : 0;
        const barW = Math.min(100, parseFloat(pctGap));
        const pkg = r.packageSize || 0;
        let neededDisp, orderedDisp, gapDisp, pkgsDisp;
        if (pkgDivideOn && pkg > 0) {
            neededDisp = `<span class="pkg-div-val">${divByPkg(r.needed, pkg)}</span>`;
            orderedDisp = `<span class="pkg-div-val">${divByPkg(r.ordered, pkg)}</span>`;
            const gapPkg = r.shortAmt / pkg; const gapStr = gapPkg % 1 === 0 ? gapPkg.toFixed(0) : gapPkg.toFixed(2);
            gapDisp = `<span style="font-weight:700;color:var(--short)" class="pkg-div-val">-${gapStr}</span><div style="margin-top:3px"><span class="iss-gap-bar" style="width:${barW}%;background:#fca5a5;"></span></div><div style="font-size:10px;color:#9f1239">${pctGap}% gap</div>`;
            pkgsDisp = `<span class="pkg-div-val">${r.unitsNeeded != null ? r.unitsNeeded : '—'}</span>`;
        } else {
            neededDisp = fmt(r.needed); orderedDisp = fmt(r.ordered);
            gapDisp = `<span style="font-weight:700;color:var(--short)">-${fmt(r.shortAmt)}</span><div style="margin-top:3px"><span class="iss-gap-bar" style="width:${barW}%;background:#fca5a5;"></span></div><div style="font-size:10px;color:#9f1239">${pctGap}% gap</div>`;
            pkgsDisp = r.unitsNeeded != null ? r.unitsNeeded : '—';
        }
        const CELLS = {
            sr:      () => `<td style="text-align:center;font-weight:700;font-size:11px;color:#9f1239">${i + 1}</td>`,
            ndc:     () => `<td><span class="iss-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td>`,
            desc:    () => `<td>${descCellHtml(r.drgName || r.desc, r.strong, r.form, issSearch)}</td>`,
            pkg:     () => `<td class="iss-num" style="color:var(--text)">${fmt(r.packageSize)}</td>`,
            needed:  () => `<td class="iss-num" style="color:var(--text)">${neededDisp}</td>`,
            ordered: () => `<td class="iss-num" style="color:var(--text)">${orderedDisp}</td>`,
            short:   () => `<td style="text-align:right">${gapDisp}</td>`,
            units:   () => `<td class="iss-num" style="color:var(--short)">${pkgsDisp}</td>`,
            paid:    () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalInsPaid,'#059669')}</td>`,
            cost:    () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalSupplyCost,'var(--rxa-primary,#7c3aed)')}</td>`,
            insurer: () => `<td style="font-size:11.5px;color:var(--text-muted)">${issSearch ? hlText(escHtml(r.topInsurer), issSearch) : escHtml(r.topInsurer)}${r.insurerCount > 1 ? ` <span style="font-size:10px;color:var(--primary)">(+${r.insurerCount - 1} more)</span>` : ''}</td>`,
        };
        html += '<tr>' + tabColOrdered('issues').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + '</tr>';
    }); }
    html += `</tbody></table></div>`;

    // OVER table
    html += `<div style="padding:8px 16px 4px;font-weight:700;font-size:12px;color:#1e40af;background:#eff6ff;border-bottom:1px solid #bfdbfe;border-top:2px solid #93c5fd;">⬆ OVER — purchased more than billed (${overRows.length})</div>
    <div><table class="iss-table" style="background:#eff6ff"><thead>${tabColHeader('issues', issSortCol, issSortDir, 'issSort', {short:'Excess Units', units:'Pkgs Over'}, 'background:#eff6ff;color:#1e40af')}</thead><tbody>`;
    if (!overRows.length) { html += `<tr><td colspan="11" class="empty-state" style="background:#eff6ff">🎉 No OVER issues found.</td></tr>`; }
    else { overRows.forEach((r, i) => {
        const pkg = r.packageSize || 0;
        const pkgsDisp = r.pkgsOver != null ? r.pkgsOver : '—';
        const CELLS = {
            sr:      () => `<td style="text-align:center;font-weight:700;font-size:11px;color:#1e40af">${i + 1}</td>`,
            ndc:     () => `<td><span class="iss-ndc" style="color:#1e40af" onclick="copyText('${r.ndc}')">${r.ndc}</span></td>`,
            desc:    () => `<td>${descCellHtml(r.drgName || r.desc, r.strong, r.form, issSearch)}</td>`,
            pkg:     () => `<td style="text-align:right;font-variant-numeric:tabular-nums;font-weight:600;color:#1e40af">${fmt(r.packageSize)}</td>`,
            needed:  () => `<td style="text-align:right;font-variant-numeric:tabular-nums;font-weight:600;color:#1e40af">${fmt(r.needed)}</td>`,
            ordered: () => `<td style="text-align:right;font-variant-numeric:tabular-nums;font-weight:600;color:#1e40af">${fmt(r.ordered)}</td>`,
            short:   () => `<td style="text-align:right;font-weight:700;color:#1e40af">+${fmt(r.overAmt)}</td>`,
            units:   () => `<td style="text-align:right;font-variant-numeric:tabular-nums;font-weight:600;color:#1e40af">${pkgsDisp}</td>`,
            paid:    () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalInsPaid,'#059669')}</td>`,
            cost:    () => `<td style="text-align:right;padding:6px 8px">${fmtDCell(r.totalSupplyCost,'var(--rxa-primary,#7c3aed)')}</td>`,
            insurer: () => `<td style="font-size:11.5px;color:var(--text-muted)">${escHtml(r.topInsurer)}${r.insurerCount > 1 ? ` <span style="font-size:10px;color:var(--primary)">(+${r.insurerCount - 1} more)</span>` : ''}</td>`,
        };
        html += '<tr style="background:#eff6ff">' + tabColOrdered('issues').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + '</tr>';
    }); }
    html += `</tbody></table></div></div></div>`;  // close OVER table div, scroll div, iss-outer

    container.innerHTML = html;
    const inp = document.getElementById('iss-search-inp'); if (inp && issSearch) { inp.focus(); inp.setSelectionRange(issSearch.length, issSearch.length); }
}

const issSearchFn = debounce(v => { issSearch = v; renderIssuesTab(); }, 200);
function issSortPreset(col, dir) { issSortCol = col; issSortDir = dir; renderIssuesTab(); }
function mfpSortPreset(col, dir) { mfpSortCol = col; mfpSortDir = dir; renderMFP(); }
function issSetType(t) { issTypeFilter = t; renderIssuesTab(); }
function issSort(col) { if (issSortCol === col) { issSortDir *= -1; } else { issSortCol = col; issSortDir = (col === 'desc' || col === 'ndc' || col === 'pkgSize') ? 1 : -1; } renderIssuesTab(); }

// ════════════════════════════════════
//  TAB SWITCHER
// ════════════════════════════════════

// ════════════════════════════════════
//  DOLLAR RECONCILIATION TAB
// ════════════════════════════════════

let dolSearch = '', dolSortCol = 'dollarDiff', dolSortDir = 1, dolStatusFilter = 'all';

const dolSearchFn = debounce(v => { dolSearch = v; renderDollarTab(); }, 200);
function dolSortPreset(col, dir) { dolSortCol = col; dolSortDir = dir; renderDollarTab(); }
function dolSort(col) { if (dolSortCol === col) dolSortDir *= -1; else { dolSortCol = col; dolSortDir = (col === 'description') ? 1 : -1; } renderDollarTab(); }
function dolSetStatus(s, btn) {
    dolStatusFilter = s;
    document.querySelectorAll('#dol-status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderDollarTab();
}

function renderDollarTab() {
    const container = document.getElementById('dollar-content');

    // Build rows: one per NDC with dollar data
    let rows = ndcGroups.map((g, i) => ({
        sr: i + 1,
        ndc: g.ndc,
        description: g.description,
        packageSize: g.packageSize,
        totalRxQty: g.totalRxQty,
        totalPurchaseQty: g.totalPurchaseQty,
        totalInsPaid: g.totalInsPaid || 0,
        totalSupplyCost: g.totalSupplyCost || 0,
        dollarDiff: g.dollarDiff || 0,
        unitPrice: g.unitPrice || 0,
        status: g.status,
    }));

    // Dollar status filter (over/under/match based on dollar diff)
    const dolSt = r => {
        if (!r.totalInsPaid && !r.totalSupplyCost) return 'nodata';
        if (Math.abs(r.dollarDiff) < 0.01) return 'match';
        return r.dollarDiff > 0 ? 'overpaid' : 'underpaid';
    };

    if (dolStatusFilter !== 'all') rows = rows.filter(r => dolSt(r) === dolStatusFilter);

    // Search
    if (dolSearch) {
        const s = normalizeNDCSearch(dolSearch.toLowerCase());
        rows = rows.filter(r =>
            normalizeNDCSearch(r.ndc).includes(s) ||
            r.description.toLowerCase().includes(dolSearch.toLowerCase())
        );
    }

    // Sort
    rows.sort((a, b) => {
        let av = a[dolSortCol], bv = b[dolSortCol];
        if (typeof av === 'string') return dolSortDir * av.localeCompare(bv);
        return dolSortDir * ((av || 0) - (bv || 0));
    });

    // Summary stats
    const totalSupCost  = rows.reduce((s, r) => s + r.totalSupplyCost, 0);
    const totalInsPaid  = rows.reduce((s, r) => s + r.totalInsPaid, 0);
    const totalDolDiff  = rows.reduce((s, r) => s + r.dollarDiff, 0);
    const ndcsWithData  = rows.filter(r => r.totalInsPaid > 0 || r.totalSupplyCost > 0).length;
    const matchCount    = rows.filter(r => dolSt(r) === 'match').length;
    const overpaidCount = rows.filter(r => dolSt(r) === 'overpaid').length;
    const underpaidCount= rows.filter(r => dolSt(r) === 'underpaid').length;
    const nodataCount   = rows.filter(r => dolSt(r) === 'nodata').length;

    if (typeof emCacheRows === 'function') emCacheRows('dollar', rows);
    const thCls = col => dolSortCol === col ? (dolSortDir === 1 ? 'asc' : 'desc') : '';
    const fmtD  = v => v == null || isNaN(v) ? '—' : '$' + Math.abs(v).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    const fmtDS = v => {
        if (v == null || isNaN(v) || v === 0) return '<span style="color:#6b7280">$0.00</span>';
        const s = '$' + Math.abs(v).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
        return v < 0 ? `<span style="color:#dc2626;font-weight:700">-${s}</span>` : `<span style="color:#2563eb;font-weight:700">+${s}</span>`;
    };

    let tbodyHtml = '';
    rows.forEach((r, idx) => {
        const ds = dolSt(r);
        let rowBg = '';
        if (ds === 'match')    rowBg = 'background:#dcfce7';
        else if (ds === 'overpaid')  rowBg = 'background:#dbeafe';
        else if (ds === 'underpaid') rowBg = 'background:#fee2e2';
        else rowBg = 'background:#f8fafc';

        const hl = s => dolSearch ? hlText(escHtml(s), dolSearch) : escHtml(s);

        let statusHtml = '';
        if (ds === 'match')     statusHtml = '<span style="background:#dcfce7;color:#15803d;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;">✓ MATCH</span>';
        else if (ds === 'overpaid')  statusHtml = '<span style="background:#dbeafe;color:#1e40af;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;">▲ COST > PAID</span>';
        else if (ds === 'underpaid') statusHtml = '<span style="background:#fee2e2;color:#991b1b;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;">▼ PAID > COST</span>';
        else statusHtml = '<span style="background:#f1f5f9;color:#6b7280;padding:2px 8px;border-radius:4px;font-size:11px;">NO DATA</span>';

        const CELLS = {
            sr:     () => `<td style="text-align:center;color:#9ca3af;font-size:11px;padding:7px 6px;">${idx+1}</td>`,
            ndc:    () => `<td style="font-size:11px;font-family:'JetBrains Mono','Courier New',monospace;color:var(--rxa-primary,#7c3aed);cursor:pointer;padding:7px 8px;" onclick="copyText('${r.ndc}')" title="Click to copy">${hl(r.ndc)}</td>`,
            desc:   () => `<td style="font-weight:600;font-size:12px;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:7px 8px;">${hl(r.description)}</td>`,
            pkg:    () => `<td style="text-align:right;padding:7px 8px;font-size:12px;">${r.packageSize > 0 ? r.packageSize.toLocaleString() : '—'}</td>`,
            rxqty:  () => `<td style="text-align:right;padding:7px 8px;font-variant-numeric:tabular-nums;">${r.totalRxQty.toLocaleString()}</td>`,
            paid:   () => `<td style="text-align:right;padding:7px 8px;font-variant-numeric:tabular-nums;color:#059669;font-weight:600;">${r.totalInsPaid > 0 ? fmtD(r.totalInsPaid) : '<span style="color:#9ca3af">—</span>'}</td>`,
            cost:   () => `<td style="text-align:right;padding:7px 8px;font-variant-numeric:tabular-nums;color:var(--rxa-primary,#7c3aed);font-weight:600;">${r.totalSupplyCost > 0 ? fmtD(r.totalSupplyCost) : '<span style="color:#9ca3af">—</span>'}</td>`,
            diff:   () => `<td style="text-align:right;padding:7px 8px;">${fmtDS(r.dollarDiff)}</td>`,
            status: () => `<td style="padding:7px 8px;">${statusHtml}</td>`,
        };
        tbodyHtml += `<tr style="${rowBg}">` + tabColOrdered('dollar').map(col => (CELLS[col.key] ? CELLS[col.key]() : '<td></td>')).join('') + `</tr>`;
    });

    container.innerHTML = `
    <div class="dol-outer">
        <div class="dol-header">
            <div class="dol-title">💲 Dollar Reconciliation</div>
            <div style="flex:1"></div>
            <div class="tab-search-wrap"><span class="search-ico ico-svg-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span><input class="raw-search" id="dol-search-inp" placeholder="Search NDC or description…" value="${escHtml(dolSearch)}" oninput="dolSearchFn(this.value)"><button class="s-clear" onclick="document.getElementById(\'dol-search-inp\').value=\'\';dolSearchFn('')" title="Clear"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></span></button></div>
            <button class="export-btn" onclick="openExportModal('dollar')"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></span> Export</button>
        </div>

        <div class="dol-summary-bar">
            <div class="summary-pill"><span>NDCs with \$ data: <strong class="pill-count">${ndcsWithData}</strong></span></div>
            <div class="summary-pill" style="background:#dcfce7"><span>✓ Match: <strong>${matchCount}</strong></span></div>
            <div class="summary-pill" style="background:#dbeafe"><span>▲ Cost > Paid: <strong>${overpaidCount}</strong></span></div>
            <div class="summary-pill" style="background:#fee2e2"><span>▼ Paid > Cost: <strong>${underpaidCount}</strong></span></div>
            <div class="summary-pill"><span>No data: <strong>${nodataCount}</strong></span></div>
        </div>

        <div style="background:var(--surface);border-bottom:1px solid var(--border);padding:8px 14px;display:flex;align-items:center;gap:8px;flex-shrink:0;">
            <div class="filter-group" id="dol-status-filters">
                <button class="filter-btn all ${dolStatusFilter==='all'?'active':''}" onclick="dolSetStatus('all',this)">All</button>
                <button class="filter-btn ok ${dolStatusFilter==='match'?'active':''}" style="${dolStatusFilter==='match'?'':'border-color:#16a34a;color:#16a34a'}" onclick="dolSetStatus('match',this)">✓ Match</button>
                <button class="filter-btn over ${dolStatusFilter==='overpaid'?'active':''}" onclick="dolSetStatus('overpaid',this)">▲ Cost > Paid</button>
                <button class="filter-btn short ${dolStatusFilter==='underpaid'?'active':''}" onclick="dolSetStatus('underpaid',this)">▼ Paid > Cost</button>
                <button class="filter-btn ${dolStatusFilter==='nodata'?'active':''}" style="border-color:#9ca3af;color:#6b7280" onclick="dolSetStatus('nodata',this)">No Data</button>
            </div>
            <div style="flex:1"></div>
            <button class="qs-btn" onclick="tabColReset('dollar',renderDollarTab)" title="Reset column order" style="font-size:10px;color:#6b7280;margin-right:8px;"><span class="ico-svg-wrap ico-inline"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9"/><polyline points="3 4 3 12 11 12"/></svg></span>Cols</button>
            <div style="font-size:11px;color:var(--text-muted);background:var(--bg);padding:5px 10px;border-radius:4px;">
                Total Supply Cost: <strong style="color:var(--rxa-primary,#7c3aed)">${fmtD(totalSupCost)}</strong> &nbsp;|&nbsp;
                Total Ins Paid: <strong style="color:#059669">${fmtD(totalInsPaid)}</strong> &nbsp;|&nbsp;
                Net Difference: <strong>${fmtDS(totalDolDiff)}</strong>
            </div>
        </div>

        <div class="dol-table-wrap">
            <table class="dol-table">
                <thead>${tabColHeader('dollar', dolSortCol, dolSortDir, 'dolSort')}</thead>
                <tbody>${tbodyHtml || '<tr><td colspan="9" style="text-align:center;padding:40px;color:#9ca3af;">No data — dollar columns not found in uploaded files.</td></tr>'}</tbody>
            </table>
        </div>
    </div>`;
}


function switchTab(name, btn) {
    document.querySelectorAll('.topbar-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    if (typeof setPageTitle === 'function') setPageTitle(name);
    if (typeof _deactivate === 'function') _deactivate();
    if (typeof _invalidateGridCache === 'function') _invalidateGridCache();
    document.getElementById('tab-results').style.display = 'none';
    document.getElementById('tab-mfp').style.display = 'none';
    ['raw', 'suppliers', 'final', 'bill', 'dollar', 'discarded', 'issues', 'notbilled'].forEach(t => document.getElementById('tab-' + t).classList.remove('active'));

    if (name === 'results') {
        document.getElementById('tab-results').style.display = 'flex';
    } else if (name === 'mfp') {
        document.getElementById('tab-mfp').style.display = 'flex';
        initMFPFilters();
        // Only re-render MFP if dirty
        if (_dirty['mfp'] !== false) { renderMFP(); _dirty['mfp'] = false; }
    } else {
        document.getElementById('tab-' + name).classList.add('active');
        // Only render if dirty (data changed) or never rendered before
        if (_dirty[name] !== false) {
            if (name === 'suppliers')  renderSuppliersTab();
            if (name === 'raw')        renderRawPreview();
            if (name === 'final')      renderFinalTab();
            if (name === 'notbilled')  renderNotBilledTab();
            if (name === 'bill')       renderBillTab();
            if (name === 'dollar')     renderDollarTab();
            if (name === 'discarded')  renderDiscardedTab();
            if (name === 'issues')     renderIssuesTab();
            _dirty[name] = false;
        }
    }
}
