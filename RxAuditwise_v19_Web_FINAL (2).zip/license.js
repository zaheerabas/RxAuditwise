// ════════════════════════════════════════════════════════════
//  RxAuditwise — License / Auth System  v5.0
//  FLOW:
//  1. Pharmacy login (username + password) → session stored
//  2. Upload screen unlocked
//  3. Run Reconciliation → scan files for this pharmacy's codes
//  4. Match → proceed | No match → contact gate
//  5. Logout → back to login
// ════════════════════════════════════════════════════════════

const LIC_API         = 'api.php';
const LIC_SESSION_KEY = 'rxaw_session_v1';

const LIC_DEFAULT_CONTACT = {
    adminName:  'RxAuditwise Support',
    adminEmail: 'info@rxauditwise.com',
    adminPhone: '+1 (347) 870-0748',
    adminOrg:   'RxAuditwise',
    adminWebsite: 'www.rxauditwise.com',
    adminAddress: '2548 Matthews Ave, Bronx NY 10467'
};

// Cached copy of the last successful contact fetch — export needs contact
// info synchronously (it can't await a network call mid-export), so this is
// updated every time licFetchContact() succeeds anywhere in the app and read
// as a synchronous fallback via licGetCachedContact().
let _lastKnownContact = null;
function licGetCachedContact() { return _lastKnownContact ? { ..._lastKnownContact } : { ...LIC_DEFAULT_CONTACT }; }

// ── Helpers ──────────────────────────────────────────────────
function licNorm(code) { return String(code).trim().toUpperCase().replace(/\s+/g, ''); }
function licTodayStr() { return new Date().toISOString().slice(0, 10); }
function licEsc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
                    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Session ───────────────────────────────────────────────────
function licGetSession() {
    try { return JSON.parse(sessionStorage.getItem(LIC_SESSION_KEY) || 'null'); } catch(e) { return null; }
}
function licSaveSession(data) { sessionStorage.setItem(LIC_SESSION_KEY, JSON.stringify(data)); }
function licClearSession()    { sessionStorage.removeItem(LIC_SESSION_KEY); }
function licIsLoggedIn()      { const s=licGetSession(); return !!(s&&s.token&&s.userId); }

// ── Fetch contact info ────────────────────────────────────────
async function licFetchContact() {
    try {
        const r = await fetch(LIC_API, { method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ action:'get_config_public' }) });
        if (!r.ok) return { ...LIC_DEFAULT_CONTACT };
        const j = await r.json();
        if (j.ok && j.config) {
            const merged = { ...LIC_DEFAULT_CONTACT, ...j.config };
            _lastKnownContact = merged;
            return merged;
        }
    } catch(e) {}
    return { ...LIC_DEFAULT_CONTACT };
}

// ── Login: authenticate pharmacy user ────────────────────────
async function licDoLogin(username, password) {
    try {
        const r = await fetch(LIC_API, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({ action:'user_login', username, password })
        });
        let j;
        try { j = await r.json(); }
        catch(pe) { throw new Error('Server returned an invalid response. Contact your administrator.'); }
        if (j.ok && j.token) {
            const session = {
                token:    j.token,
                userId:   j.userId || j.user_id,
                name:     j.name   || username,
                pharmacy: j.pharmacy || j.name || username,
                endDate:  j.endDate  || null,
                codes:    j.codes    || [],
                active:   j.active !== false,
            };
            licSaveSession(session);
            return { ok: true, session };
        }
        return { ok: false, error: j.error || 'Invalid username or password' };
    } catch(e) {
        return { ok: false, error: e.message || 'Cannot reach server. Check your connection.' };
    }
}

// ── Refresh session (called before reconciliation) ────────────
async function licRefreshSession() {
    const s = licGetSession();
    if (!s || !s.token) return null;
    try {
        const r = await fetch(LIC_API, {
            method:  'POST',
            headers: { 'Content-Type':'application/json', 'X-Auth-Token': s.token },
            body:    JSON.stringify({ action:'get_current_user' })
        });
        if (!r.ok) return s;
        const j = await r.json();
        if (j.ok && j.user) {
            const updated = { ...s, ...j.user, token: s.token };
            licSaveSession(updated);
            return updated;
        }
    } catch(e) {}
    return s;
}

// ── File scanning ─────────────────────────────────────────────
function licReadFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const wb  = XLSX.read(new Uint8Array(e.target.result), { type:'array' });
                const all = [];
                for (const name of wb.SheetNames) {
                    const rows = XLSX.utils.sheet_to_json(wb.Sheets[name], { header:1, defval:'' });
                    all.push(...rows);
                }
                resolve(all);
            } catch(err) { reject(err); }
        };
        reader.onerror = () => reject(new Error('Could not read: ' + file.name));
        reader.readAsArrayBuffer(file);
    });
}
function licCells(rows) {
    const out = new Set();
    for (const row of rows) {
        if (!Array.isArray(row)) continue;
        for (const cell of row) {
            const s = licNorm(String(cell == null ? '' : cell));
            if (s.length >= 3) out.add(s);
        }
    }
    return out;
}
function licCodeInCells(code, cells) {
    const n = licNorm(code);
    if (cells.has(n)) return true;
    for (const cell of cells) { if (cell.includes(n)) return true; }
    return false;
}
async function licAllCells(fileList, singleFile) {
    const combined = new Set();
    for (const f of (fileList || [])) {
        try { licCells(await licReadFile(f)).forEach(c => combined.add(c)); } catch(e) {}
    }
    if (singleFile) {
        try { licCells(await licReadFile(singleFile)).forEach(c => combined.add(c)); } catch(e) {}
    }
    return combined;
}

// ── Main gate check ───────────────────────────────────────────
async function licCheckFiles(supplierFileList, billingFileObj) {
    const session = licGetSession();
    if (!session || !session.token) return { allowed:false, user:null, reason:'not_logged_in' };
    if (!session.active)           return { allowed:false, user:session, reason:'inactive' };
    const today = licTodayStr();
    if (session.endDate && session.endDate < today)
        return { allowed:false, user:session, reason:'expired' };
    const refreshed = await licRefreshSession();
    const codes = (refreshed && refreshed.codes) ? refreshed.codes : (session.codes || []);
    if (!codes.length) return { allowed:false, user:session, reason:'no_codes' };
    const allCells = await licAllCells(supplierFileList, billingFileObj);
    for (const code of codes) {
        if (code && licCodeInCells(code, allCells))
            return { allowed:true, user:session, reason:'matched' };
    }
    return { allowed:false, user:session, reason:'no_match' };
}

// ══════════════════════════════════════════════════════════════
//  LOGIN UI — Three panels: Sign In | Forgot Password | Reset
// ══════════════════════════════════════════════════════════════
function licShowLogin(opts) {
    const onSuccess = (opts && opts.onSuccess) || function() {};
    const errMsg    = (opts && opts.error)     || '';

    if (typeof setPageTitle === 'function') setPageTitle('login');

    const existing = document.getElementById('lic-login-overlay');
    if (existing) existing.remove();

    licInjectCSS();

    const div = document.createElement('div');
    div.id = 'lic-login-overlay';
    div.innerHTML = `
    <div class="lic-shell">

        <!-- ══════════ LEFT — ILLUSTRATION ══════════ -->
        <div class="lic-illustration">
            <div class="lic-illu-grid"></div>

            <div class="lic-illu-stage">
                <div class="lic-float-card lic-fc-1">
                    <span class="lic-fc-ico">📦</span>
                    <span class="lic-fc-txt">Supplier file<br>matched</span>
                </div>
                <div class="lic-float-card lic-fc-2">
                    <span class="lic-fc-ico">🧾</span>
                    <span class="lic-fc-txt">Billing file<br>parsed</span>
                </div>

                <div class="lic-illu-mockup">
                    <div class="lic-mockup-top">
                        <span class="lic-mockup-dot" style="background:#ef4444"></span>
                        <span class="lic-mockup-dot" style="background:#eab308"></span>
                        <span class="lic-mockup-dot" style="background:#22c55e"></span>
                    </div>
                    <div class="lic-mockup-row"><span class="lic-status-pill lic-status-ok">OK</span><span class="lic-mockup-line"></span></div>
                    <div class="lic-mockup-row"><span class="lic-status-pill lic-status-short">SHORT</span><span class="lic-mockup-line s"></span></div>
                    <div class="lic-mockup-row"><span class="lic-status-pill lic-status-ok">OK</span><span class="lic-mockup-line"></span></div>
                    <div class="lic-mockup-row"><span class="lic-status-pill lic-status-over">OVER</span><span class="lic-mockup-line s"></span></div>
                    <div class="lic-mockup-chart">
                        <div style="height:38%"></div><div style="height:68%"></div><div style="height:50%"></div>
                        <div style="height:92%"></div><div style="height:58%"></div><div style="height:78%"></div><div style="height:44%"></div>
                    </div>
                </div>

                <div class="lic-float-circle lic-fcirc-1">✅</div>
                <div class="lic-float-circle lic-fcirc-2">🔍</div>
                <div class="lic-float-card lic-fc-3">
                    <span class="lic-fc-ico">🏥</span>
                    <span class="lic-fc-txt">King Community<br>Pharmacy</span>
                </div>
            </div>
        </div>

        <!-- ══════════ RIGHT — FORM ══════════ -->
        <div class="lic-form-panel">
            <div class="lic-form-inner">

                <!-- ── Sign In ── -->
                <div class="lic-form-slot" id="lic-panel-signin">
                    <div class="lic-brandrow">
                        <img src="icon.png" alt="RxAuditwise" class="lic-logo-img"
                             onerror="this.style.display='none'">
                        <span class="lic-brand-word">RxAuditwise</span>
                    </div>
                    <h1 class="lic-h1">Sign in</h1>
                    <p class="lic-sub">Welcome back. Enter your credentials to continue.</p>

                    <div class="lic-form">
                        <div class="lic-group">
                            <label class="lic-label">Username</label>
                            <input type="text" id="lic-inp-user" class="lic-plain-input" placeholder="Enter your username"
                                autocomplete="username" spellcheck="false"
                                onkeydown="if(event.key==='Enter')document.getElementById('lic-inp-pass').focus()">
                        </div>
                        <div class="lic-group">
                            <label class="lic-label">Password</label>
                            <div class="lic-input-wrap">
                                <input type="password" id="lic-inp-pass" class="lic-plain-input" placeholder="Enter your password"
                                    autocomplete="current-password"
                                    onkeydown="if(event.key==='Enter')licSubmitLogin()">
                                <button type="button" class="lic-eye-btn" onclick="licTogglePass('lic-inp-pass','lic-eye-1')" tabindex="-1" aria-label="Show/hide password">
                                    <svg id="lic-eye-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                        <circle cx="12" cy="12" r="3"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="lic-err" id="lic-err">${errMsg}</div>
                        <button class="lic-btn" id="lic-login-btn" onclick="licSubmitLogin()">
                            <span id="lic-btn-text">Sign In</span>
                            <span id="lic-btn-spin" class="lic-spinner" style="display:none"></span>
                        </button>
                    </div>

                    <div class="lic-footer-links">
                        <span class="lic-help-text">Need an account? <a href="javascript:void(0)" onclick="licShowForgot()" class="lic-text-link">Contact admin</a></span>
                    </div>
                </div>

                <!-- ── Contact Admin ── -->
                <div class="lic-form-slot" id="lic-panel-forgot" style="display:none">
                    <div class="lic-brandrow">
                        <img src="icon.png" alt="RxAuditwise" class="lic-logo-img"
                             onerror="this.style.display='none'">
                        <span class="lic-brand-word">RxAuditwise</span>
                    </div>
                    <h1 class="lic-h1">Contact admin</h1>
                    <p class="lic-sub">Account access and password resets are handled by your administrator.</p>

                    <div class="lic-contact-card">
                        <div class="lic-contact-org" id="lic-admin-org">RxAuditwise</div>
                        <div class="lic-contact-row">
                            <span class="lic-contact-ico">👤</span>
                            <span id="lic-admin-name">RxAuditwise Support</span>
                        </div>
                        <div class="lic-contact-row">
                            <span class="lic-contact-ico">✉️</span>
                            <a id="lic-admin-email" href="mailto:info@rxauditwise.com">info@rxauditwise.com</a>
                        </div>
                        <div class="lic-contact-row">
                            <span class="lic-contact-ico">📞</span>
                            <span id="lic-admin-phone">+1 (347) 870-0748</span>
                        </div>
                        <div class="lic-contact-row">
                            <span class="lic-contact-ico">📍</span>
                            <span id="lic-admin-address">2548 Matthews Ave, Bronx NY 10467</span>
                        </div>
                    </div>

                    <div class="lic-footer-links">
                        <button onclick="licShowSignin()" class="lic-text-btn">← Back to Sign In</button>
                    </div>
                </div>

                <!-- ── Set New Password ── -->
                <div class="lic-form-slot" id="lic-panel-reset" style="display:none">
                    <div class="lic-brandrow">
                        <img src="icon.png" alt="RxAuditwise" class="lic-logo-img"
                             onerror="this.style.display='none'">
                        <span class="lic-brand-word">RxAuditwise</span>
                    </div>
                    <h1 class="lic-h1">Set new password</h1>
                    <p class="lic-sub">Enter a new password for your account.</p>
                    <div class="lic-form">
                        <div class="lic-group">
                            <label class="lic-label">New password</label>
                            <div class="lic-input-wrap">
                                <input type="password" id="lic-rp-pass1" class="lic-plain-input" placeholder="Minimum 6 characters"
                                    onkeydown="if(event.key==='Enter')document.getElementById('lic-rp-pass2').focus()">
                                <button type="button" class="lic-eye-btn" onclick="licTogglePass('lic-rp-pass1','lic-eye-2')" tabindex="-1">
                                    <svg id="lic-eye-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                        <circle cx="12" cy="12" r="3"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="lic-group">
                            <label class="lic-label">Confirm password</label>
                            <input type="password" id="lic-rp-pass2" class="lic-plain-input" placeholder="Confirm new password"
                                onkeydown="if(event.key==='Enter')licResetSubmit()">
                        </div>
                        <div id="lic-pw-strength" class="lic-pw-strength" style="display:none">
                            <div class="lic-pw-bar"><div id="lic-pw-fill" class="lic-pw-fill"></div></div>
                            <span id="lic-pw-label"></span>
                        </div>
                        <div class="lic-err" id="lic-rp-err"></div>
                        <div id="lic-rp-ok" style="display:none" class="lic-ok-box"></div>
                        <button class="lic-btn" id="lic-rp-btn" onclick="licResetSubmit()">Set New Password</button>
                    </div>
                </div>

                <div class="lic-copyright">© ${new Date().getFullYear()} RxAuditwise. All rights reserved.</div>
            </div>
        </div>
    </div>`;

    document.body.appendChild(div);
    div._onSuccess = onSuccess;

    // Password strength meter
    const pass1 = document.getElementById('lic-rp-pass1');
    if (pass1) pass1.addEventListener('input', function() {
        licUpdateStrength(this.value);
    });

    const urlToken = new URLSearchParams(window.location.search).get('reset_token');
    if (urlToken) {
        document.getElementById('lic-panel-signin').style.display = 'none';
        document.getElementById('lic-panel-reset').style.display  = '';
    } else {
        setTimeout(() => { const inp = document.getElementById('lic-inp-user'); if (inp) inp.focus(); }, 120);
    }
}

// ── Show/hide password toggle ─────────────────────────────────
function licTogglePass(inputId, eyeId) {
    const inp = document.getElementById(inputId);
    const eye = document.getElementById(eyeId);
    if (!inp) return;
    const isPass = inp.type === 'password';
    inp.type = isPass ? 'text' : 'password';
    if (eye) {
        eye.innerHTML = isPass
            ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`
            : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
    }
}

// ── Password strength ─────────────────────────────────────────
function licUpdateStrength(val) {
    const wrap  = document.getElementById('lic-pw-strength');
    const fill  = document.getElementById('lic-pw-fill');
    const label = document.getElementById('lic-pw-label');
    if (!wrap || !val) { if(wrap) wrap.style.display='none'; return; }
    wrap.style.display = 'flex';
    let score = 0;
    if (val.length >= 6)  score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const levels = [
        { pct:20, color:'#ef4444', text:'Very Weak' },
        { pct:40, color:'#f97316', text:'Weak' },
        { pct:60, color:'#eab308', text:'Fair' },
        { pct:80, color:'#22c55e', text:'Strong' },
        { pct:100,color:'#16a34a', text:'Very Strong' },
    ];
    const lvl = levels[Math.min(score, 4)];
    fill.style.width  = lvl.pct + '%';
    fill.style.background = lvl.color;
    label.textContent = lvl.text;
    label.style.color = lvl.color;
}

// ── Panel switchers ───────────────────────────────────────────
async function licShowForgot() {
    document.getElementById('lic-panel-signin').style.display = 'none';
    document.getElementById('lic-panel-forgot').style.display = '';

    const contact = await licFetchContact();
    const orgEl   = document.getElementById('lic-admin-org');
    const nameEl  = document.getElementById('lic-admin-name');
    const emailEl = document.getElementById('lic-admin-email');
    const phoneEl = document.getElementById('lic-admin-phone');
    if (orgEl)   orgEl.textContent   = contact.adminOrg   || LIC_DEFAULT_CONTACT.adminOrg;
    if (nameEl)  nameEl.textContent  = contact.adminName  || LIC_DEFAULT_CONTACT.adminName;
    if (phoneEl) phoneEl.textContent = contact.adminPhone || LIC_DEFAULT_CONTACT.adminPhone;
    if (emailEl) {
        const em = contact.adminEmail || LIC_DEFAULT_CONTACT.adminEmail;
        emailEl.textContent = em;
        emailEl.href = 'mailto:' + em;
    }
}

function licShowSignin() {
    ['lic-panel-forgot','lic-panel-reset'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
    document.getElementById('lic-panel-signin').style.display = '';
    setTimeout(() => { const p=document.getElementById('lic-inp-pass'); if(p) p.focus(); }, 80);
}

// ── CSS ───────────────────────────────────────────────────────
function licInjectCSS() {
    if (document.getElementById('lic-css')) return;
    const s = document.createElement('style');
    s.id = 'lic-css';
    s.textContent = `
    /* ── Overlay ── */
    #lic-login-overlay {
        position:fixed;inset:0;z-index:99999;
        display:flex;align-items:center;justify-content:center;padding:28px;
        background:#eef0f4;
        overflow:auto;
        font-family:inherit;
    }

    /* ── Shell (centered card) ── */
    .lic-shell {
        position:relative;width:100%;max-width:1040px;min-height:600px;
        display:flex;background:#fff;border-radius:22px;overflow:hidden;
        box-shadow:0 30px 70px rgba(20,20,50,.14);
        animation:licPopIn .4s cubic-bezier(.34,1.56,.64,1);
    }
    @keyframes licPopIn {
        from { opacity:0; transform:translateY(16px) scale(.98); }
        to   { opacity:1; transform:translateY(0)   scale(1); }
    }

    /* ── Left: illustration ── */
    .lic-illustration {
        flex:1 1 50%;position:relative;overflow:hidden;
        background:#f6f7fa;display:flex;align-items:center;justify-content:center;
        padding:40px;box-sizing:border-box;
    }
    .lic-illu-grid {
        position:absolute;inset:0;pointer-events:none;
        background-image:
            linear-gradient(rgba(124,58,237,.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(124,58,237,.05) 1px, transparent 1px);
        background-size:34px 34px;
        mask-image:radial-gradient(ellipse at center, #000 40%, transparent 78%);
        -webkit-mask-image:radial-gradient(ellipse at center, #000 40%, transparent 78%);
    }
    .lic-illu-stage { position:relative;width:100%;max-width:340px; }

    .lic-illu-mockup {
        background:#fff;border-radius:16px;padding:16px 18px;
        box-shadow:0 24px 50px rgba(20,20,60,.16);position:relative;z-index:2;
        border:1px solid #eef0f4;
    }
    .lic-mockup-top { display:flex;gap:5px;margin-bottom:12px; }
    .lic-mockup-dot { width:8px;height:8px;border-radius:50%; }
    .lic-mockup-row { display:flex;align-items:center;gap:8px;margin-bottom:8px; }
    .lic-status-pill {
        font-size:.58rem;font-weight:800;padding:2px 7px;border-radius:5px;
        letter-spacing:.03em;flex-shrink:0;width:44px;text-align:center;
    }
    .lic-status-ok    { background:rgba(34,197,94,.15);color:#16a34a; }
    .lic-status-short { background:rgba(239,68,68,.15);color:#dc2626; }
    .lic-status-over  { background:rgba(234,179,8,.15);color:#b45309; }
    .lic-mockup-line { flex:1;height:6px;border-radius:4px;background:#eef0f4; }
    .lic-mockup-line.s { max-width:60%; }
    .lic-mockup-chart { display:flex;align-items:flex-end;gap:5px;height:36px;margin-top:12px; }
    .lic-mockup-chart div { flex:1;border-radius:3px 3px 0 0;background:linear-gradient(180deg,#c4b5fd,#7c3aed); }

    .lic-float-card {
        position:absolute;background:#fff;border-radius:12px;padding:9px 12px;
        box-shadow:0 14px 30px rgba(20,20,60,.14);
        display:flex;align-items:center;gap:8px;z-index:3;
        border:1px solid #eef0f4;
    }
    .lic-fc-ico { font-size:1.1rem;flex-shrink:0; }
    .lic-fc-txt { font-size:.68rem;font-weight:600;color:#334155;line-height:1.25; }
    .lic-fc-1 { top:-8%;  left:-14%; transform:rotate(-4deg); }
    .lic-fc-2 { top:6%;   right:-18%; transform:rotate(3deg); }
    .lic-fc-3 { bottom:-10%; left:-10%; transform:rotate(3deg); }

    .lic-float-circle {
        position:absolute;width:46px;height:46px;border-radius:50%;background:#fff;
        display:flex;align-items:center;justify-content:center;font-size:1.15rem;
        box-shadow:0 14px 28px rgba(20,20,60,.14);z-index:3;border:1px solid #eef0f4;
    }
    .lic-fcirc-1 { bottom:14%; right:-16%; }
    .lic-fcirc-2 { top:38%; left:-20%; }

    /* ── Right: form ── */
    .lic-form-panel {
        flex:1 1 50%;display:flex;align-items:center;justify-content:center;
        padding:48px 44px;box-sizing:border-box;background:#fff;
    }
    .lic-form-inner { width:100%;max-width:340px; }

    .lic-brandrow { display:flex;align-items:center;gap:10px;margin-bottom:30px; }
    .lic-logo-img { width:30px;height:30px;border-radius:8px;object-fit:cover; }
    .lic-brand-word { font-size:.95rem;font-weight:800;color:#0f172a;letter-spacing:-.01em; }

    .lic-h1  { font-size:1.7rem;font-weight:800;color:#0f172a;margin:0 0 6px;letter-spacing:-.02em; }
    .lic-sub { font-size:.85rem;color:#8a93a3;margin:0 0 28px;line-height:1.55; }

    .lic-form { display:flex;flex-direction:column;gap:18px; }
    .lic-group { position:relative; }
    .lic-label {
        display:block;font-size:.76rem;font-weight:600;color:#475569;
        margin-bottom:7px;letter-spacing:.01em;
    }
    .lic-input-wrap { position:relative;display:flex;align-items:center; }
    .lic-plain-input {
        width:100%;padding:12px 14px;
        background:#f6f7fa;
        border:1.5px solid #eceef2;
        border-radius:9px;
        color:#0f172a;font-size:.92rem;outline:none;
        transition:border-color .18s,background .18s,box-shadow .18s;
        box-sizing:border-box;
        font-family:inherit;
    }
    .lic-input-wrap .lic-plain-input { padding-right:42px; }
    .lic-plain-input::placeholder { color:#a3abba; }
    .lic-plain-input:focus {
        border-color:#7c3aed;
        background:#fff;
        box-shadow:0 0 0 3px rgba(124,58,237,.12);
    }

    /* ── Show/hide password ── */
    .lic-eye-btn {
        position:absolute;right:12px;background:none;border:none;
        color:#a3abba;cursor:pointer;padding:4px;
        display:flex;align-items:center;transition:color .15s;
    }
    .lic-eye-btn:hover { color:#475569; }

    /* ── Error ── */
    .lic-err { font-size:.8rem;color:#dc2626;min-height:16px;padding:0 2px;letter-spacing:.01em; }

    /* ── Button ── */
    .lic-btn {
        width:100%;padding:13px;margin-top:2px;
        background:#7c3aed;
        color:#fff;border:none;border-radius:9px;
        font-size:.95rem;font-weight:700;cursor:pointer;
        display:flex;align-items:center;justify-content:center;gap:8px;
        transition:background .15s,transform .15s;
        font-family:inherit;letter-spacing:.01em;
    }
    .lic-btn:hover:not(:disabled) { background:#6d28d9; }
    .lic-btn:active:not(:disabled) { transform:scale(.99); }
    .lic-btn:disabled { opacity:.6;cursor:not-allowed; }

    /* ── Spinner ── */
    .lic-spinner {
        width:17px;height:17px;border:2.5px solid rgba(255,255,255,.35);
        border-top-color:#fff;border-radius:50%;
        animation:licSpin .7s linear infinite;
    }
    @keyframes licSpin { to { transform:rotate(360deg); } }

    /* ── Footer links ── */
    .lic-footer-links { margin-top:26px;text-align:center; }
    .lic-help-text { font-size:.82rem;color:#8a93a3; }
    .lic-text-link { color:#7c3aed;font-weight:700;text-decoration:none; }
    .lic-text-link:hover { text-decoration:underline; }
    .lic-text-btn {
        background:none;border:none;color:#7c3aed;
        font-size:.8rem;cursor:pointer;padding:0;font-weight:600;
        transition:color .15s;font-family:inherit;
    }
    .lic-text-btn:hover { color:#5b21b6; }

    .lic-copyright { margin-top:34px;text-align:center;font-size:.72rem;color:#c7ccd6; }

    /* ── Contact admin card ── */
    .lic-contact-card {
        background:#f6f7fa;border:1.5px solid #eceef2;border-radius:14px;
        padding:16px 18px;display:flex;flex-direction:column;gap:12px;margin-bottom:4px;
    }
    .lic-contact-org { font-size:.95rem;font-weight:700;color:#0f172a; }
    .lic-contact-row { display:flex;align-items:center;gap:10px;font-size:.85rem;color:#334155; }
    .lic-contact-ico { font-size:1rem;flex-shrink:0; }
    .lic-contact-row a { color:#7c3aed;text-decoration:none;font-weight:600; }
    .lic-contact-row a:hover { text-decoration:underline; }

    /* ── OK box ── */
    .lic-ok-box {
        background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.3);
        border-radius:10px;color:#059669;font-size:.83rem;
        padding:12px 14px;line-height:1.6;
    }

    /* ── Password strength ── */
    .lic-pw-strength { display:flex;align-items:center;gap:10px; }
    .lic-pw-bar { flex:1;height:4px;background:#eceef2;border-radius:4px;overflow:hidden; }
    .lic-pw-fill { height:100%;width:0;border-radius:4px;transition:width .3s,background .3s; }
    .lic-pw-strength span { font-size:.72rem;font-weight:600;white-space:nowrap; }

    /* ── Gate overlay ── */
    #lic-gate-overlay {
        position:fixed;inset:0;z-index:99999;
        background:rgba(10,8,30,.82);backdrop-filter:blur(10px);
        display:flex;align-items:center;justify-content:center;padding:20px;
        box-sizing:border-box;
    }
    .lic-gate-box {
        --tone:#2563eb; --tone-bg:#eff6ff;
        position:relative;background:#fff;border-radius:20px;overflow:hidden;
        max-width:440px;width:100%;text-align:center;
        box-shadow:0 32px 80px rgba(0,0,0,.4);
        animation:licPopIn2 .35s cubic-bezier(.34,1.56,.64,1);
    }
    @keyframes licPopIn2 {
        from { opacity:0; transform:translateY(18px) scale(.96); }
        to   { opacity:1; transform:translateY(0)   scale(1); }
    }
    .lic-tone-amber { --tone:#d97706; --tone-bg:#fffbeb; }
    .lic-tone-red   { --tone:#dc2626; --tone-bg:#fef2f2; }
    .lic-tone-blue  { --tone:#2563eb; --tone-bg:#eff6ff; }
    .lic-tone-slate { --tone:#475569; --tone-bg:#f1f5f9; }

    .lic-gate-accent { height:5px;width:100%;background:var(--tone); }
    .lic-gate-body   { padding:34px 32px 28px; }

    .lic-gate-icon-badge {
        width:56px;height:56px;border-radius:16px;background:var(--tone-bg);
        display:flex;align-items:center;justify-content:center;
        font-size:26px;margin:0 auto 16px;
    }
    .lic-gate-title { font-size:1.3rem;font-weight:800;color:#0f172a;margin-bottom:8px;letter-spacing:-.01em; }
    .lic-gate-msg   { font-size:.87rem;color:#64748b;line-height:1.65;margin-bottom:20px; }
    .lic-gate-card  { background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:14px;
        padding:16px 18px;text-align:left;margin-bottom:20px;display:flex;flex-direction:column;gap:10px; }
    .lic-gate-org   { font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:2px; }
    .lic-cr  { display:flex;align-items:center;gap:10px;font-size:.85rem;color:#334155; }
    .lic-ico-badge {
        width:26px;height:26px;border-radius:8px;background:#fff;border:1px solid #e2e8f0;
        display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;
    }
    .lic-cr a { color:var(--tone);text-decoration:none;font-weight:600; }
    .lic-cr a:hover { text-decoration:underline; }
    .lic-gate-btn {
        background:#7c3aed;color:#fff;border:none;border-radius:12px;
        padding:13px 24px;font-size:.92rem;font-weight:700;cursor:pointer;width:100%;
        display:flex;align-items:center;justify-content:center;gap:8px;
        transition:background .15s,transform .15s;font-family:inherit;
    }
    .lic-gate-btn:hover { background:#6d28d9; }
    .lic-gate-btn:active { transform:scale(.99); }

    /* ── Responsive ── */
    @media (max-width:900px) {
        .lic-illustration { display:none; }
        .lic-shell { max-width:440px;min-height:0; }
        .lic-form-panel { padding:44px 30px; }
    }
    @media (max-width:480px) {
        #lic-login-overlay { padding:0; }
        .lic-shell { border-radius:0;min-height:100vh;box-shadow:none; }
        .lic-form-panel { padding:36px 24px; }
        .lic-h1 { font-size:1.4rem; }
        .lic-gate-body { padding:28px 22px 24px; }
        .lic-gate-title { font-size:1.15rem; }
    }
    `;
    document.head.appendChild(s);
}
licInjectCSS();



// ── Auto-init ─────────────────────────────────────────────────
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', licRequireLogin);
} else {
    licRequireLogin();
}
// ══════════════════════════════════════════════════════════════
//  LOGIN FUNCTIONS
// ══════════════════════════════════════════════════════════════

// ── Client-side rate limit (5 attempts → 30s cooldown) ───────
const _licAttempts = { count:0, until:0 };
function licCheckRateLimit(errEl) {
    if (_licAttempts.until > Date.now()) {
        const secs = Math.ceil((_licAttempts.until - Date.now()) / 1000);
        if (errEl) errEl.textContent = `Too many attempts. Try again in ${secs} second${secs!==1?'s':''}.`;
        return false;
    }
    return true;
}

async function licSubmitLogin() {
    const userInp = document.getElementById('lic-inp-user');
    const passInp = document.getElementById('lic-inp-pass');
    const errEl   = document.getElementById('lic-err');
    const btn     = document.getElementById('lic-login-btn');
    const btnText = document.getElementById('lic-btn-text');
    const btnSpin = document.getElementById('lic-btn-spin');
    if (!userInp || !passInp) return;

    const username = userInp.value.trim();
    const password = passInp.value;

    if (!username) { if(errEl) errEl.textContent = 'Please enter your username.'; return; }
    if (!password) { if(errEl) errEl.textContent = 'Please enter your password.'; return; }
    if (!licCheckRateLimit(errEl)) return;

    if (errEl)   errEl.textContent = '';
    if (btn)     btn.disabled = true;
    if (btnText) btnText.textContent = 'Signing in…';
    if (btnSpin) btnSpin.style.display = '';

    const result = await licDoLogin(username, password);

    if (result.ok) {
        if (btnText) btnText.textContent = '✓';
        setTimeout(() => {
            const overlay = document.getElementById('lic-login-overlay');
            const cb = overlay && overlay._onSuccess;
            if (overlay) overlay.remove();
            licUpdateTopbar(result.session);
            if (cb) cb(result.session);
        }, 300);
    } else {
        _licAttempts.count++;
        if (_licAttempts.count >= 5) {
            _licAttempts.until = Date.now() + 30000; // 30s lockout
            _licAttempts.count = 0;
        }
        if (errEl)   errEl.textContent = result.error || 'Invalid username or password.';
        if (btn)     btn.disabled = false;
        if (btnText) btnText.textContent = 'Sign In';
        if (btnSpin) btnSpin.style.display = 'none';
        if (passInp) { passInp.value = ''; passInp.focus(); }
    }
}

async function licResetSubmit() {
    const pass1  = document.getElementById('lic-rp-pass1')?.value || '';
    const pass2  = document.getElementById('lic-rp-pass2')?.value || '';
    const errEl  = document.getElementById('lic-rp-err');
    const okEl   = document.getElementById('lic-rp-ok');
    const btn    = document.getElementById('lic-rp-btn');
    const token  = new URLSearchParams(window.location.search).get('reset_token') || '';

    if (errEl) errEl.textContent = '';
    if (okEl)  okEl.style.display = 'none';

    if (!pass1 || pass1.length < 6) { if(errEl) errEl.textContent = 'Password must be at least 6 characters.'; return; }
    if (pass1 !== pass2)             { if(errEl) errEl.textContent = 'Passwords do not match.'; return; }
    if (!token)                      { if(errEl) errEl.textContent = 'Invalid or expired reset link.'; return; }

    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

    try {
        const r = await fetch(LIC_API, {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ action:'user_reset_password', token, password: pass1 })
        });
        let j;
        try { j = await r.json(); } catch(e) { throw new Error('Server error — please try again.'); }
        if (j.ok) {
            if (okEl) { okEl.textContent = '✓ Password changed! Redirecting to sign in…'; okEl.style.display = 'block'; }
            if (btn)  btn.style.display = 'none';
            history.replaceState({}, '', window.location.pathname);
            setTimeout(() => licShowSignin(), 2500);
        } else {
            if (errEl) errEl.textContent = j.error || 'Reset link is invalid or has expired.';
            if (btn)   { btn.disabled = false; btn.textContent = 'Set New Password'; }
        }
    } catch(e) {
        if (errEl) errEl.textContent = e.message;
        if (btn)   { btn.disabled = false; btn.textContent = 'Set New Password'; }
    }
}

// ── Logout ────────────────────────────────────────────────────
function licLogout() {
    if (!confirm('Sign out of RxAuditwise?')) return;
    licClearSession();
    if (typeof supplierFiles !== 'undefined') supplierFiles.length = 0;
    if (typeof billingFiles  !== 'undefined') billingFiles.length  = 0;
    const appSc = document.getElementById('app-screen');
    const uplSc = document.getElementById('upload-screen');
    if (appSc) appSc.style.display = 'none';
    if (uplSc) uplSc.style.display = 'flex';
    licRequireLogin();
}

// ── Topbar user badge ─────────────────────────────────────────
let LIC_CURRENT_SESSION = null;
function licUpdateTopbar(session) {
    const el = document.getElementById('tb-profile-wrap');
    if (!el || !session) return;
    LIC_CURRENT_SESSION = session;
    const displayName = session.pharmacy || session.name || 'Account';
    const initials = licEsc(displayName).replace(/[^A-Za-z0-9 ]/g,'').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase() || 'U';
    el.innerHTML = `
        <button class="tb-avatar-btn" id="tb-profile-btn" onclick="tbProfileToggle(event)" title="${licEsc(displayName)}">
            <span class="tb-avatar-circle">${initials}</span>
            <span class="tb-avatar-label">Profile</span>
        </button>
        <div class="tb-profile-menu" id="tb-profile-menu">
            <div class="tb-profile-header">
                <div class="tb-profile-name">${licEsc(displayName)}</div>
                <div class="tb-profile-sub">${session.endDate ? 'License valid through ' + licFmtDate(session.endDate) : 'Active session'}</div>
            </div>
            <button class="tb-profile-item" onclick="tbShowAccount()">
                <span>👤</span><span>My Account</span>
            </button>
            <button class="tb-profile-item" onclick="tbProfileClose();if(typeof settingsSidebarOpen==='function')settingsSidebarOpen();">
                <span>⚙️</span><span>Settings</span>
            </button>
            <button class="tb-profile-item" onclick="tbProfileClose();if(typeof helpCenterOpen==='function')helpCenterOpen();">
                <span>📖</span><span>Help Center</span>
            </button>
            <button class="tb-profile-item" onclick="tourStart(true);tbProfileClose();">
                <span>❓</span><span>Help Tour</span>
            </button>
            <button class="tb-profile-item" onclick="tbProfileClose();if(typeof infoSidebarOpen==='function')infoSidebarOpen();">
                <span>ℹ️</span><span>About RxAuditwise</span>
            </button>
            <button class="tb-profile-item danger" onclick="tbProfileClose();licLogout();">
                <span>🚪</span><span>Sign Out</span>
            </button>
        </div>`;
}

function tbProfileToggle(e) {
    if (e) e.stopPropagation();
    const menu = document.getElementById('tb-profile-menu');
    const btn = document.getElementById('tb-profile-btn');
    if (!menu) return;
    const willOpen = !menu.classList.contains('open');
    document.querySelectorAll('.tb-profile-menu.open, .df-panel.open').forEach(m => m.classList.remove('open'));
    document.querySelectorAll('.tb-expand-btn.force-expand, .tb-avatar-btn.force-expand').forEach(b => b.classList.remove('force-expand'));
    if (willOpen) {
        menu.classList.add('open');
        if (btn) btn.classList.add('force-expand');
    }
}
function tbProfileClose() {
    const menu = document.getElementById('tb-profile-menu');
    const btn = document.getElementById('tb-profile-btn');
    if (menu) menu.classList.remove('open');
    if (btn) btn.classList.remove('force-expand');
}
function tbShowAccount() {
    tbProfileClose();
    if (typeof accountSidebarOpen === 'function') accountSidebarOpen();
}
document.addEventListener('click', function(e) {
    const menu = document.getElementById('tb-profile-menu');
    const wrap = document.getElementById('tb-profile-wrap');
    const btn  = document.getElementById('tb-profile-btn');
    if (menu && menu.classList.contains('open') && wrap && !wrap.contains(e.target)) {
        menu.classList.remove('open');
        if (btn) btn.classList.remove('force-expand');
    }
});

// ── Require login ─────────────────────────────────────────────
function licRequireLogin() {
    const session = licGetSession();
    if (session && session.token) { licUpdateTopbar(session); return true; }
    const uplSc = document.getElementById('upload-screen');
    if (uplSc) uplSc.style.pointerEvents = 'none';
    licShowLogin({
        onSuccess: function(sess) {
            if (uplSc) uplSc.style.pointerEvents = '';
            licUpdateTopbar(sess);
        }
    });
    return false;
}

// ── Gate overlay ──────────────────────────────────────────────
async function licShowGate(result) {
    const contact = await licFetchContact();
    const name  = contact.adminName  || LIC_DEFAULT_CONTACT.adminName;
    const org   = contact.adminOrg   || LIC_DEFAULT_CONTACT.adminOrg;
    const email = contact.adminEmail || LIC_DEFAULT_CONTACT.adminEmail;
    const phone = contact.adminPhone || LIC_DEFAULT_CONTACT.adminPhone;
    const reason = result && result.reason;
    const user   = result && result.user;

    if (reason === 'not_logged_in') { licRequireLogin(); return; }
    if (typeof setPageTitle === 'function') setPageTitle('gate');

    let icon, title, msg, tone;
    if (reason === 'expired') {
        icon='⏰'; title='Subscription Expired'; tone='amber';
        msg=`The subscription for <strong>${licEsc(user?.pharmacy||'your pharmacy')}</strong> expired on <strong>${licFmtDate(user?.endDate)}</strong>. Contact your administrator to renew.`;
    } else if (reason === 'no_codes') {
        icon='🔑'; title='No License Codes'; tone='blue';
        msg=`No license codes are registered for <strong>${licEsc(user?.pharmacy||'your pharmacy')}</strong>. Contact your administrator.`;
    } else if (reason === 'inactive') {
        icon='🚫'; title='Account Inactive'; tone='red';
        msg='Your pharmacy account is currently inactive. Contact your administrator.';
    } else {
        icon='🔒'; title='License Code Not Found'; tone='slate';
        msg=`None of the uploaded files contain a license code for <strong>${licEsc(user?.pharmacy||'your pharmacy')}</strong>. Make sure you are uploading files for your registered pharmacy location.`;
    }

    const old = document.getElementById('lic-gate-overlay');
    if (old) old.remove();

    const div = document.createElement('div');
    div.id = 'lic-gate-overlay';
    div.innerHTML = `
        <div class="lic-gate-box lic-tone-${tone}">
            <div class="lic-gate-accent"></div>
            <div class="lic-gate-body">
                <div class="lic-gate-icon-badge">${icon}</div>
                <div class="lic-gate-title">${title}</div>
                <div class="lic-gate-msg">${msg}</div>
                <div class="lic-gate-card">
                    <div class="lic-gate-org">${licEsc(org)}</div>
                    <div class="lic-cr"><span class="lic-ico-badge">👤</span><span>${licEsc(name)}</span></div>
                    <div class="lic-cr"><span class="lic-ico-badge">✉️</span><a href="mailto:${licEsc(email)}">${licEsc(email)}</a></div>
                    <div class="lic-cr"><span class="lic-ico-badge">📞</span><span>${licEsc(phone)}</span></div>
                </div>
                <button class="lic-gate-btn" onclick="document.getElementById('lic-gate-overlay').remove()">
                    <span>Try Again</span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" width="15" height="15">
                        <path d="M3 12a9 9 0 1 0 9-9" stroke-linecap="round"/>
                        <path d="M3 4v6h6" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
        </div>`;
    document.body.appendChild(div);
}

function licFmtDate(d) {
    if (!d) return '—';
    const [y,m,da] = d.split('-');
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return `${months[+m-1]} ${+da}, ${y}`;
}

// ── Admin-controlled theme colors ───────────────────────────────
const LIC_THEME_CACHE_KEY = 'rxaw_theme_v1';
const LIC_DEFAULT_THEME = { primary:'#7c3aed', ok:'#16a34a', danger:'#dc2626', warn:'#b45309', bg:'#f0f2f5',
    rowOk:'#dcfce7', rowOver:'#dbeafe', rowShort:'#fee2e2' };

// Converts a hex color to an unquoted "r,g,b" triplet for use in rgba(var(--x), alpha).
function licHexToRgbTriplet(hex) {
    hex = String(hex || '').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    if (isNaN(num)) return '124,58,237';
    return [(num >> 16) & 255, (num >> 8) & 255, num & 255].join(',');
}

// Lightens (positive percent) or darkens (negative percent) a hex color.
function licShadeColor(hex, percent) {
    hex = String(hex || '').replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    if (isNaN(num)) return '#7c3aed';
    const amt = Math.round(2.55 * percent);
    let r = (num >> 16) + amt, g = (num >> 8 & 0x00FF) + amt, b = (num & 0x0000FF) + amt;
    r = Math.max(0, Math.min(255, r)); g = Math.max(0, Math.min(255, g)); b = Math.max(0, Math.min(255, b));
    return '#' + (0x1000000 + r * 0x10000 + g * 0x100 + b).toString(16).slice(1);
}
// Applies a theme object ({primary, ok, danger, warn}) as CSS custom properties.
// Missing fields fall back to defaults; darker primary shades are derived automatically
// so an admin only has to pick one primary color, not three coordinated shades.
function licApplyTheme(theme) {
    const t = { ...LIC_DEFAULT_THEME, ...(theme || {}) };
    const root = document.documentElement.style;
    root.setProperty('--rxa-primary', t.primary);
    root.setProperty('--rxa-primary-600', licShadeColor(t.primary, -12));
    root.setProperty('--rxa-primary-700', licShadeColor(t.primary, -25));
    root.setProperty('--rxa-ok', t.ok);
    root.setProperty('--rxa-danger', t.danger);
    root.setProperty('--rxa-warn-dark', t.warn);
    root.setProperty('--bg', t.bg);
    root.setProperty('--rxa-primary-rgb', licHexToRgbTriplet(t.primary));
    root.setProperty('--rxa-total-ok', t.rowOk);
    root.setProperty('--rxa-total-over', t.rowOver);
    root.setProperty('--rxa-total-short', t.rowShort);
    // --border was previously hardcoded to a fixed purple tint (#7c3aed3b) at
    // :root and never touched here, so it stayed purple no matter what color
    // an admin picked. Deriving it from the chosen primary color instead —
    // same translucency the original hardcoded value had (~23% opacity).
    root.setProperty('--border', `rgba(${licHexToRgbTriplet(t.primary)},.23)`);
}
async function licFetchAndApplyTheme() {
    // Apply instantly from cache first (avoids a flash of default colors on repeat visits)
    try {
        const cached = JSON.parse(localStorage.getItem(LIC_THEME_CACHE_KEY) || 'null');
        if (cached) licApplyTheme(cached);
    } catch(e) {}
    // Then fetch the current server value and update if it differs
    try {
        const r = await fetch(LIC_API, { method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ action:'get_config_public' }) });
        if (!r.ok) return;
        const j = await r.json();
        if (j.ok && j.config && j.config.theme) {
            licApplyTheme(j.config.theme);
            localStorage.setItem(LIC_THEME_CACHE_KEY, JSON.stringify(j.config.theme));
        }
    } catch(e) {}
}
licFetchAndApplyTheme();
if (typeof _tbFillContactCard === 'function') _tbFillContactCard('lic');
if (typeof _updateFormatHintMailto === 'function') _updateFormatHintMailto();
