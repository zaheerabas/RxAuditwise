<?php
/**
 * RxAuditwise — Mailer v3.0
 * PHP mail() only — no cron, no SMTP library needed.
 * Three emails only:
 *   1. Welcome email when admin adds a new user
 *   2. Password reset link (user forgot password)
 *   3. Login alert to admin when any user logs in
 */

@error_reporting(0);

function mailerGetSettings() {
    try {
        $r = db()->query("SELECT sval FROM rxa_settings WHERE skey='email_settings' LIMIT 1")->fetch();
        return $r ? json_decode($r['sval'], true) : [];
    } catch(Exception $e) { return []; }
}

function mailerGetContact() {
    try {
        $r = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
        return $r ? json_decode($r['sval'], true) : [];
    } catch(Exception $e) { return []; }
}

/**
 * Core send function using PHP mail().
 * Returns ['ok'=>true] or ['ok'=>false, 'error'=>'...']
 */
function mailerSend($to, $subject, $html, $text = '') {
    $cfg  = mailerGetSettings();
    $from = trim($cfg['from_email'] ?? '');
    $name = trim($cfg['from_name']  ?? 'RxAuditwise');

    if (!$from) return ['ok'=>false, 'error'=>'Sender email not configured. Set it in Email Settings.'];
    if (!$to)   return ['ok'=>false, 'error'=>'No recipient email address'];

    if (!$text) {
        $text = strip_tags(str_replace(
            ['<br>', '<br/>', '<br />', '</p>', '</div>', '</tr>', '</li>'],
            "\n", $html
        ));
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\n{3,}/', "\n\n", trim($text));
    }

    $boundary = '----=_' . md5(uniqid(rand(), true));

    $headers = implode("\r\n", [
        "From: {$name} <{$from}>",
        "Reply-To: {$from}",
        "MIME-Version: 1.0",
        "Content-Type: multipart/alternative; boundary=\"{$boundary}\"",
        "X-Mailer: RxAuditwise/3.0",
        "X-Priority: 3",
    ]);

    $body = "--{$boundary}\r\n"
          . "Content-Type: text/plain; charset=UTF-8\r\n"
          . "Content-Transfer-Encoding: base64\r\n\r\n"
          . chunk_split(base64_encode($text)) . "\r\n"
          . "--{$boundary}\r\n"
          . "Content-Type: text/html; charset=UTF-8\r\n"
          . "Content-Transfer-Encoding: base64\r\n\r\n"
          . chunk_split(base64_encode($html)) . "\r\n"
          . "--{$boundary}--";

    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $ok = @mail($to, $encodedSubject, $body, $headers);

    if ($ok) return ['ok' => true];
    $err = error_get_last();
    return ['ok' => false, 'error' => 'mail() failed: ' . ($err['message'] ?? 'Unknown error. Check cPanel mail settings.')];
}

/**
 * Build a clean HTML email template.
 */
function mailerLayout($headline, $bodyHtml, $org = 'RxAuditwise') {
    $orgSafe = htmlspecialchars($org);
    $headSafe = htmlspecialchars($headline);
    return <<<HTML
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px">
  <tr><td align="center">
  <table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%">
    <tr><td style="background:#1e1b4b;border-radius:14px 14px 0 0;padding:24px 32px">
      <div style="color:#fff;font-size:22px;font-weight:800">💊 {$orgSafe}</div>
      <div style="font-size:11px;color:rgba(255,255,255,.65);margin-top:2px;letter-spacing:1px;text-transform:uppercase">Pharmacy Purchase Reconciliation</div>
    </td></tr>
    <tr><td style="background:#fff;padding:28px 32px">
      <h2 style="color:#0f172a;font-size:18px;margin:0 0 18px;font-weight:700">{$headSafe}</h2>
      {$bodyHtml}
    </td></tr>
    <tr><td style="background:#f8fafc;border-top:1px solid #e2e8f0;border-radius:0 0 14px 14px;padding:12px 32px;text-align:center">
      <div style="font-size:11px;color:#94a3b8">{$orgSafe} · RxAuditwise · Pharmacy Purchase Reconciliation</div>
    </td></tr>
  </table>
  </td></tr>
</table>
</body>
</html>
HTML;
}

// ══════════════════════════════════════════════════════════════
//  EMAIL 1: Welcome — sent when admin creates a new user
// ══════════════════════════════════════════════════════════════
function mailerSendWelcome($user) {
    if (empty($user['email'])) return;

    $contact = mailerGetContact();
    $org     = $contact['adminOrg']   ?? 'RxAuditwise';
    $aEmail  = $contact['adminEmail'] ?? '';
    $aPhone  = $contact['adminPhone'] ?? '';

    $name   = htmlspecialchars($user['name']);
    $pharm  = htmlspecialchars($user['pharmacy']);
    $start  = !empty($user['start_date']) ? date('F j, Y', strtotime($user['start_date'])) : '—';
    $end    = !empty($user['end_date'])   ? date('F j, Y', strtotime($user['end_date']))   : '—';
    $contactHtml = '';
    if ($aEmail) $contactHtml .= "<div style='font-size:13px;color:#475569;margin-bottom:4px'>✉️ <a href='mailto:{$aEmail}' style='color:#2563eb'>{$aEmail}</a></div>";
    if ($aPhone) $contactHtml .= "<div style='font-size:13px;color:#475569'>📞 {$aPhone}</div>";

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px">Dear <strong>{$name}</strong>,</p>
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 20px">Your RxAuditwise pharmacy account has been created and is now active. Here are your account details:</p>

<table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:22px">
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0;width:38%">Pharmacy</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:600">{$pharm}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Subscription Start</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$start}</td></tr>
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Subscription End</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:700;color:#16a34a">{$end}</td></tr>
</table>

<div style="background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:10px;padding:14px 18px;margin-bottom:20px">
  <div style="font-weight:700;color:#1e40af;margin-bottom:8px">🚀 How to get started:</div>
  <ol style="color:#1e40af;font-size:13px;line-height:2;margin:0;padding-left:18px">
    <li>Open the RxAuditwise application</li>
    <li>Sign in with your username and password</li>
    <li>Upload your Supplier and Billing files</li>
    <li>Click <strong>Run Reconciliation</strong> — your license code is detected automatically</li>
  </ol>
</div>

<div style="background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:14px 18px">
  <div style="font-weight:700;font-size:14px;margin-bottom:8px">Need help? Contact your administrator:</div>
  {$contactHtml}
</div>

<p style="color:#94a3b8;font-size:12px;margin-top:18px;line-height:1.6">This is an automated message. Do not reply to this email — use the contact information above.</p>
HTML;

    $html = mailerLayout("🎉 Welcome to RxAuditwise!", $bodyHtml, $org);
    return mailerSend($user['email'], "[RxAuditwise] Welcome — Your account is ready", $html);
}

// ══════════════════════════════════════════════════════════════
//  EMAIL 2: Password reset link — sent when user clicks "Forgot Password"
// ══════════════════════════════════════════════════════════════
function mailerSendUserReset($user, $token) {
    if (empty($user['email'])) return ['ok'=>false,'error'=>'No email on file'];

    $contact = mailerGetContact();
    $org     = $contact['adminOrg'] ?? 'RxAuditwise';
    $name    = htmlspecialchars($user['name']);

    // Build reset URL from server info
    $proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host    = $_SERVER['HTTP_HOST'] ?? 'yourdomain.com';
    $dir     = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
    $resetUrl = $proto . '://' . $host . $dir . '/index.html?reset_token=' . urlencode($token);
    $safeUrl  = htmlspecialchars($resetUrl);

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px">Hi <strong>{$name}</strong>,</p>
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 24px">We received a request to reset the password for your RxAuditwise account. Click the button below to set a new password:</p>

<div style="text-align:center;margin:28px 0">
  <a href="{$safeUrl}"
     style="background:#7c3aed;color:#fff;text-decoration:none;padding:14px 32px;border-radius:10px;font-size:16px;font-weight:700;display:inline-block">
    🔒 Reset My Password
  </a>
</div>

<p style="color:#64748b;font-size:13px;line-height:1.7;margin:0 0 12px">Or copy and paste this link into your browser:</p>
<p style="word-break:break-all;font-size:12px;color:#2563eb;margin:0 0 22px">
  <a href="{$safeUrl}" style="color:#2563eb">{$safeUrl}</a>
</p>

<div style="background:#fef9c3;border:1px solid #fde047;border-radius:8px;padding:12px 16px;margin-bottom:16px">
  <div style="font-size:13px;color:#713f12">⏰ <strong>This link expires in 1 hour.</strong> If it has expired, go back and request a new reset link.</div>
</div>

<p style="color:#94a3b8;font-size:12px;line-height:1.6;margin:0">If you did not request a password reset, you can safely ignore this email — your account has not been changed.</p>
HTML;

    $html = mailerLayout("Reset Your Password", $bodyHtml, $org);
    return mailerSend($user['email'], "[RxAuditwise] Password Reset Request", $html);
}

// ══════════════════════════════════════════════════════════════
//  EMAIL 3: Login alert to admin — sent on every pharmacy user login
// ══════════════════════════════════════════════════════════════
function mailerSendLoginAlertToAdmin($user, $ip) {
    $cfg     = mailerGetSettings();
    $adminTo = trim($cfg['admin_notify_email'] ?? '');

    // Send login confirmation to the USER themselves
    if (!empty($user['email'])) {
        $uname   = htmlspecialchars($user['name']);
        $pharm   = htmlspecialchars($user['pharmacy']);
        $time    = date('F j, Y \a\t g:i A T');
        $safeIp  = htmlspecialchars($ip);
        $contact = mailerGetContact();
        $org     = $contact['adminOrg'] ?? 'RxAuditwise';
        $aEmail  = $contact['adminEmail'] ?? '';
        $contactLine = $aEmail ? "<p style='color:#64748b;font-size:12px;margin:12px 0 0'>Questions? Contact your administrator: <a href='mailto:{$aEmail}' style='color:#2563eb'>{$aEmail}</a></p>" : '';

        $userBodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px">Hi <strong>{$uname}</strong>,</p>
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 20px">
  You have successfully signed in to RxAuditwise.
</p>
<table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:20px">
  <tr style="background:#f8fafc">
    <td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0;width:38%">Pharmacy</td>
    <td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:600">{$pharm}</td>
  </tr>
  <tr>
    <td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Login Time</td>
    <td style="padding:10px 14px;border:1px solid #e2e8f0">{$time}</td>
  </tr>
  <tr style="background:#f8fafc">
    <td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">IP Address</td>
    <td style="padding:10px 14px;border:1px solid #e2e8f0;font-family:'Courier New',monospace">{$safeIp}</td>
  </tr>
</table>
<p style="color:#94a3b8;font-size:12px;line-height:1.6;margin:0">
  If this was not you, contact your administrator immediately.
</p>
{$contactLine}
HTML;
        $userHtml = mailerLayout('🔐 Login Confirmation', $userBodyHtml, $org);
        mailerSend($user['email'], '[RxAuditwise] Successful Login to Your Account', $userHtml);
    }

    if (!$adminTo) return; // admin email not configured — skip admin alert

    $contact = mailerGetContact();
    $org     = $contact['adminOrg'] ?? 'RxAuditwise';

    $name    = htmlspecialchars($user['name']);
    $pharm   = htmlspecialchars($user['pharmacy']);
    $uname   = htmlspecialchars($user['username'] ?? '');
    $time    = date('F j, Y \a\t g:i A T');
    $safeIp  = htmlspecialchars($ip);

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 18px">
  A pharmacy user has logged in to RxAuditwise.
</p>

<table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:22px">
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0;width:35%">User Name</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:600">{$name}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Pharmacy</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$pharm}</td></tr>
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Username</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-family:'Courier New',monospace">{$uname}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Login Time</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$time}</td></tr>
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">IP Address</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-family:'Courier New',monospace">{$safeIp}</td></tr>
</table>

<p style="color:#94a3b8;font-size:12px;line-height:1.6;margin:0">This is an automated notification from RxAuditwise.</p>
HTML;

    $html = mailerLayout("🔐 User Login Notification", $bodyHtml, $org);
    mailerSend($adminTo, "[RxAuditwise] Login: {$name} ({$pharm})", $html);
}

// ══════════════════════════════════════════════════════════════
//  Admin password reset email (for admin forgot password flow)
// ══════════════════════════════════════════════════════════════
function mailerSendAdminReset($username, $email, $token) {
    $contact = mailerGetContact();
    $org     = $contact['adminOrg'] ?? 'RxAuditwise';

    $proto    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host     = $_SERVER['HTTP_HOST'] ?? 'yourdomain.com';
    $dir      = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
    $resetUrl = $proto . '://' . $host . $dir . '/admin.html?reset_token=' . urlencode($token);
    $safeUrl  = htmlspecialchars($resetUrl);
    $safeUser = htmlspecialchars($username);

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px">Hi <strong>{$safeUser}</strong>,</p>
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 24px">A password reset was requested for the RxAuditwise admin account.</p>

<div style="text-align:center;margin:28px 0">
  <a href="{$safeUrl}"
     style="background:#dc2626;color:#fff;text-decoration:none;padding:14px 32px;border-radius:10px;font-size:16px;font-weight:700;display:inline-block">
    🔒 Reset Admin Password
  </a>
</div>

<p style="color:#64748b;font-size:13px;margin:0 0 12px">Or copy this link:</p>
<p style="word-break:break-all;font-size:12px;color:#2563eb;margin:0 0 20px">
  <a href="{$safeUrl}" style="color:#2563eb">{$safeUrl}</a>
</p>

<div style="background:#fef9c3;border:1px solid #fde047;border-radius:8px;padding:12px 16px;margin-bottom:16px">
  <div style="font-size:13px;color:#713f12">⏰ <strong>Expires in 1 hour.</strong></div>
</div>

<p style="color:#94a3b8;font-size:12px;line-height:1.6;margin:0">If you did not request this, ignore this email — the admin account is safe.</p>
HTML;

    $html = mailerLayout("Admin Password Reset", $bodyHtml, $org);
    return mailerSend($email, "[RxAuditwise Admin] Password Reset Request", $html);
}

// ══════════════════════════════════════════════════════════════
//  STUB FUNCTIONS — called by api.php expiry check
//  (expiry emails are disabled per user request — stubs prevent fatal errors)
// ══════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════
//  EXPIRY REMINDERS — fires automatically on login via runUserExpiryCheck()
//  at 30/15/7/3/1/0 days remaining. No cron needed; alert_sent_flags on the
//  user row prevents the same threshold firing twice.
// ══════════════════════════════════════════════════════════════
function mailerBuildExpiryEmail($user, $daysLeft, $adminContact) {
    $name  = htmlspecialchars($user['name'] ?? '');
    $pharm = htmlspecialchars($user['pharmacy'] ?? '');
    $end   = !empty($user['end_date']) ? date('F j, Y', strtotime($user['end_date'])) : '—';
    $org   = $adminContact['adminOrg']   ?? 'RxAuditwise';
    $aName = $adminContact['adminName']  ?? '';
    $aEmail= $adminContact['adminEmail'] ?? '';
    $aPhone= $adminContact['adminPhone'] ?? '';

    if ($daysLeft <= 0)      { $tone = ['#dc2626','#fef2f2','#fecaca']; $when = 'today';                       $subjectWhen = 'expires today'; }
    elseif ($daysLeft <= 3)  { $tone = ['#dc2626','#fef2f2','#fecaca']; $when = "in {$daysLeft} day" . ($daysLeft==1?'':'s'); $subjectWhen = "expires in {$daysLeft} day" . ($daysLeft==1?'':'s'); }
    elseif ($daysLeft <= 7)  { $tone = ['#d97706','#fffbeb','#fde68a']; $when = "in {$daysLeft} days";          $subjectWhen = "expires in {$daysLeft} days"; }
    else                     { $tone = ['#2563eb','#eff6ff','#bfdbfe']; $when = "in {$daysLeft} days";          $subjectWhen = "expires in {$daysLeft} days"; }
    [$accent, $bg, $border] = $tone;

    $contactHtml = '';
    if ($aName)  $contactHtml .= "<div style='font-size:13px;color:#475569;margin-bottom:4px'>👤 {$aName}</div>";
    if ($aEmail) $contactHtml .= "<div style='font-size:13px;color:#475569;margin-bottom:4px'>✉️ <a href='mailto:{$aEmail}' style='color:#2563eb'>{$aEmail}</a></div>";
    if ($aPhone) $contactHtml .= "<div style='font-size:13px;color:#475569'>📞 {$aPhone}</div>";
    if (!$contactHtml) $contactHtml = "<div style='font-size:13px;color:#475569'>Contact your administrator to renew.</div>";

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px">Dear <strong>{$name}</strong>,</p>
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 20px">This is a reminder that the RxAuditwise subscription for <strong>{$pharm}</strong> {$subjectWhen}.</p>

<div style="background:{$bg};border:1.5px solid {$border};border-radius:10px;padding:16px 20px;margin-bottom:20px;text-align:center">
  <div style="font-size:13px;color:{$accent};font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Subscription expires {$when}</div>
  <div style="font-size:22px;font-weight:800;color:#0f172a">{$end}</div>
</div>

<p style="color:#475569;font-size:14px;line-height:1.7;margin:0 0 18px">To avoid any interruption to your pharmacy purchase reconciliation, please contact your administrator to renew before this date.</p>

<div style="background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:14px 18px">
  <div style="font-weight:700;font-size:14px;margin-bottom:8px">Renew with your administrator:</div>
  {$contactHtml}
</div>

<p style="color:#94a3b8;font-size:12px;margin-top:18px;line-height:1.6">This is an automated reminder. Do not reply to this email — use the contact information above.</p>
HTML;

    $headline = $daysLeft <= 0 ? "⏰ Your subscription expires today" : "⏰ Your subscription {$subjectWhen}";
    $html = mailerLayout($headline, $bodyHtml, $org);
    $subject = $daysLeft <= 0
        ? "[RxAuditwise] Subscription expires today — {$pharm}"
        : "[RxAuditwise] Subscription {$subjectWhen} — {$pharm}";
    return ['subject' => $subject, 'html' => $html];
}

function mailerBuildAdminExpiryEmail($user, $daysLeft, $adminEmail) {
    $name  = htmlspecialchars($user['name'] ?? '');
    $pharm = htmlspecialchars($user['pharmacy'] ?? '');
    $email = htmlspecialchars($user['email'] ?? '—');
    $phone = htmlspecialchars($user['phone'] ?? '—');
    $end   = !empty($user['end_date']) ? date('F j, Y', strtotime($user['end_date'])) : '—';
    $when  = $daysLeft <= 0 ? 'today' : "in {$daysLeft} day" . ($daysLeft==1?'':'s');
    $accent = $daysLeft <= 3 ? '#dc2626' : ($daysLeft <= 7 ? '#d97706' : '#2563eb');

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 18px">A pharmacy subscription is expiring {$when} and may need renewal.</p>

<table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:20px">
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0;width:34%">Pharmacy</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:600">{$pharm}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Contact</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$name}</td></tr>
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Email</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$email}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Phone</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$phone}</td></tr>
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Expires</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:700;color:{$accent}">{$end}</td></tr>
</table>

<p style="color:#475569;font-size:14px;line-height:1.7">Log in to the admin panel's Users page to renew or reach out to the pharmacy directly.</p>
HTML;

    $html = mailerLayout("⏰ Subscription expiring {$when}", $bodyHtml, 'RxAuditwise Admin');
    return ['subject' => "[RxAuditwise Admin] {$pharm} expires {$when}", 'html' => $html];
}

// ══════════════════════════════════════════════════════════════
//  ASK ADMIN — a user submits a question from the Help Center.
//  Notifies the admin with the question; confirms receipt to the user.
// ══════════════════════════════════════════════════════════════
function mailerSendUserQuestionToAdmin($user, $question, $adminEmail) {
    $name  = htmlspecialchars($user['name'] ?? '');
    $pharm = htmlspecialchars($user['pharmacy'] ?? '');
    $email = htmlspecialchars($user['email'] ?? '—');
    $phone = htmlspecialchars($user['phone'] ?? '—');
    $qSafe = nl2br(htmlspecialchars($question));

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:14px;line-height:1.7;margin:0 0 16px">A question was submitted from the Help Center.</p>

<table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:20px">
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0;width:30%">Pharmacy</td><td style="padding:10px 14px;border:1px solid #e2e8f0;font-weight:600">{$pharm}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Contact</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$name}</td></tr>
  <tr style="background:#f8fafc"><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Email</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$email}</td></tr>
  <tr><td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Phone</td><td style="padding:10px 14px;border:1px solid #e2e8f0">{$phone}</td></tr>
</table>

<div style="background:#faf9ff;border:1.5px solid #e5e0fa;border-radius:10px;padding:16px 18px;">
  <div style="font-weight:700;font-size:13px;color:#6d28d9;margin-bottom:8px;">Question</div>
  <div style="font-size:14px;color:#0f172a;line-height:1.6;">{$qSafe}</div>
</div>

<p style="color:#475569;font-size:13px;line-height:1.6;margin-top:18px">Reply directly to this email to respond to {$name} at {$email}.</p>
HTML;

    $html = mailerLayout("💬 New question from {$pharm}", $bodyHtml, 'RxAuditwise Admin');
    $subject = "[RxAuditwise] Question from {$pharm}";
    // Reply-To the user's own email so the admin can respond directly from their inbox
    return mailerSendWithReplyTo($adminEmail, $subject, $html, $user['email'] ?? null);
}

function mailerSendUserQuestionConfirmation($user, $question) {
    if (empty($user['email'])) return ['ok' => false, 'error' => 'User has no email on file'];
    $name  = htmlspecialchars($user['name'] ?? '');
    $qSafe = nl2br(htmlspecialchars($question));

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 18px">Hi {$name},</p>
<p style="color:#475569;font-size:14px;line-height:1.7;margin:0 0 18px">We've received your question and someone will get back to you shortly.</p>

<div style="background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;padding:16px 18px;">
  <div style="font-weight:700;font-size:13px;color:#64748b;margin-bottom:8px;">Your question</div>
  <div style="font-size:14px;color:#0f172a;line-height:1.6;">{$qSafe}</div>
</div>

<p style="color:#94a3b8;font-size:12px;margin-top:18px;line-height:1.6">This is an automated confirmation — no need to reply to this email.</p>
HTML;

    $html = mailerLayout("✅ We received your question", $bodyHtml);
    return mailerSend($user['email'], "[RxAuditwise] We received your question", $html);
}

// Like mailerSend() but sets a different Reply-To than the From address —
// used so the admin can hit "reply" and land directly in the user's inbox.
function mailerSendWithReplyTo($to, $subject, $html, $replyTo = null) {
    $cfg  = mailerGetSettings();
    $from = trim($cfg['from_email'] ?? '');
    $name = trim($cfg['from_name']  ?? 'RxAuditwise');
    if (!$from) return ['ok'=>false, 'error'=>'Sender email not configured. Set it in Email Settings.'];
    if (!$to)   return ['ok'=>false, 'error'=>'No recipient email address'];

    $text = strip_tags(str_replace(['<br>','<br/>','<br />','</p>','</div>','</tr>','</li>'], "\n", $html));
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace('/\n{3,}/', "\n\n", trim($text));

    $boundary = '----=_' . md5(uniqid(rand(), true));
    $replyToAddr = $replyTo ?: $from;
    $headers = implode("\r\n", [
        "From: {$name} <{$from}>",
        "Reply-To: {$replyToAddr}",
        "MIME-Version: 1.0",
        "Content-Type: multipart/alternative; boundary=\"{$boundary}\"",
        "X-Mailer: RxAuditwise/3.0",
        "X-Priority: 3",
    ]);
    $body = "--{$boundary}\r\n"
          . "Content-Type: text/plain; charset=UTF-8\r\n"
          . "Content-Transfer-Encoding: base64\r\n\r\n"
          . chunk_split(base64_encode($text)) . "\r\n"
          . "--{$boundary}\r\n"
          . "Content-Type: text/html; charset=UTF-8\r\n"
          . "Content-Transfer-Encoding: base64\r\n\r\n"
          . chunk_split(base64_encode($html)) . "\r\n"
          . "--{$boundary}--";
    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $ok = @mail($to, $encodedSubject, $body, $headers);
    if ($ok) return ['ok' => true];
    $err = error_get_last();
    return ['ok' => false, 'error' => 'mail() failed: ' . ($err['message'] ?? 'Unknown error.')];
}

// ══════════════════════════════════════════════════════════════
//  TEST EMAIL — called from admin panel "Send Test Email"
// ══════════════════════════════════════════════════════════════
function mailerSendTest($to) {
    $contact = mailerGetContact();
    $org     = $contact['adminOrg'] ?? 'RxAuditwise';
    $time    = date('F j, Y \a\t g:i A T');

    $bodyHtml = <<<HTML
<p style="color:#475569;font-size:15px;line-height:1.7;margin:0 0 16px">
  This is a <strong>test email</strong> from your RxAuditwise installation.
</p>
<table style="width:100%;border-collapse:collapse;font-size:14px;margin-bottom:22px">
  <tr style="background:#f8fafc">
    <td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0;width:40%">Sent At</td>
    <td style="padding:10px 14px;border:1px solid #e2e8f0">{$time}</td>
  </tr>
  <tr>
    <td style="padding:10px 14px;color:#64748b;border:1px solid #e2e8f0">Status</td>
    <td style="padding:10px 14px;border:1px solid #e2e8f0;color:#16a34a;font-weight:700">✓ Email delivery is working</td>
  </tr>
</table>
<p style="color:#475569;font-size:13px;line-height:1.7;margin:0">
  If you received this, your email configuration is correct. Welcome emails, password resets, and login alerts will be delivered successfully.
</p>
HTML;
    $html = mailerLayout('✅ Test Email — Configuration OK', $bodyHtml, $org);
    return mailerSend($to, '[RxAuditwise] Test Email — Configuration Check', $html);
}
