<?php
/**
 * RxAuditwise — Database Installer v5.0
 * Run ONCE. Safe to re-run. DELETE THIS FILE after setup.
 *
 * ── EDIT THESE 3 LINES ──────────────────────────────────────
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'ximtwwsi_rx');   // ← cPanel DB name
define('DB_USER', 'ximtwwsi_rx');   // ← cPanel DB username
define('DB_PASS', 'Rx@2141audit'); // ← cPanel DB password
// ────────────────────────────────────────────────────────────

function box($ok,$title,$body){
    $c=$ok?'#16a34a':'#dc2626';
    echo "<div style='font-family:-apple-system,sans-serif;max-width:660px;margin:36px auto;padding:28px 34px;border:2px solid {$c};border-radius:14px;background:#f8fafc'>
          <h2 style='color:{$c};margin:0 0 16px'>".($ok?'✅':'❌')." {$title}</h2>
          <div style='color:#334155;line-height:1.9;font-size:15px'>{$body}</div></div>";
}

try {
    $pdo = new PDO(
        'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
        DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // ── Users table ─────────────────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS rxa_users (
        id                   VARCHAR(64)   PRIMARY KEY,
        username             VARCHAR(100)  UNIQUE DEFAULT NULL,
        password_hash        VARCHAR(255)  DEFAULT NULL,
        name                 VARCHAR(255)  NOT NULL,
        pharmacy             VARCHAR(255)  NOT NULL DEFAULT '',
        phone                VARCHAR(100)  DEFAULT '',
        email                VARCHAR(255)  DEFAULT '',
        address              TEXT,
        notes                TEXT,
        codes                JSON          NOT NULL DEFAULT ('[]'),
        start_date           DATE,
        end_date             DATE,
        active               TINYINT(1)   NOT NULL DEFAULT 1,
        alert_sent_flags     JSON         NOT NULL DEFAULT ('[]'),
        session_token        VARCHAR(255)  DEFAULT NULL,
        session_expires      DATETIME     DEFAULT NULL,
        reset_token          VARCHAR(255)  DEFAULT NULL,
        reset_token_expires  DATETIME     DEFAULT NULL,
        created_at           DATETIME     NOT NULL,
        updated_at           DATETIME     NOT NULL,
        INDEX idx_end        (end_date),
        INDEX idx_active     (active),
        INDEX idx_username   (username),
        INDEX idx_session    (session_token)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Safe upgrade: add new columns if upgrading from older version
    $upgradeCols = [
        "ALTER TABLE rxa_users ADD COLUMN username VARCHAR(100) UNIQUE DEFAULT NULL",
        "ALTER TABLE rxa_users ADD COLUMN password_hash VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE rxa_users ADD COLUMN alert_sent_flags JSON NOT NULL DEFAULT ('[]')",
        "ALTER TABLE rxa_users ADD COLUMN session_token VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE rxa_users ADD COLUMN session_expires DATETIME DEFAULT NULL",
        "ALTER TABLE rxa_users ADD COLUMN reset_token VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE rxa_users ADD COLUMN reset_token_expires DATETIME DEFAULT NULL",
    ];
    foreach ($upgradeCols as $sql) {
        try { $pdo->exec($sql); } catch(Exception $e) { /* column already exists */ }
    }

    // ── Settings table ──────────────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS rxa_settings (
        skey VARCHAR(100) PRIMARY KEY,
        sval LONGTEXT     NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // ── Activity logs table ─────────────────────────────────
    $pdo->exec("CREATE TABLE IF NOT EXISTS rxa_logs (
        id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        event      VARCHAR(60)   NOT NULL,
        detail     TEXT          NOT NULL DEFAULT '',
        actor      VARCHAR(100)  NOT NULL DEFAULT 'system',
        ip         VARCHAR(60)   NOT NULL DEFAULT '',
        created_at DATETIME      NOT NULL,
        INDEX idx_event   (event),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS rxa_questions (
        id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id    VARCHAR(64)   NOT NULL DEFAULT '',
        name       VARCHAR(150)  NOT NULL DEFAULT '',
        pharmacy   VARCHAR(150)  NOT NULL DEFAULT '',
        email      VARCHAR(150)  NOT NULL DEFAULT '',
        phone      VARCHAR(60)   NOT NULL DEFAULT '',
        question   TEXT          NOT NULL,
        is_read    TINYINT(1)    NOT NULL DEFAULT 0,
        created_at DATETIME      NOT NULL,
        INDEX idx_created (created_at),
        INDEX idx_read (is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // ── Default settings ────────────────────────────────────
    $pdo->exec("INSERT IGNORE INTO rxa_settings(skey,sval) VALUES
        ('credentials', '{\"username\":\"admin\",\"password\":\"admin123\"}'),
        ('config',      '{}'),
        ('email_settings', '{\"alerts_enabled\":false,\"welcome_enabled\":false,\"method\":\"php_mail\",\"notify_user\":true,\"notify_admin\":false}')
    ");

    box(true, 'Installation Successful!',
        '<strong>Tables created / verified:</strong><br>
        &nbsp; 📋 <code>rxa_users</code> — pharmacies, subscriptions, license codes<br>
        &nbsp; ⚙️ <code>rxa_settings</code> — config, credentials, email, auth tokens<br>
        &nbsp; 📜 <code>rxa_logs</code> — full activity audit log<br><br>
        <strong>Default admin login:</strong> username <code>admin</code> — password <code>admin123</code><br>
        <em>Change this immediately after first login (Security page).</em><br><br>
        <strong>New columns added:</strong> username, password_hash, session_token, reset_token for pharmacy user login.<br><br>
        <strong style="color:#dc2626;font-size:16px">⚠️ DELETE this file (install.php) now — it has no auth protection!</strong>');

} catch (Exception $e) {
    box(false, 'Installation Failed',
        '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '<br><br>
        Check that <code>DB_NAME</code>, <code>DB_USER</code>, and <code>DB_PASS</code> are correct.');
}
