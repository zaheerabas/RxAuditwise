<?php
/**
 * RxAuditwise — Daily Cron Job v2.0
 * Run via cPanel Cron Jobs once daily: 0 8 * * *
 * Command: php /home/YOURUSERNAME/public_html/YOURFOLDER/cron.php >> /dev/null 2>&1
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'ximtwwsi_rx');  // ← same as api.php
define('DB_USER', 'ximtwwsi_rx');
define('DB_PASS', 'Rx@2141audit');

error_reporting(0);
ini_set('display_errors','0');
require_once __DIR__ . '/mailer.php';

function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    return $pdo;
}

function log_event($event, $detail = '', $actor = 'cron') {
    try { db()->prepare("INSERT INTO rxa_logs(event,detail,actor,ip,created_at) VALUES(?,?,?,?,NOW())")->execute([$event,$detail,$actor,'cron']); } catch(Exception $e){}
}

$cfg = mailerGetSettings();
if (empty($cfg['alerts_enabled'])) {
    echo date('[Y-m-d H:i:s]') . " Alerts disabled.\n"; exit;
}

// runAlerts is defined in api.php but we reimplement inline here for standalone use
$thresholds = [30, 15, 7, 3, 1, 0];
$today      = date('Y-m-d');
$adminEmail = $cfg['admin_notify_email'] ?? '';
$notifyAdmin= !empty($cfg['notify_admin']) && $adminEmail;
$notifyUser = !empty($cfg['notify_user']);
$cfgRow     = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
$adminContact = $cfgRow ? json_decode($cfgRow['sval'], true) : [];
$users = db()->query("SELECT id,name,pharmacy,email,end_date,alert_sent_flags FROM rxa_users WHERE active=1 AND end_date IS NOT NULL")->fetchAll();

$sent=0; $skipped=0; $errors=0;
foreach ($users as $u) {
    $endDt=new DateTime($u['end_date']); $nowDt=new DateTime($today);
    $diff=(int)$nowDt->diff($endDt)->days*($endDt>=$nowDt?1:-1);
    $flags=json_decode($u['alert_sent_flags']??'[]',true)?:[];
    foreach ($thresholds as $t) {
        if ($diff!==$t) continue;
        $key="d{$t}";
        if (in_array($key,$flags)){$skipped++;break;}
        if ($notifyUser && !empty($u['email'])) {
            $tpl=mailerBuildExpiryEmail($u,$t,$adminContact);
            $r=mailerSend($u['email'],$tpl['subject'],$tpl['html']);
            if($r['ok']){$sent++;log_event('email_sent',"Alert {$key} → {$u['email']}");}
            else{$errors++;log_event('email_failed',"Alert {$key} to {$u['email']}: ".$r['error']);}
        }
        if ($notifyAdmin && in_array($t,[7,3,1,0])) {
            $tpl=mailerBuildAdminExpiryEmail($u,$t,$adminEmail);
            $r=mailerSend($adminEmail,$tpl['subject'],$tpl['html']);
            if($r['ok'])$sent++; else $errors++;
        }
        $flags[]=$key;
        db()->prepare("UPDATE rxa_users SET alert_sent_flags=? WHERE id=?")->execute([json_encode(array_values(array_unique($flags))),$u['id']]);
        break;
    }
}
$summary="Cron done — sent:{$sent} skipped:{$skipped} errors:{$errors}";
log_event('cron_run',$summary);
echo date('[Y-m-d H:i:s]')." {$summary}\n";
