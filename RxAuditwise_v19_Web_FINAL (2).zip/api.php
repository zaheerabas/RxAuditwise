<?php
/**
 * RxAuditwise — API v5.1
 * Token-based auth (no PHP sessions needed).
 *
 * ── CHANGE THESE 3 LINES ──────────────────────────────────────
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'ximtwwsi_rx');   // ← cPanel DB name
define('DB_USER', 'ximtwwsi_rx');   // ← cPanel DB user
define('DB_PASS', 'Rx@2141audit'); // ← cPanel DB password
// ─────────────────────────────────────────────────────────────

// ── Suppress ALL PHP warnings/notices from reaching the browser.
// ── Any stray output would corrupt the JSON response.
error_reporting(0);
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ob_start(); // Buffer all output — prevents PHP warnings corrupting JSON
$_rxa_sent = false; // Track if we already sent a response via ok()/err()

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Auth-Token');
// Security headers — prevent clickjacking, MIME sniffing, XSS
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { if(ob_get_level()>0)ob_end_clean(); http_response_code(200); exit; }

// ── DB ────────────────────────────────────────────────────────
function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    } catch (Exception $e) {
        if (ob_get_level() > 0) ob_end_clean();
        http_response_code(500);
        echo json_encode(['ok'=>false,'error'=>'DB connection failed: '.$e->getMessage()]); exit;
    }
    return $pdo;
}

// ── Response helpers ──────────────────────────────────────────
function ok($d=[]) {
    global $_rxa_sent; $_rxa_sent = true;
    // Discard any stray PHP output (warnings etc) before sending clean JSON
    if (ob_get_level() > 0) ob_end_clean();
    echo json_encode(['ok'=>true]+$d);
    exit;
}
function err($m, $c=400) {
    global $_rxa_sent; $_rxa_sent = true;
    // Discard any stray PHP output before sending clean JSON
    if (ob_get_level() > 0) ob_end_clean();
    http_response_code($c);
    echo json_encode(['ok'=>false,'error'=>$m]);
    exit;
}
function body() {
    static $b=null;
    if ($b!==null) return $b;
    $b = json_decode(file_get_contents('php://input'), true) ?? [];
    return $b;
}
function ip() {
    return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '')[0]);
}

// ── Server-side rate limiting ─────────────────────────────────
// Tracks failed login attempts per IP in rxa_settings.
// After 10 failures → 15 minute lockout. Resets on success.
function checkRateLimit($type = 'login') {
    $key    = 'rl_' . $type . '_' . md5(ip());
    $window = 900; // 15 minutes in seconds
    $max    = 10;  // max attempts before lockout
    try {
        $row = db()->prepare("SELECT sval FROM rxa_settings WHERE skey=? LIMIT 1");
        $row->execute([$key]);
        $rec = $row->fetch();
        $data = $rec ? json_decode($rec['sval'], true) : null;
        $now  = time();
        // If window expired, reset
        if ($data && isset($data['until']) && $data['until'] < $now) {
            db()->prepare("DELETE FROM rxa_settings WHERE skey=?")->execute([$key]);
            $data = null;
        }
        if ($data && isset($data['count']) && $data['count'] >= $max) {
            $wait = max(0, $data['until'] - $now);
            err("Too many login attempts. Try again in " . ceil($wait/60) . " minute(s).", 429);
        }
    } catch(Exception $e) { /* DB unavailable — allow through */ }
}

function recordFailedAttempt($type = 'login') {
    $key    = 'rl_' . $type . '_' . md5(ip());
    $window = 900;
    $max    = 10;
    try {
        $row = db()->prepare("SELECT sval FROM rxa_settings WHERE skey=? LIMIT 1");
        $row->execute([$key]);
        $rec  = $row->fetch();
        $data = $rec ? json_decode($rec['sval'], true) : ['count'=>0,'until'=>time()+$window];
        $data['count']++;
        if ($data['count'] >= $max) $data['until'] = time() + $window;
        $json = json_encode($data);
        db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES(?,?) ON DUPLICATE KEY UPDATE sval=?")
           ->execute([$key,$json,$json]);
    } catch(Exception $e) {}
}

function clearRateLimit($type = 'login') {
    $key = 'rl_' . $type . '_' . md5(ip());
    try { db()->prepare("DELETE FROM rxa_settings WHERE skey=?")->execute([$key]); } catch(Exception $e) {}
}

// ── Token auth (replaces PHP sessions) ───────────────────────
// Token stored in rxa_settings as JSON: {token, username, expires}
function makeToken($username) {
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+8 hours'));
    $data    = json_encode(['token'=>$token,'username'=>$username,'expires'=>$expires]);
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('auth_token',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([$data, $data]);
    return $token;
}

function getAuthUsername() {
    // Token comes from header OR body (fallback)
    $token = $_SERVER['HTTP_X_AUTH_TOKEN']
          ?? $_SERVER['HTTP_X_AUTH_TOKEN']
          ?? body()['_token']
          ?? null;
    if (!$token) return null;
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='auth_token' LIMIT 1")->fetch();
    if (!$row) return null;
    $data = json_decode($row['sval'], true);
    if (!$data || $data['token'] !== $token) return null;
    if (strtotime($data['expires']) < time()) {
        // Expired — clean up
        db()->exec("DELETE FROM rxa_settings WHERE skey='auth_token'");
        return null;
    }
    // Refresh expiry on every valid request (sliding window)
    $data['expires'] = date('Y-m-d H:i:s', strtotime('+8 hours'));
    $json = json_encode($data);
    db()->prepare("UPDATE rxa_settings SET sval=? WHERE skey='auth_token'")->execute([$json]);
    return $data['username'];
}

// ── Logging ───────────────────────────────────────────────────
function log_event($event, $detail='', $actor=null) {
    try {
        $who = $actor ?? ($GLOBALS['_auth_user'] ?? 'system');
        db()->prepare("INSERT INTO rxa_logs(event,detail,actor,ip,created_at) VALUES(?,?,?,?,NOW())")
           ->execute([$event, $detail, $who, ip()]);
    } catch (Exception $e) {}
}

// Creates rxa_questions on first use if it doesn't already exist — this lets
// existing installations (which already ran install.php before this table
// existed) pick it up automatically without a manual migration step.
function ensureQuestionsTable() {
    db()->exec("CREATE TABLE IF NOT EXISTS rxa_questions (
        id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id    VARCHAR(64)   NOT NULL DEFAULT '',
        name       VARCHAR(150)  NOT NULL DEFAULT '',
        pharmacy   VARCHAR(150)  NOT NULL DEFAULT '',
        email      VARCHAR(150)  NOT NULL DEFAULT '',
        phone      VARCHAR(60)   NOT NULL DEFAULT '',
        question   TEXT          NOT NULL,
        is_read    TINYINT(1)    NOT NULL DEFAULT 0,
        created_at DATETIME      NOT NULL,
        INDEX idx_created (created_at),
        INDEX idx_read (is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// ── Route ─────────────────────────────────────────────────────
$action = $_GET['action'] ?? body()['action'] ?? '';

// ══════════════════════════════════════════════════════════════
//  PUBLIC ROUTES (no auth needed)
// ══════════════════════════════════════════════════════════════

if ($action === 'login') {
    $u = trim(body()['username'] ?? '');
    $p = body()['password'] ?? '';
    if (!$u || !$p) err('Username and password required');
    checkRateLimit('admin');
    $row   = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
    $creds = $row ? json_decode($row['sval'], true) : ['username'=>'admin','password'=>'admin123'];
    if ($u === $creds['username'] && $p === $creds['password']) {
        clearRateLimit('admin');
        $token = makeToken($u);
        log_event('login', "Admin logged in", $u);
        ok(['token'=>$token, 'username'=>$u]);
    } else {
        recordFailedAttempt('admin');
        log_event('login_failed', "Failed admin login: ".htmlspecialchars($u), 'anon');
        // Timing-safe: always sleep briefly to prevent timing attacks
        usleep(200000 + random_int(0, 100000));
        err('Invalid username or password', 401);
    }
}

if ($action === 'logout') {
    $who = getAuthUsername() ?? 'unknown';
    db()->exec("DELETE FROM rxa_settings WHERE skey='auth_token'");
    log_event('logout', "Admin logged out", $who);
    ok();
}

if ($action === 'get_users_public') {
    $rows = db()->query("SELECT id,name,pharmacy,codes,start_date,end_date,active FROM rxa_users")->fetchAll();
    $mapped = [];
    foreach ($rows as $r) {
        $mapped[] = [
            'id'        => $r['id'],
            'name'      => $r['name'],
            'pharmacy'  => $r['pharmacy'],
            'codes'     => json_decode($r['codes'], true) ?: [],
            'startDate' => $r['start_date'],
            'endDate'   => $r['end_date'],
            'active'    => (bool)$r['active'],
        ];
    }
    ok(['users' => $mapped]);
}

if ($action === 'get_config_public') {
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
    ok(['config' => $row ? json_decode($row['sval'], true) : []]);
}

if ($action === 'user_login') {
    $u = trim(body()['username'] ?? '');
    $p = body()['password'] ?? '';
    if (!$u || !$p) err('Username and password required');
    checkRateLimit('user');
    $row = db()->prepare("SELECT * FROM rxa_users WHERE username=? AND active=1 LIMIT 1");
    $row->execute([$u]);
    $user = $row->fetch();
    // Handle users with no password set yet (old records before upgrade)
    if (!$user) {
        log_event('user_login_failed', "Failed login (user not found): {$u}", 'anon');
        err('Invalid username or password', 401);
    }
    if (empty($user['password_hash'])) {
        log_event('user_login_failed', "Failed login (no password set): {$u}", 'anon');
        err('No password set for this account. Ask your administrator to set your password from the Users page.', 401);
    }
    if (!password_verify($p, $user['password_hash'])) {
        recordFailedAttempt('user');
        log_event('user_login_failed', "Failed login (wrong password): {$u}", 'anon');
        usleep(200000 + random_int(0, 100000));
        err('Invalid username or password', 401);
    }
    $today = date('Y-m-d');
    if ($user['end_date'] && $user['end_date'] < $today) {
        log_event('user_login_expired', "Expired login: {$u} ({$user['pharmacy']})", $u);
        err('Subscription expired on ' . date('M j, Y', strtotime($user['end_date'])) . '. Contact your administrator.', 403);
    }
    // Generate user session token (stored per-user, separate from admin)
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+12 hours'));
    db()->prepare("UPDATE rxa_users SET session_token=?,session_expires=?,updated_at=NOW() WHERE id=?")
       ->execute([$token, $expires, $user['id']]);
    // Fire login notifications if configured
    require_once __DIR__ . '/mailer.php';
    $emCfg = mailerGetSettings();
    // Always send admin login notification if admin email is configured
    mailerSendLoginAlertToAdmin($user, ip());
    // Trigger expiry alert check on login (no cron needed)
    runUserExpiryCheck($user, $emCfg);
    clearRateLimit('user');
    log_event('user_login', "User login: {$user['name']} ({$user['pharmacy']})", $u);
    ok([
        'token'    => $token,
        'userId'   => $user['id'],
        'username' => $user['username'],
        'name'     => $user['name'],
        'pharmacy' => $user['pharmacy'],
        'endDate'  => $user['end_date'],
        'active'   => (bool)$user['active'],
        'codes'    => json_decode($user['codes'], true) ?: [],
    ]);
}

if ($action === 'get_current_user') {
    // Called by main app to refresh session/codes
    $token = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? body()['_token'] ?? '';
    if (!$token) err('No token', 401);
    $row = db()->prepare("SELECT * FROM rxa_users WHERE session_token=? AND active=1 LIMIT 1");
    $row->execute([$token]);
    $user = $row->fetch();
    if (!$user) err('Session expired', 401);
    if ($user['session_expires'] && strtotime($user['session_expires']) < time()) err('Session expired', 401);
    // Slide expiry
    db()->prepare("UPDATE rxa_users SET session_expires=? WHERE id=?")->execute([date('Y-m-d H:i:s', strtotime('+12 hours')), $user['id']]);
    ok(['user' => [
        'userId'   => $user['id'],
        'username' => $user['username'],
        'name'     => $user['name'],
        'pharmacy' => $user['pharmacy'],
        'endDate'  => $user['end_date'],
        'active'   => (bool)$user['active'],
        'codes'    => json_decode($user['codes'], true) ?: [],
    ]]);
}

// User submits a question from the Help Center — notifies the admin (with a
// Reply-To set to the user's own email so the admin can just hit reply) and
// sends the user a confirmation that it was received.
if ($action === 'ask_admin_question') {
    $token = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? body()['_token'] ?? '';
    if (!$token) err('No token', 401);
    $row = db()->prepare("SELECT * FROM rxa_users WHERE session_token=? AND active=1 LIMIT 1");
    $row->execute([$token]);
    $user = $row->fetch();
    if (!$user) err('Session expired', 401);

    $question = trim(body()['question'] ?? '');
    if (!$question) err('Question is required');
    if (strlen($question) > 4000) err('Question is too long');

    // Always store the question so it's visible in the admin panel — this
    // must not depend on whether email is configured (email is best-effort).
    ensureQuestionsTable();
    db()->prepare("INSERT INTO rxa_questions(user_id,name,pharmacy,email,phone,question,is_read,created_at) VALUES(?,?,?,?,?,?,0,NOW())")
        ->execute([$user['id'], $user['name'], $user['pharmacy'], $user['email'] ?? '', $user['phone'] ?? '', $question]);
    log_event('user_question', "Question from {$user['name']} ({$user['pharmacy']})", $user['username']);

    require_once __DIR__ . '/mailer.php';
    $cfgRow = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
    $cfg = $cfgRow ? json_decode($cfgRow['sval'], true) : [];
    $adminEmail = $cfg['adminEmail'] ?? '';

    $sentToAdmin = false; $sentConfirmation = false;
    if ($adminEmail) {
        $toAdmin = mailerSendUserQuestionToAdmin($user, $question, $adminEmail);
        $sentToAdmin = !empty($toAdmin['ok']);
        if (!empty($user['email'])) {
            $toUser = mailerSendUserQuestionConfirmation($user, $question);
            $sentConfirmation = !empty($toUser['ok']);
        }
    }

    ok(['stored' => true, 'sentToAdmin' => $sentToAdmin, 'sentConfirmation' => $sentConfirmation]);
}

function runUserExpiryCheck($user, $cfg) {
    if (empty($cfg['notify_user']) && empty($cfg['notify_admin'])) return;
    $thresholds = [30, 15, 7, 3, 1, 0];
    $today  = date('Y-m-d');
    $endDt  = new DateTime($user['end_date'] ?? $today);
    $nowDt  = new DateTime($today);
    $diff   = (int)$nowDt->diff($endDt)->days * ($endDt >= $nowDt ? 1 : -1);
    $flags  = json_decode($user['alert_sent_flags'] ?? '[]', true) ?: [];
    foreach ($thresholds as $t) {
        if ($diff !== $t) continue;
        $key = "d{$t}";
        if (in_array($key, $flags)) break;
        $cfgRow = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
        $contact = $cfgRow ? json_decode($cfgRow['sval'], true) : [];
        if (!empty($cfg['notify_user']) && !empty($user['email'])) {
            $tpl = mailerBuildExpiryEmail($user, $t, $contact);
            if (!empty($tpl['subject'])) mailerSend($user['email'], $tpl['subject'], $tpl['html']);
        }
        if (!empty($cfg['notify_admin']) && !empty($cfg['admin_notify_email']) && in_array($t, [7,3,1,0])) {
            $tpl = mailerBuildAdminExpiryEmail($user, $t, $cfg['admin_notify_email']);
            if (!empty($tpl['subject'])) mailerSend($cfg['admin_notify_email'], $tpl['subject'], $tpl['html']);
        }
        $flags[] = $key;
        db()->prepare("UPDATE rxa_users SET alert_sent_flags=? WHERE id=?")
           ->execute([json_encode(array_values(array_unique($flags))), $user['id']]);
        break;
    }
}

// ══════════════════════════════════════════════════════════════
//  PASSWORD RESET — PHARMACY USERS
// ══════════════════════════════════════════════════════════════

if ($action === 'user_forgot_password') {
    $u     = trim(body()['username'] ?? '');
    $email = trim(body()['email']    ?? '');
    // Always return ok (don't reveal if account exists)
    if ($u && $email) {
        $row = db()->prepare("SELECT * FROM rxa_users WHERE username=? AND email=? AND active=1 LIMIT 1");
        $row->execute([$u, $email]);
        $user = $row->fetch();
        if ($user) {
            $token   = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            db()->prepare("UPDATE rxa_users SET reset_token=?,reset_token_expires=? WHERE id=?")
               ->execute([$token, $expires, $user['id']]);
            require_once __DIR__ . '/mailer.php';
            mailerSendUserReset($user, $token);
            log_event('user_password_reset_requested', "Reset requested for {$u}");
        }
    }
    ok(); // Always return ok
}

if ($action === 'user_reset_password') {
    $token = trim(body()['token']    ?? '');
    $pass  = body()['password']      ?? '';
    if (!$token) err('Invalid reset link');
    if (strlen($pass) < 6) err('Password must be at least 6 characters');
    $row = db()->prepare("SELECT * FROM rxa_users WHERE reset_token=? LIMIT 1");
    $row->execute([$token]);
    $user = $row->fetch();
    if (!$user) err('Reset link is invalid or already used');
    if ($user['reset_token_expires'] && strtotime($user['reset_token_expires']) < time()) err('Reset link has expired. Please request a new one.');
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    db()->prepare("UPDATE rxa_users SET password_hash=?,reset_token=NULL,reset_token_expires=NULL WHERE id=?")
       ->execute([$hash, $user['id']]);
    log_event('user_password_reset', "Password reset for {$user['username']}");
    ok();
}

// ══════════════════════════════════════════════════════════════
//  PASSWORD RESET — ADMIN
// ══════════════════════════════════════════════════════════════

if ($action === 'admin_forgot_password') {
    $u     = trim(body()['username'] ?? '');
    $email = trim(body()['email']    ?? '');
    if ($u && $email) {
        $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
        $creds = $row ? json_decode($row['sval'], true) : [];
        $cfgRow = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
        $cfg = $cfgRow ? json_decode($cfgRow['sval'], true) : [];
        if ($creds['username'] === $u && ($cfg['adminEmail'] ?? '') === $email) {
            $token   = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $tdata   = ['token'=>$token,'expires'=>$expires];
            db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('admin_reset',?) ON DUPLICATE KEY UPDATE sval=?")
               ->execute([json_encode($tdata), json_encode($tdata)]);
            require_once __DIR__ . '/mailer.php';
            mailerSendAdminReset($u, $email, $token);
            log_event('admin_password_reset_requested', "Admin reset for {$u}");
        }
    }
    ok();
}

if ($action === 'admin_reset_password') {
    $token = trim(body()['token']    ?? '');
    $pass  = body()['password']      ?? '';
    if (!$token) err('Invalid token');
    if (strlen($pass) < 6) err('Min 6 characters');
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='admin_reset' LIMIT 1")->fetch();
    if (!$row) err('Reset link is invalid or already used');
    $tdata = json_decode($row['sval'], true);
    if (!$tdata || $tdata['token'] !== $token) err('Invalid reset link');
    if (strtotime($tdata['expires']) < time()) err('Reset link expired. Request a new one.');
    $cRow = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
    $creds = $cRow ? json_decode($cRow['sval'], true) : ['username'=>'admin'];
    $creds['password'] = $pass;
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('credentials',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([json_encode($creds), json_encode($creds)]);
    db()->exec("DELETE FROM rxa_settings WHERE skey='admin_reset'");
    log_event('admin_password_reset', "Admin password changed via reset link");
    ok();
}

if ($action === 'get_ref_data') {
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='ref_data' LIMIT 1")->fetch();
    ok(['data' => $row ? json_decode($row['sval'], true) : new stdClass()]);
}


// ══════════════════════════════════════════════════════════════
//  AUTH GUARD
// ══════════════════════════════════════════════════════════════
$authUser = getAuthUsername();
if (!$authUser) err('Not authenticated', 401);
$GLOBALS['_auth_user'] = $authUser;

// ══════════════════════════════════════════════════════════════
//  USER QUESTIONS (from Help Center "Ask a question")
// ══════════════════════════════════════════════════════════════
if ($action === 'get_user_questions') {
    ensureQuestionsTable();
    $rows = db()->query("SELECT * FROM rxa_questions ORDER BY created_at DESC")->fetchAll();
    $unread = db()->query("SELECT COUNT(*) FROM rxa_questions WHERE is_read=0")->fetchColumn();
    ok(['questions' => $rows, 'unreadCount' => (int)$unread]);
}

if ($action === 'mark_question_read') {
    ensureQuestionsTable();
    $id = trim(body()['id'] ?? '');
    if (!$id) err('ID required');
    $read = !empty(body()['read']) ? 1 : 0;
    db()->prepare("UPDATE rxa_questions SET is_read=? WHERE id=?")->execute([$read, $id]);
    ok();
}

if ($action === 'delete_question') {
    ensureQuestionsTable();
    $id = trim(body()['id'] ?? '');
    if (!$id) err('ID required');
    db()->prepare("DELETE FROM rxa_questions WHERE id=?")->execute([$id]);
    log_event('question_deleted', "Deleted question #{$id}");
    ok();
}

// ══════════════════════════════════════════════════════════════
//  USERS
// ══════════════════════════════════════════════════════════════

if ($action === 'get_users') {
    $rows = db()->query("SELECT * FROM rxa_users ORDER BY created_at DESC")->fetchAll();
    $mapped = [];
    foreach ($rows as $r) {
        $mapped[] = [
            'id'        => $r['id'],
            'username'  => $r['username'] ?? '',
            'name'      => $r['name'],
            'pharmacy'  => $r['pharmacy'],
            'phone'     => $r['phone'],
            'email'     => $r['email'],
            'address'   => $r['address'],
            'notes'     => $r['notes'],
            'codes'     => json_decode($r['codes'], true) ?: [],
            'startDate' => $r['start_date'],
            'endDate'   => $r['end_date'],
            'active'    => (bool)$r['active'],
            'createdAt' => $r['created_at'],
            'updatedAt' => $r['updated_at'],
        ];
    }
    ok(['users' => $mapped]);
}

if ($action === 'save_user') {
    $b         = body();
    $id        = trim($b['id']       ?? '');
    $name      = trim($b['name']     ?? '');
    $pharmacy  = trim($b['pharmacy'] ?? '');
    $phone     = trim($b['phone']    ?? '');
    $email     = trim($b['email']    ?? '');
    $address   = trim($b['address']  ?? '');
    $notes     = trim($b['notes']    ?? '');
    $codes     = json_encode(array_values(array_filter(array_map('trim', $b['codes'] ?? []))));
    $startDate = $b['startDate'] ?? null;
    $endDate   = $b['endDate']   ?? null;
    $now       = date('Y-m-d H:i:s');

    if (!$name)      err('Name is required');
    if (!$pharmacy)  err('Pharmacy is required');
    if (!$startDate) err('Start date is required');
    if (!$endDate)   err('End date is required');

    // Username and password handling
    $username = strtolower(trim($b['username'] ?? ''));
    $password = $b['password'] ?? '';

    if (empty($id)) {
        // INSERT — username + password required for new users
        if (!$username) err('Username is required');
        // Check username not already taken
        $chk = db()->prepare("SELECT id FROM rxa_users WHERE username=? LIMIT 1");
        $chk->execute([$username]);
        if ($chk->fetch()) err('Username already taken — choose another');
        if (!$password) err('Password is required for new users');
        if (strlen($password) < 6) err('Password must be at least 6 characters');
        $passHash = password_hash($password, PASSWORD_DEFAULT);
        $id = bin2hex(random_bytes(8));
        db()->prepare("INSERT INTO rxa_users(id,username,password_hash,name,pharmacy,phone,email,address,notes,codes,start_date,end_date,active,alert_sent_flags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,'[]',?,?)")
           ->execute([$id,$username,$passHash,$name,$pharmacy,$phone,$email,$address,$notes,$codes,$startDate,$endDate,$now,$now]);
        log_event('user_added', "Added: {$name} ({$pharmacy}) @{$username} until {$endDate}");
        // Always send welcome email when admin creates a user (if they have an email)
        if (!empty($email)) {
            require_once __DIR__ . '/mailer.php';
            mailerSendWelcome([
                'id'         => $id,
                'name'       => $name,
                'pharmacy'   => $pharmacy,
                'email'      => $email,
                'phone'      => $phone,
                'codes'      => json_decode($codes, true) ?? [],
                'start_date' => $startDate,
                'end_date'   => $endDate,
            ]);
        }
        ok(['id'=>$id, 'new'=>true]);
    } else {
        // UPDATE
        $old = db()->prepare("SELECT end_date,username FROM rxa_users WHERE id=? LIMIT 1");
        $old->execute([$id]);
        $oldRow    = $old->fetch();
        $flagReset = ($oldRow && $oldRow['end_date'] !== $endDate) ? ", alert_sent_flags='[]'" : '';
        // Check username uniqueness (if changed)
        if ($username && $oldRow && $username !== $oldRow['username']) {
            $chk = db()->prepare("SELECT id FROM rxa_users WHERE username=? AND id!=? LIMIT 1");
            $chk->execute([$username, $id]);
            if ($chk->fetch()) err('Username already taken — choose another');
        }
        // Build update query dynamically (password optional)
        if ($password && strlen($password) >= 6) {
            $passHash = password_hash($password, PASSWORD_DEFAULT);
            $extraCols = $username ? ",username=?,password_hash=?" : ",password_hash=?";
            $extraVals = $username ? [$username,$passHash] : [$passHash];
        } elseif ($username) {
            $extraCols = ",username=?";
            $extraVals = [$username];
        } else {
            $extraCols = "";
            $extraVals = [];
        }
        $params = array_merge([$name,$pharmacy,$phone,$email,$address,$notes,$codes,$startDate,$endDate,$now], $extraVals, [$id]);
        db()->prepare("UPDATE rxa_users SET name=?,pharmacy=?,phone=?,email=?,address=?,notes=?,codes=?,start_date=?,end_date=?,active=1,updated_at=?{$extraCols}{$flagReset} WHERE id=?")
           ->execute($params);
        log_event('user_edited', "Edited: {$name} ({$pharmacy})" . ($flagReset ? ' [renewed]' : ''));
        ok(['id'=>$id, 'new'=>false]);
    }
}

if ($action === 'delete_user') {
    $id = trim(body()['id'] ?? '');
    if (!$id) err('ID required');
    $r = db()->prepare("SELECT name,pharmacy FROM rxa_users WHERE id=?");
    $r->execute([$id]);
    $u = $r->fetch();
    db()->prepare("DELETE FROM rxa_users WHERE id=?")->execute([$id]);
    log_event('user_deleted', "Deleted: " . ($u ? "{$u['name']} ({$u['pharmacy']})" : $id));
    ok();
}

// Toggles (or bulk-toggles) a user's active flag without touching any other field —
// save_user's UPDATE previously hardcoded active=1, so there was no way to suspend
// an account short of deleting it outright.
if ($action === 'toggle_user_active') {
    $b      = body();
    $ids    = $b['ids'] ?? (isset($b['id']) ? [$b['id']] : []);
    $ids    = array_values(array_filter(array_map('trim', is_array($ids) ? $ids : [$ids])));
    $active = !empty($b['active']) ? 1 : 0;
    if (!$ids) err('At least one user ID is required');
    $now = date('Y-m-d H:i:s');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("UPDATE rxa_users SET active=?, updated_at=? WHERE id IN ($placeholders)");
    $stmt->execute(array_merge([$active, $now], $ids));
    log_event($active ? 'user_activated' : 'user_deactivated', count($ids) . ' user(s): ' . implode(', ', $ids));
    ok(['updated' => count($ids)]);
}

// ══════════════════════════════════════════════════════════════
//  CONFIG
// ══════════════════════════════════════════════════════════════

if ($action === 'get_config') {
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
    ok(['config' => $row ? json_decode($row['sval'], true) : []]);
}

if ($action === 'save_config') {
    $cfg = body()['config'] ?? [];
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('config',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([json_encode($cfg), json_encode($cfg)]);
    log_event('config_saved', "Contact info updated");
    ok();
}

if ($action === 'change_password') {
    $cur = body()['current'] ?? '';
    $nw  = body()['new']     ?? '';
    if (strlen($nw) < 6) err('Minimum 6 characters');
    $row   = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
    $creds = $row ? json_decode($row['sval'], true) : ['username'=>'admin','password'=>'admin123'];
    if ($cur !== $creds['password']) err('Current password incorrect');
    $creds['password'] = $nw;
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('credentials',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([json_encode($creds), json_encode($creds)]);
    log_event('password_changed', "Password changed");
    ok();
}

if ($action === 'change_username') {
    $newU = trim(body()['username'] ?? '');
    $pw   = body()['password']      ?? '';
    if (!$newU) err('Username required');
    $row   = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
    $creds = $row ? json_decode($row['sval'], true) : ['username'=>'admin','password'=>'admin123'];
    if ($pw !== $creds['password']) err('Password incorrect');
    $old = $creds['username'];
    $creds['username'] = $newU;
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('credentials',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([json_encode($creds), json_encode($creds)]);
    // Update token's stored username too
    $trow = db()->query("SELECT sval FROM rxa_settings WHERE skey='auth_token' LIMIT 1")->fetch();
    if ($trow) {
        $tdata = json_decode($trow['sval'], true);
        if ($tdata) { $tdata['username'] = $newU; db()->prepare("UPDATE rxa_settings SET sval=? WHERE skey='auth_token'")->execute([json_encode($tdata)]); }
    }
    $GLOBALS['_auth_user'] = $newU;
    log_event('username_changed', "Username: '{$old}' → '{$newU}'", $newU);
    ok();
}

// ══════════════════════════════════════════════════════════════
//  EMAIL SETTINGS
// ══════════════════════════════════════════════════════════════

if ($action === 'get_email_settings') {
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='email_settings' LIMIT 1")->fetch();
    $cfg = $row ? json_decode($row['sval'], true) : [];
    if (!empty($cfg['smtp_pass'])) $cfg['smtp_pass'] = '••••••••';
    ok(['settings' => $cfg]);
}

if ($action === 'save_email_settings') {
    $new = body()['settings'] ?? [];
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='email_settings' LIMIT 1")->fetch();
    $existing = $row ? json_decode($row['sval'], true) : [];
    // Don't overwrite real password with placeholder
    if (isset($new['smtp_pass']) && strpos($new['smtp_pass'], '•') !== false) {
        $new['smtp_pass'] = $existing['smtp_pass'] ?? '';
    }
    $merged = array_merge($existing, $new);
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('email_settings',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([json_encode($merged), json_encode($merged)]);
    log_event('email_settings_saved', "Email settings updated");
    ok();
}

if ($action === 'send_test_email') {
    require_once __DIR__ . '/mailer.php';
    $to = trim(body()['to'] ?? '');
    if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) err('Valid email required');
    $cfg = mailerGetSettings();
    if (empty($cfg['from_email'])) err('Set sender email in Email Alerts settings first');
    $html = "<div style='font-family:sans-serif;padding:32px;max-width:500px'>
        <h2 style='color:#1e40af'>💊 RxAuditwise — Test Email</h2>
        <p style='color:#16a34a;font-size:15px'>✅ Your email configuration is working correctly!</p>
        <p style='color:#64748b;font-size:13px'>Sent: " . date('Y-m-d H:i:s') . " · Method: " . htmlspecialchars($cfg['method'] ?? 'php_mail') . "</p>
    </div>";
    $r = mailerSendTest($to);
    if ($r['ok']) {
        log_event('email_test_sent', "Test email sent to {$to}");
        ok(['message' => "Test email sent successfully to {$to}"]);
    } else {
        log_event('email_test_failed', "Test failed to {$to}: " . $r['error']);
        err('Send failed: ' . $r['error']);
    }
}

if ($action === 'run_alerts_now') {
    require_once __DIR__ . '/mailer.php';
    $cfg = mailerGetSettings();
    if (empty($cfg['alerts_enabled'])) err('Email alerts are disabled. Enable them in Email Alerts settings first.');
    list($sent, $skipped, $errors, $results) = runAlerts($cfg);
    log_event('alerts_manual_run', "Manual run — sent:{$sent} skipped:{$skipped} errors:{$errors}");
    ok(['sent'=>$sent, 'skipped'=>$skipped, 'errors'=>$errors, 'results'=>$results]);
}

function runAlerts($cfg) {
    $thresholds   = [30, 15, 7, 3, 1, 0];
    $today        = date('Y-m-d');
    $adminEmail   = $cfg['admin_notify_email'] ?? '';
    $notifyAdmin  = !empty($cfg['notify_admin']) && $adminEmail;
    $notifyUser   = !empty($cfg['notify_user']);
    $cfgRow       = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
    $adminContact = $cfgRow ? json_decode($cfgRow['sval'], true) : [];
    $users        = db()->query("SELECT id,name,pharmacy,email,end_date,alert_sent_flags FROM rxa_users WHERE active=1 AND end_date IS NOT NULL")->fetchAll();
    $sent=0; $skipped=0; $errors=0; $results=[];
    foreach ($users as $u) {
        $endDt = new DateTime($u['end_date']);
        $nowDt = new DateTime($today);
        $diff  = (int)$nowDt->diff($endDt)->days * ($endDt >= $nowDt ? 1 : -1);
        $flags = json_decode($u['alert_sent_flags'] ?? '[]', true) ?: [];
        foreach ($thresholds as $t) {
            if ($diff !== $t) continue;
            $key = "d{$t}";
            if (in_array($key, $flags)) { $skipped++; break; }
            if ($notifyUser && !empty($u['email'])) {
                $tpl = mailerBuildExpiryEmail($u, $t, $adminContact);
            if (empty($tpl['subject'])) continue;
                $r   = mailerSend($u['email'], $tpl['subject'], $tpl['html']);
                if ($r['ok']) { $sent++; $results[] = "✅ {$u['name']} ({$u['pharmacy']}) → {$u['email']}"; }
                else          { $errors++; $results[] = "❌ {$u['email']}: " . $r['error']; log_event('email_failed', "Alert {$key}: " . $r['error']); }
            }
            if ($notifyAdmin && in_array($t, [7,3,1,0]) && $adminEmail) {
                $tpl = mailerBuildAdminExpiryEmail($u, $t, $adminEmail);
                $r   = mailerSend($adminEmail, $tpl['subject'], $tpl['html']);
                if ($r['ok']) $sent++; else $errors++;
            }
            $flags[] = $key;
            db()->prepare("UPDATE rxa_users SET alert_sent_flags=? WHERE id=?")
               ->execute([json_encode(array_values(array_unique($flags))), $u['id']]);
            break;
        }
    }
    return [$sent, $skipped, $errors, $results];
}

// ══════════════════════════════════════════════════════════════
//  COMPOSE EMAIL
// ══════════════════════════════════════════════════════════════

if ($action === 'send_compose') {
    require_once __DIR__ . '/mailer.php';
    $cfg = mailerGetSettings();
    if (empty($cfg['from_email'])) err('Configure email settings (From Email) first');
    $subject = trim(body()['subject'] ?? '');
    $message = trim(body()['message'] ?? '');
    $targets = body()['targets'] ?? [];
    if (!$subject) err('Subject is required');
    if (!$message) err('Message body is required');
    if (empty($targets)) err('No recipients selected');

    $today = date('Y-m-d');
    $rows  = db()->query("SELECT id,name,pharmacy,email,end_date,active FROM rxa_users WHERE email IS NOT NULL AND email != ''")->fetchAll();
    $recipients = [];
    foreach ($rows as $r) {
        if (!in_array($r['id'], (array)$targets)) continue;
        $recipients[] = $r;
    }
    if (!$recipients) err('No matching recipients with email addresses');

    $cfgRow  = db()->query("SELECT sval FROM rxa_settings WHERE skey='config' LIMIT 1")->fetch();
    $contact = $cfgRow ? json_decode($cfgRow['sval'], true) : [];
    $org     = htmlspecialchars($contact['adminOrg'] ?? 'RxAuditwise');
    $sent=0; $failed=0; $failList=[];

    foreach ($recipients as $rec) {
        $name     = htmlspecialchars($rec['name']);
        $pharm    = htmlspecialchars($rec['pharmacy']);
        $msgHtml  = nl2br(htmlspecialchars($message));
        $html = <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;padding:32px 16px">
<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
<table width="560" style="max-width:560px;width:100%">
  <tr><td style="background:#1e40af;border-radius:14px 14px 0 0;padding:24px 32px">
    <div style="color:#fff;font-size:22px;font-weight:700">💊 {$org}</div>
  </td></tr>
  <tr><td style="background:#fff;padding:28px 32px 24px">
    <p style="color:#475569;font-size:15px;margin:0 0 16px">Dear <strong>{$name}</strong> ({$pharm}),</p>
    <div style="color:#0f172a;font-size:15px;line-height:1.8">{$msgHtml}</div>
  </td></tr>
  <tr><td style="background:#f8fafc;border-top:1px solid #e2e8f0;border-radius:0 0 14px 14px;padding:14px 32px;text-align:center">
    <div style="font-size:12px;color:#94a3b8">{$org} · RxAuditwise</div>
  </td></tr>
</table>
</td></tr></table>
</body></html>
HTML;
        $r = mailerSend($rec['email'], $subject, $html);
        if ($r['ok']) $sent++;
        else { $failed++; $failList[] = $rec['email'] . ': ' . $r['error']; }
    }
    log_event('email_compose_sent', "'{$subject}' → sent:{$sent} failed:{$failed}");
    ok(['sent'=>$sent, 'failed'=>$failed, 'total'=>count($recipients), 'errors'=>$failList]);
}

// ══════════════════════════════════════════════════════════════
//  BACKUP / RESTORE
// ══════════════════════════════════════════════════════════════

if ($action === 'log_export') {
    log_event('backup_exported', "Backup JSON downloaded");
    ok();
}

if ($action === 'restore_backup') {
    $users  = body()['users']  ?? [];
    $config = body()['config'] ?? [];
    $db  = db();
    $db->exec("DELETE FROM rxa_users");
    $now = date('Y-m-d H:i:s');
    foreach ($users as $u) {
        $uid = $u['id'] ?? bin2hex(random_bytes(8));
        $db->prepare("INSERT INTO rxa_users(id,name,pharmacy,phone,email,address,notes,codes,start_date,end_date,active,alert_sent_flags,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$uid, $u['name']??'', $u['pharmacy']??'', $u['phone']??'', $u['email']??'',
               $u['address']??'', $u['notes']??'',
               json_encode(is_array($u['codes']) ? $u['codes'] : []),
               $u['startDate']??null, $u['endDate']??null,
               ($u['active']??true) ? 1 : 0,
               $u['alert_sent_flags'] ?? '[]',
               $u['createdAt'] ?? $now, $now]);
    }
    $db->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('config',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([json_encode($config), json_encode($config)]);
    log_event('backup_restored', "Restored " . count($users) . " users");
    ok(['restored' => count($users)]);
}

// ══════════════════════════════════════════════════════════════
//  LOGS
// ══════════════════════════════════════════════════════════════

if ($action === 'get_logs') {
    $limit  = min((int)(body()['limit']  ?? 50), 500);
    $offset = max((int)(body()['offset'] ?? 0), 0);
    $filter = trim(body()['filter'] ?? '');
    $search = trim(body()['search'] ?? '');
    $where=[]; $params=[];
    if ($filter && $filter !== 'all') { $where[] = 'event=?'; $params[] = $filter; }
    if ($search) { $where[] = '(detail LIKE ? OR actor LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
    $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    $db = db();
    // Get count first, store result before executing next statement
    $ct = $db->prepare("SELECT COUNT(*) FROM rxa_logs $w");
    $ct->execute($params);
    $total = (int)$ct->fetchColumn();
    $ct = null; // free statement
    // Get rows
    // NOTE: LIMIT/OFFSET must be bound as PDO::PARAM_INT explicitly — passing them
    // through execute([...]) binds everything as strings, and MySQL rejects a
    // quoted string for LIMIT/OFFSET (this was causing the HTTP 500 on this page).
    $rows = $db->prepare("SELECT id,event,detail,actor,ip,created_at FROM rxa_logs $w ORDER BY created_at DESC LIMIT ? OFFSET ?");
    $i = 1;
    foreach ($params as $p) { $rows->bindValue($i++, $p); }
    $rows->bindValue($i++, $limit,  PDO::PARAM_INT);
    $rows->bindValue($i++, $offset, PDO::PARAM_INT);
    $rows->execute();
    ok(['logs' => $rows->fetchAll(), 'total' => $total]);
}

if ($action === 'clear_logs') {
    $pw  = body()['password'] ?? '';
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
    $c   = $row ? json_decode($row['sval'], true) : ['password'=>'admin123'];
    if ($pw !== $c['password']) err('Password incorrect');
    db()->exec("DELETE FROM rxa_logs");
    log_event('logs_cleared', "All logs cleared");
    ok();
}

// ══════════════════════════════════════════════════════════════
//  FACTORY RESET
// ══════════════════════════════════════════════════════════════

if ($action === 'factory_reset') {
    $pw  = body()['password'] ?? '';
    $row = db()->query("SELECT sval FROM rxa_settings WHERE skey='credentials' LIMIT 1")->fetch();
    $c   = $row ? json_decode($row['sval'], true) : ['password'=>'admin123'];
    if ($pw !== $c['password']) err('Password incorrect');
    log_event('factory_reset', "Factory reset performed — all data erased");
    db()->exec("DELETE FROM rxa_users");
    db()->exec("DELETE FROM rxa_settings");
    db()->exec("DELETE FROM rxa_logs");
    ok();
}


// ══════════════════════════════════════════════════════════════
//  PHARMACY USER LOGIN (for the main app, separate from admin)
// ══════════════════════════════════════════════════════════════







if ($action === 'admin_send_reset') {
    $userId = trim(body()['userId'] ?? '');
    $email  = trim(body()['email']  ?? '');
    if (!$userId || !$email) err('User ID and email required');
    $row = db()->prepare("SELECT * FROM rxa_users WHERE id=? LIMIT 1");
    $row->execute([$userId]);
    $user = $row->fetch();
    if (!$user) err('User not found');
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
    db()->prepare("UPDATE rxa_users SET reset_token=?,reset_token_expires=? WHERE id=?")
       ->execute([$token, $expires, $userId]);
    require_once __DIR__ . '/mailer.php';
    mailerSendUserReset($user, $token);
    log_event('admin_sent_reset', "Admin sent password reset to {$email} for {$user['name']}");
    ok();
}

// ══════════════════════════════════════════════════════════════
//  REFERENCE DATA (MFP NDCs / BIN→Insurer / Non-NABP)
// ══════════════════════════════════════════════════════════════


if ($action === 'save_ref_data') {
    $data = body()['data'] ?? [];
    $json = json_encode($data);
    db()->prepare("INSERT INTO rxa_settings(skey,sval) VALUES('ref_data',?) ON DUPLICATE KEY UPDATE sval=?")
       ->execute([$json, $json]);
    log_event('ref_data_saved', "Reference data (MFP/BIN/NABP) updated");
    ok();
}

// ══════════════════════════════════════════════════════════════
//  BACKUP INFO
// ══════════════════════════════════════════════════════════════

if ($action === 'backup_info') {
    $userCount = (int)db()->query("SELECT COUNT(*) FROM rxa_users")->fetchColumn();
    $logCount  = (int)db()->query("SELECT COUNT(*) FROM rxa_logs")->fetchColumn();
    $lastLog   = db()->query("SELECT created_at FROM rxa_logs ORDER BY created_at DESC LIMIT 1")->fetchColumn();
    ok(['userCount'=>$userCount, 'logCount'=>$logCount, 'lastLog'=>$lastLog]);
}


err('Unknown action');
