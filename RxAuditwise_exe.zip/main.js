/**
 * RxAuditwise — Electron Main Process v4.0
 * ─────────────────────────────────────────
 * CHANGE THESE before building:
 */
const SERVER_URL  = 'https://software.rxauditwise.com';
const SUPPORT_EMAIL  = 'info@rxauditwise.com';
const SUPPORT_PHONE  = '+1 (800) 000-0000';
const SUPPORT_ADDR   = 'RxAuditwise LLC';
// ─────────────────────────────────────────

const {
    app, BrowserWindow, Menu, shell,
    ipcMain, dialog, globalShortcut, nativeImage
} = require('electron');
const path = require('path');

// ── Single instance ───────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); }

let mainWindow  = null;
let splashWindow = null;

// ════════════════════════════════════════════════════════════════
//  SPLASH SCREEN
// ════════════════════════════════════════════════════════════════
function createSplash() {
    splashWindow = new BrowserWindow({
        width:  480,
        height: 300,
        frame:        false,       // no title bar
        transparent:  false,
        resizable:    false,
        center:       true,
        alwaysOnTop:  true,
        skipTaskbar:  true,
        icon: path.join(__dirname, 'src', 'icon.ico'),
        backgroundColor: '#ffffff',
        webPreferences: { nodeIntegration: false, contextIsolation: true }
    });

    // Build inline splash HTML — no external files needed
    const splashHTML = `<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: #fff;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    overflow: hidden;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    user-select: none;
  }
  .icon-wrap {
    width: 72px; height: 72px;
    background: linear-gradient(135deg, #6d28d9, #7c3aed);
    border-radius: 20px;
    display: flex; align-items: center; justify-content: center;
    font-size: 36px;
    margin-bottom: 18px;
    box-shadow: 0 8px 24px rgba(109,40,217,.3);
    animation: pop .4s cubic-bezier(.34,1.56,.64,1);
  }
  @keyframes pop {
    from { transform: scale(.6); opacity:0; }
    to   { transform: scale(1);  opacity:1; }
  }
  .title {
    font-size: 22px; font-weight: 800; color: #0f172a; letter-spacing: -.3px;
  }
  .title span { color: #7c3aed; }
  .sub {
    font-size: 12px; color: #94a3b8; margin-top: 4px; margin-bottom: 28px;
  }
  .progress-wrap {
    width: 240px; height: 3px; background: #e2e8f0; border-radius: 99px; overflow: hidden;
  }
  .progress-bar {
    height: 100%; background: linear-gradient(90deg, #6d28d9, #2563eb);
    border-radius: 99px;
    animation: load 1.8s ease-in-out forwards;
  }
  @keyframes load {
    0%   { width: 0%; }
    30%  { width: 40%; }
    60%  { width: 70%; }
    85%  { width: 88%; }
    100% { width: 100%; }
  }
  .status {
    font-size: 11px; color: #94a3b8; margin-top: 10px;
    animation: fade 1s ease-in-out infinite alternate;
  }
  @keyframes fade { from { opacity:.5; } to { opacity:1; } }
  .version {
    position: absolute; bottom: 14px; right: 16px;
    font-size: 10px; color: #cbd5e1; font-weight: 600;
  }
  .copy {
    position: absolute; bottom: 14px; left: 16px;
    font-size: 10px; color: #cbd5e1;
  }
</style></head>
<body>
  <div class="icon-wrap">💊</div>
  <div class="title">NDC <span>Viewer</span></div>
  <div class="sub">Pharmacy Purchase Reconciliation</div>
  <div class="progress-wrap"><div class="progress-bar"></div></div>
  <div class="status" id="status">Loading MFP data…</div>
  <div class="version">v${app.getVersion()}</div>
  <div class="copy">Local only · No internet required</div>
<script>
  const msgs = ['Loading MFP data…','Initializing engine…','Preparing workspace…','Almost ready…'];
  let i = 0;
  setInterval(() => { i=(i+1)%msgs.length; document.getElementById('status').textContent=msgs[i]; }, 600);
</script>
</body></html>`;

    splashWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(splashHTML));
    splashWindow.once('ready-to-show', () => splashWindow.show());
}

// ════════════════════════════════════════════════════════════════
//  MAIN WINDOW
// ════════════════════════════════════════════════════════════════
function createWindow() {
    mainWindow = new BrowserWindow({
        width:       1400,
        height:      860,
        minWidth:    980,
        minHeight:   640,
        title:       'RxAuditwise — NDC Viewer',
        icon:        path.join(__dirname, 'src', 'icon.ico'),
        backgroundColor: '#f1f5f9',
        show:        false,   // shown after splash
        webPreferences: {
            preload:          path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration:  false,
            webSecurity:      true,
        },
    });

    mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

    // When main window is ready: close splash and show app
    mainWindow.once('ready-to-show', () => {
        setTimeout(() => {
            if (splashWindow && !splashWindow.isDestroyed()) {
                splashWindow.close();
                splashWindow = null;
            }
            mainWindow.show();
            mainWindow.focus();
        }, 1800); // minimum splash display time
    });

    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        shell.openExternal(url);
        return { action: 'deny' };
    });

    mainWindow.on('closed', () => { mainWindow = null; });
}

// ════════════════════════════════════════════════════════════════
//  MENU
// ════════════════════════════════════════════════════════════════
function buildMenu() {
    const isMac = process.platform === 'darwin';

    const send = (channel, ...args) => {
        if (mainWindow) mainWindow.webContents.send(channel, ...args);
    };

    const template = [
        // ── macOS app menu ──────────────────────────────────────
        ...(isMac ? [{ label: app.name, submenu: [
            { role: 'about' }, { type: 'separator' }, { role: 'quit' }
        ]}] : []),

        // ── File ────────────────────────────────────────────────
        {
            label: 'File',
            submenu: [
                {
                    label: 'New / Upload Files',
                    accelerator: 'CmdOrCtrl+N',
                    click: () => send('menu-action', 'new-files')
                },
                {
                    label: 'Open Supplier File…',
                    accelerator: 'CmdOrCtrl+O',
                    click: async () => {
                        if (!mainWindow) return;
                        const r = await dialog.showOpenDialog(mainWindow, {
                            title: 'Select Supplier File(s)',
                            properties: ['openFile','multiSelections'],
                            filters: [{ name: 'Data Files', extensions: ['csv','xlsx','xls'] }]
                        });
                        if (!r.canceled) send('menu-action', 'open-supplier', r.filePaths);
                    }
                },
                {
                    label: 'Open Billing File…',
                    accelerator: 'CmdOrCtrl+B',
                    click: async () => {
                        if (!mainWindow) return;
                        const r = await dialog.showOpenDialog(mainWindow, {
                            title: 'Select Billing File',
                            properties: ['openFile'],
                            filters: [{ name: 'Data Files', extensions: ['csv','xlsx','xls'] }]
                        });
                        if (!r.canceled) send('menu-action', 'open-billing', r.filePaths);
                    }
                },
                { type: 'separator' },
                {
                    label: 'Run Reconciliation',
                    accelerator: 'CmdOrCtrl+Enter',
                    click: () => send('menu-action', 'run-reconciliation')
                },
                { type: 'separator' },
                {
                    label: 'Export Current Tab…',
                    accelerator: 'CmdOrCtrl+E',
                    click: () => send('menu-action', 'export')
                },
                { type: 'separator' },
                {
                    label: 'Reload App',
                    accelerator: 'CmdOrCtrl+R',
                    click: () => mainWindow && mainWindow.reload()
                },
                { type: 'separator' },
                isMac
                    ? { role: 'close' }
                    : { label: 'Exit', accelerator: 'Alt+F4', click: () => app.quit() }
            ]
        },

        // ── Edit ────────────────────────────────────────────────
        {
            label: 'Edit',
            submenu: [
                { role: 'copy',        accelerator: 'CmdOrCtrl+C' },
                { role: 'selectAll',   accelerator: 'CmdOrCtrl+A' },
                { type: 'separator' },
                {
                    label: 'Find / Search',
                    accelerator: 'CmdOrCtrl+F',
                    click: () => send('menu-action', 'focus-search')
                },
                {
                    label: 'Clear Search',
                    accelerator: 'Escape',
                    click: () => send('menu-action', 'clear-search')
                },
                { type: 'separator' },
                {
                    label: 'Reset All Filters',
                    accelerator: 'CmdOrCtrl+Shift+R',
                    click: () => send('menu-action', 'reset-filters')
                }
            ]
        },

        // ── View ────────────────────────────────────────────────
        {
            label: 'View',
            submenu: [
                // Tab navigation
                { label: 'Tab: Preview (Raw)',        accelerator: 'F1',  click: () => send('menu-action','switch-tab','raw') },
                { label: 'Tab: Combined Suppliers',   accelerator: 'F2',  click: () => send('menu-action','switch-tab','suppliers') },
                { label: 'Tab: Results',              accelerator: 'F3',  click: () => send('menu-action','switch-tab','results') },
                { label: 'Tab: MFP',                  accelerator: 'F4',  click: () => send('menu-action','switch-tab','mfp') },
                { label: 'Tab: Final',                accelerator: 'F5',  click: () => send('menu-action','switch-tab','final') },
                { label: 'Tab: Bill',                 accelerator: 'F6',  click: () => send('menu-action','switch-tab','bill') },
                { label: 'Tab: Discarded',            accelerator: 'F7',  click: () => send('menu-action','switch-tab','discarded') },
                { label: 'Tab: Not Billed',           accelerator: 'F8',  click: () => send('menu-action','switch-tab','notbilled') },
                { label: 'Tab: Issues',               accelerator: 'F9',  click: () => send('menu-action','switch-tab','issues') },
                { type: 'separator' },
                // Zoom
                { label: 'Zoom In',    accelerator: 'CmdOrCtrl+=',
                  click: () => { if (!mainWindow) return; mainWindow.webContents.setZoomFactor(Math.min(mainWindow.webContents.getZoomFactor()+0.1, 3.0)); }
                },
                { label: 'Zoom Out',   accelerator: 'CmdOrCtrl+-',
                  click: () => { if (!mainWindow) return; mainWindow.webContents.setZoomFactor(Math.max(mainWindow.webContents.getZoomFactor()-0.1, 0.3)); }
                },
                { label: 'Reset Zoom', accelerator: 'CmdOrCtrl+0',
                  click: () => mainWindow && mainWindow.webContents.setZoomFactor(1.0)
                },
                { type: 'separator' },
                { label: 'Toggle Full Screen', accelerator: isMac ? 'Ctrl+Cmd+F' : 'F11',
                  click: () => mainWindow && mainWindow.setFullScreen(!mainWindow.isFullScreen())
                },
                { label: 'Toggle Maximize', accelerator: 'CmdOrCtrl+M',
                  click: () => { if (!mainWindow) return; mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize(); }
                },
                { type: 'separator' },
                { label: 'Toggle Developer Tools', accelerator: isMac ? 'Alt+Cmd+I' : 'Ctrl+Shift+I',
                  click: () => mainWindow && mainWindow.webContents.toggleDevTools()
                }
            ]
        },

        // ── Help ────────────────────────────────────────────────
        {
            label: 'Help',
            submenu: [
                {
                    label: '🌐 Visit Website',
                    click: () => shell.openExternal(SERVER_URL)
                },
                {
                    label: '✉️  Email Support',
                    click: () => shell.openExternal(`mailto:${SUPPORT_EMAIL}?subject=RxAuditwise Support`)
                },
                { type: 'separator' },
                {
                    label: '📋 Keyboard Shortcuts',
                    accelerator: 'CmdOrCtrl+/',
                    click: () => {
                        dialog.showMessageBox(mainWindow, {
                            type:    'info',
                            title:   'Keyboard Shortcuts',
                            message: 'RxAuditwise — Keyboard Shortcuts',
                            detail:
`──── Navigation ────
F1          Preview (Raw) tab
F2          Combined Suppliers tab
F3          Results tab
F4          MFP tab
F5          Final tab
F6          Bill tab
F7          Discarded tab
F8          Not Billed tab
F9          Issues tab

──── File ────
Ctrl+N      New / Upload Files
Ctrl+O      Open Supplier File
Ctrl+B      Open Billing File
Ctrl+Enter  Run Reconciliation
Ctrl+E      Export current tab

──── Edit ────
Ctrl+F      Search / Find
Ctrl+Shift+R  Reset all filters
Ctrl+C      Copy selected cell

──── View ────
Ctrl+=      Zoom In
Ctrl+-      Zoom Out
Ctrl+0      Reset Zoom
F11         Full Screen
Ctrl+M      Maximize window`,
                            buttons: ['Close'],
                        });
                    }
                },
                { type: 'separator' },
                {
                    label: '📞 Contact Information',
                    click: () => {
                        dialog.showMessageBox(mainWindow, {
                            type:    'info',
                            title:   'Contact RxAuditwise',
                            message: 'RxAuditwise Support',
                            detail:
`Email:    ${SUPPORT_EMAIL}
Phone:    ${SUPPORT_PHONE}
Address:  ${SUPPORT_ADDR}
Website:  ${SERVER_URL}

For technical support, billing questions,
or subscription renewals — contact us at
any of the above.`,
                            buttons: ['OK', 'Open Website', 'Send Email'],
                        }).then(({ response }) => {
                            if (response === 1) shell.openExternal(SERVER_URL);
                            if (response === 2) shell.openExternal(`mailto:${SUPPORT_EMAIL}`);
                        });
                    }
                },
                { type: 'separator' },
                {
                    label: 'About RxAuditwise',
                    click: () => {
                        dialog.showMessageBox(mainWindow, {
                            type:    'info',
                            title:   'About RxAuditwise',
                            message: 'RxAuditwise — NDC Viewer',
                            detail:
`Version:   ${app.getVersion()}
Platform:  ${process.platform} ${process.arch}

Pharmacy Purchase Reconciliation
Runs locally — no internet required for core features

© 2026 RxAuditwise
${SERVER_URL}`,
                            buttons: ['OK'],
                            icon:    path.join(__dirname, 'src', 'icon.ico'),
                        });
                    }
                }
            ]
        }
    ];

    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ════════════════════════════════════════════════════════════════
//  IPC HANDLERS
// ════════════════════════════════════════════════════════════════
ipcMain.handle('open-file-dialog', async (event, opts = {}) => {
    return dialog.showOpenDialog(mainWindow, {
        title:      opts.title || 'Select Data Files',
        properties: ['openFile', 'multiSelections'],
        filters:    [
            { name: 'Data Files', extensions: ['csv','xlsx','xls'] },
            { name: 'All Files',  extensions: ['*'] }
        ]
    });
});

ipcMain.handle('get-app-version', () => app.getVersion());

// ════════════════════════════════════════════════════════════════
//  APP LIFECYCLE
// ════════════════════════════════════════════════════════════════
app.whenReady().then(() => {
    buildMenu();
    createSplash();   // show splash first
    createWindow();   // load main app in background

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('second-instance', () => {
    if (mainWindow) {
        if (mainWindow.isMinimized()) mainWindow.restore();
        mainWindow.focus();
    }
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});
