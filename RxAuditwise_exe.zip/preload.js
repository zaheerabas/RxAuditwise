/**
 * RxAuditwise — Preload Script v4.0
 * Bridges main process menu actions to the renderer
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    // File dialogs
    openFileDialog: (opts) => ipcRenderer.invoke('open-file-dialog', opts),
    getAppVersion:  ()     => ipcRenderer.invoke('get-app-version'),

    // Listen for menu actions sent from main process
    onMenuAction: (callback) => {
        ipcRenderer.on('menu-action', (event, action, ...args) => callback(action, ...args));
    },

    platform:   process.platform,
    isElectron: true,
});
