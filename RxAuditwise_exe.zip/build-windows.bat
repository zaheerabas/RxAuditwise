@echo off
title RxAuditwise Builder
color 0A
echo.
echo  ==========================================
echo   RxAuditwise - Windows .EXE Builder
echo  ==========================================
echo.

:: ── Step 1: Check Node.js ─────────────────────────────────────
node --version >nul 2>&1
if %errorlevel% neq 0 (
    color 0C
    echo  ERROR: Node.js not found!
    echo.
    echo  Please install Node.js from:
    echo  https://nodejs.org  (choose LTS version)
    echo.
    pause
    exit /b 1
)

echo  [OK] Node.js found: 
node --version
echo.

:: ── Step 2: Install dependencies ──────────────────────────────
echo  [1/3] Installing build tools (takes 2-5 minutes first time)...
echo        Please wait...
echo.
call npm install --prefer-offline 2>nul
if %errorlevel% neq 0 (
    echo  Trying with npm cache...
    call npm install
    if %errorlevel% neq 0 (
        color 0C
        echo.
        echo  ERROR: npm install failed.
        echo  Make sure you have internet connection.
        pause
        exit /b 1
    )
)

echo.
echo  [OK] Dependencies installed.
echo.

:: ── Step 3: Build ─────────────────────────────────────────────
echo  [2/3] Building Windows installer...
echo        This takes 3-8 minutes, please wait...
echo.
call npm run build
if %errorlevel% neq 0 (
    color 0C
    echo.
    echo  ERROR: Build failed. See error above.
    pause
    exit /b 1
)

:: ── Done ──────────────────────────────────────────────────────
echo.
echo  [3/3] SUCCESS!
echo.
color 0B
echo  ==========================================
echo   Build Complete!
echo  ==========================================
echo.
echo  Files created in the  dist\  folder:
echo.
dir /b dist\*.exe 2>nul
echo.
echo  - RxAuditwise Setup x.x.x.exe  = Installer (share this with users)
echo  - RxAuditwise-Portable-x.x.x.exe = No install needed version
echo.
echo  Opening dist folder...
start "" dist
echo.
pause
