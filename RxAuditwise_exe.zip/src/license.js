// ════════════════════════════════════════════════════════════
//  RxAuditwise — License / Subscription System  v3.1 (DB)
//
//  UPDATED: 
//  - Reads users from MySQL via api.php (not localStorage)
//  - SMART matching: code found if ANY cell CONTAINS the code
//    (handles "2052029843-NILEEXPRESSPHARMACYINC" style cells)
// ════════════════════════════════════════════════════════════

const LIC_API = 'https://software.rxauditwise.com/api.php';

const LIC_DEFAULT_CONTACT = {
    adminName:  'RxAuditwise Support',
    adminEmail: 'admin@rxauditwise.com',
    adminPhone: '+1 (800) 000-0000',
    adminOrg:   'RxAuditwise'
};

function licNorm(code) {
    return String(code).trim().toUpperCase().replace(/\s+/g, '');
}
function licTodayStr() {
    return new Date().toISOString().slice(0, 10);
}
function licEsc(s) {
    return String(s)
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Fetch users from server ───────────────────────────────────────────────────
async function licFetchUsers() {
    try {
        const r = await fetch(LIC_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'get_users_public' })
        });
        const j = await r.json();
        if (j.ok && j.users) return j.users;
    } catch (e) {
        console.warn('[RxAuditwise lic] API fetch failed:', e);
    }
    return [];
}

async function licFetchContact() {
    try {
        const r = await fetch(LIC_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'get_config_public' })
        });
        const j = await r.json();
        if (j.ok && j.config) return { ...LIC_DEFAULT_CONTACT, ...j.config };
    } catch (e) {}
    return { ...LIC_DEFAULT_CONTACT };
}

// ── Build active users list (non-expired only) ────────────────────────────────
function licGetActiveUsers(users) {
    const today = licTodayStr();
    return users.filter(u => {
        if (!u.active) return false;
        if (u.endDate && u.endDate < today) return false;
        return true;
    });
}

// ── Parse a File → 2-D rows array ────────────────────────────────────────────
function licReadFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const wb  = XLSX.read(new Uint8Array(e.target.result), { type: 'array' });
                const all = [];
                for (const name of wb.SheetNames) {
                    const rows = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: '' });
                    all.push(...rows);
                }
                resolve(all);
            } catch (err) { reject(err); }
        };
        reader.onerror = () => reject(new Error('Could not read: ' + file.name));
        reader.readAsArrayBuffer(file);
    });
}

// ── Extract all cell strings from 2-D row array ───────────────────────────────
function licCells(rows) {
    const out = new Set();
    for (const row of rows) {
        if (!Array.isArray(row)) continue;
        for (const cell of row) {
            const s = licNorm(String(cell == null ? '' : cell));
            if (s.length >= 3) out.add(s);
        }
    }
    return out;
}

// ── SMART code match: exact OR cell contains the code ─────────────────────────
// Handles cases like cell="2052029843-NILEEXPRESSPHARMACYINC" and code="2052029843"
function licCodeInCells(code, cells) {
    const n = licNorm(code);
    if (cells.has(n)) return true;                         // exact match
    for (const cell of cells) {
        if (cell.includes(n)) return true;                 // cell contains code
    }
    return false;
}

// ── Collect ALL cells from a list of files ────────────────────────────────────
async function licAllCells(fileList, singleFile) {
    const combined = new Set();
    for (const f of (fileList || [])) {
        try { licCells(await licReadFile(f)).forEach(c => combined.add(c)); } catch(e) {}
    }
    if (singleFile) {
        try { licCells(await licReadFile(singleFile)).forEach(c => combined.add(c)); } catch(e) {}
    }
    return combined;
}

// ── Main gate check ───────────────────────────────────────────────────────────
async function licCheckFiles(supplierFileList, billingFileObj) {
    const users       = await licFetchUsers();
    const activeUsers = licGetActiveUsers(users);

    if (!activeUsers.length) {
        return { allowed: false, user: null, reason: 'no_match' };
    }

    // Collect all cells from uploaded files
    const allCells = await licAllCells(supplierFileList, billingFileObj);

    // Check active users first
    for (const u of activeUsers) {
        for (const code of (u.codes || [])) {
            if (code && licCodeInCells(code, allCells)) {
                return { allowed: true, user: u, reason: 'matched' };
            }
        }
    }

    // Check expired users (to show better error message)
    const today = licTodayStr();
    for (const u of users) {
        if (!u.endDate || u.endDate >= today) continue;
        for (const code of (u.codes || [])) {
            if (code && licCodeInCells(code, allCells)) {
                return { allowed: false, user: u, reason: 'expired' };
            }
        }
    }

    return { allowed: false, user: null, reason: 'no_match' };
}

// ── Show gate overlay ─────────────────────────────────────────────────────────
async function licShowGate(result) {
    const contact = await licFetchContact();
    const name    = contact.adminName  || LIC_DEFAULT_CONTACT.adminName;
    const org     = contact.adminOrg   || LIC_DEFAULT_CONTACT.adminOrg;
    const email   = contact.adminEmail || LIC_DEFAULT_CONTACT.adminEmail;
    const phone   = contact.adminPhone || LIC_DEFAULT_CONTACT.adminPhone;

    const reason  = result && result.reason;
    const expUser = result && result.user;

    let icon, title, msg;
    if (reason === 'expired' && expUser) {
        icon  = '⏰';
        title = 'Subscription Expired';
        msg   = `Your subscription for <strong>${licEsc(expUser.pharmacy || expUser.name)}</strong> expired on <strong>${licFmtDate(expUser.endDate)}</strong>.<br>Please contact your administrator to renew.`;
    } else {
        icon  = '🔒';
        title = 'Subscription Required';
        msg   = `Your data files do not contain a registered license code.<br>Please contact your administrator to activate your subscription.`;
    }

    const old = document.getElementById('lic-gate-overlay');
    if (old) old.remove();

    const div = document.createElement('div');
    div.id    = 'lic-gate-overlay';
    div.innerHTML = `
        <div class="lic-gate-box">
            <div class="lic-gate-icon">${icon}</div>
            <div class="lic-gate-title">${title}</div>
            <div class="lic-gate-msg">${msg}</div>
            <div class="lic-gate-card">
                <div class="lic-gate-org">${licEsc(org)}</div>
                <div class="lic-cr"><span class="lic-ico">👤</span><span>${licEsc(name)}</span></div>
                <div class="lic-cr"><span class="lic-ico">✉️</span><a href="mailto:${licEsc(email)}">${licEsc(email)}</a></div>
                <div class="lic-cr"><span class="lic-ico">📞</span><span>${licEsc(phone)}</span></div>
            </div>
            <div class="lic-gate-note">
                Once the admin ${reason === 'expired' ? 'renews your subscription' : 'registers your license code'}, upload your files again.
            </div>
            <button class="lic-gate-btn" onclick="document.getElementById('lic-gate-overlay').remove()">← Try Again</button>
        </div>`;
    document.body.appendChild(div);
}

function licFmtDate(d) {
    if (!d) return '—';
    const [y, m, da] = d.split('-');
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return `${months[+m - 1]} ${+da}, ${y}`;
}

(function licCSS() {
    if (document.getElementById('lic-gate-css')) return;
    const s = document.createElement('style');
    s.id = 'lic-gate-css';
    s.textContent = `
        #lic-gate-overlay {
            position:fixed;inset:0;z-index:99999;
            background:rgba(15,23,42,.84);backdrop-filter:blur(7px);
            display:flex;align-items:center;justify-content:center;padding:20px;
            animation:licIn .22s ease;
        }
        @keyframes licIn { from{opacity:0;transform:scale(.96)} to{opacity:1;transform:scale(1)} }
        .lic-gate-box {
            background:#fff;border-radius:20px;padding:44px 40px 36px;
            max-width:460px;width:100%;text-align:center;
            box-shadow:0 28px 72px rgba(0,0,0,.3);
        }
        .lic-gate-icon  { font-size:52px;margin-bottom:12px; }
        .lic-gate-title { font-size:1.45rem;font-weight:700;color:#1e293b;margin-bottom:10px; }
        .lic-gate-msg   { font-size:.92rem;color:#475569;line-height:1.65;margin-bottom:22px; }
        .lic-gate-card  {
            background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:14px;
            padding:18px 22px;text-align:left;margin-bottom:18px;
        }
        .lic-gate-org { font-size:1rem;font-weight:700;color:#0f172a;margin-bottom:10px; }
        .lic-cr { display:flex;align-items:center;gap:10px;font-size:.88rem;color:#334155;margin-bottom:7px; }
        .lic-cr:last-child { margin-bottom:0; }
        .lic-ico { font-size:1rem;width:22px;flex-shrink:0; }
        .lic-cr a { color:#2563eb;text-decoration:none; }
        .lic-cr a:hover { text-decoration:underline; }
        .lic-gate-note { font-size:.79rem;color:#94a3b8;margin-bottom:24px;line-height:1.5; }
        .lic-gate-btn  {
            background:#1e40af;color:#fff;border:none;border-radius:10px;
            padding:12px 30px;font-size:.95rem;font-weight:600;cursor:pointer;
            transition:background .18s;
        }
        .lic-gate-btn:hover { background:#1d3a9e; }
    `;
    document.head.appendChild(s);
}());
