// ════════════════════════════════════
//  PKG DIVIDE — shared state & helpers
// ════════════════════════════════════

let pkgDivideOn = false;

function togglePkgDivide() {
    pkgDivideOn = !pkgDivideOn;

    // Sync ALL ÷PKG buttons (Results + MFP tabs)
    document.querySelectorAll('.pkg-toggle-btn').forEach(btn => {
        btn.classList.toggle('pkg-toggle-active', pkgDivideOn);
    });

    if (pkgDivideOn) {
        document.getElementById('th-rxq').innerHTML  = 'FILLED QTY <span class="pkg-div-badge">÷PKG</span>';
        document.getElementById('th-pq').innerHTML   = 'PURCHASED QTY <span class="pkg-div-badge">÷PKG</span>';
        document.getElementById('th-diff').innerHTML = 'RECONCILIATION <span class="pkg-div-badge">÷PKG</span>';
        document.getElementById('th-stat').innerHTML = 'STATUS <span class="pkg-div-badge">÷PKG</span>';
    } else {
        document.getElementById('th-rxq').textContent  = 'FILLED QTY';
        document.getElementById('th-pq').textContent   = 'PURCHASED QTY';
        document.getElementById('th-diff').textContent = 'RECONCILIATION';
        document.getElementById('th-stat').textContent = 'STATUS';
    }

    // Re-render all tabs that support ÷PKG
    renderTable();
    const mfpTab   = document.getElementById('tab-mfp');
    const finalTab = document.getElementById('tab-final');
    const issTab   = document.getElementById('tab-issues');
    if (mfpTab   && mfpTab.style.display    === 'flex')   renderMFP();
    if (finalTab && finalTab.classList.contains('active')) renderFinalTab();
    if (issTab   && issTab.classList.contains('active'))   renderIssuesTab();
}

// Divide value by pkg, return formatted string
function divByPkg(val, pkg) {
    if (!pkg || pkg === 0) return val != null ? fmt(val) : '—';
    const result = val / pkg;
    return result % 1 === 0 ? result.toFixed(0) : result.toFixed(2);
}

// Build status HTML — always shows amount, ÷PKG when active
function statusHtmlFn(d, pkg) {
    if (pkgDivideOn && pkg > 0) {
        // Divide the diff by pkg size and show result
        const dPkg  = d / pkg;
        const abs   = Math.abs(dPkg);
        const absStr = abs % 1 === 0 ? abs.toFixed(1) : abs.toFixed(2);
        if (d === 0)  return `<span class="st-ok">OK - (0.0)</span>`;
        if (d > 0)    return `<span class="st-over">OVER - (${absStr})</span>`;
        return         `<span class="st-short">SHORT - (${absStr})</span>`;
    }
    // Normal mode — show original amounts
    const abs = Math.abs(d).toFixed(1);
    if (d === 0)  return `<span class="st-ok">OK - (0.0)</span>`;
    if (d > 0)    return `<span class="st-over">OVER - (${abs})</span>`;
    return         `<span class="st-short">SHORT - (${abs})</span>`;
}

// Build diff/reconciliation cell HTML — normal or ÷PKG mode
// SHORT: show only the number (no "SHORT" text) in red
function diffHtmlFn(d, pkg) {
    if (pkgDivideOn && pkg > 0) {
        const dPkg = d / pkg;
        if (dPkg > 0)   return `<span class="di-over">✔</span>`;
        if (dPkg === 0) return `<span class="di-ok">✔</span>`;
        const abs = Math.abs(dPkg);
        const str = abs % 1 === 0 ? abs.toFixed(0) : abs.toFixed(2);
        return `<span class="di-short">-(${str})</span>`;
    }
    if (d > 0)   return `<span class="di-over">✔</span>`;
    if (d === 0) return `<span class="di-ok">✔</span>`;
    return `<span class="di-short">-(${fmt(Math.abs(d))})</span>`;
}

// Format a qty value — normal or ÷PKG
function qtyDisp(val, pkg) {
    if (pkgDivideOn && pkg > 0) return `<span class="pkg-div-val">${divByPkg(val, pkg)}</span>`;
    return fmt(val);
}

// ════════════════════════════════════
//  RESULTS TAB
// ════════════════════════════════════

function renderAll() {
    buildAllRows();
    populateFilters();
    applyFilters();
    renderSummary();
}

function buildAllRows() {
    allRows = [];
    for (const grp of ndcGroups) {
        for (const ins of grp.insurerRows) {
            allRows.push({ type: 'detail', description: grp.description, drgName: grp.drgName, strong: grp.strong, form: grp.form, ndc: grp.ndc, packageSize: grp.packageSize, insName: ins.insName, binNo: ins.binNo, rxQty: ins.qty, purchaseQty: grp.totalPurchaseQty, diff: grp.totalPurchaseQty - ins.qty, status: grp.status, brand: grp.brand, drugForm: grp.drugForm, isHL: ins.qty === grp.maxQty, ndcGroup: grp });
        }
        allRows.push({ type: 'total', description: grp.description, drgName: grp.drgName, strong: grp.strong, form: grp.form, ndc: grp.ndc, packageSize: '', insName: '', binNo: '', rxQty: grp.totalRxQty, purchaseQty: grp.totalPurchaseQty, diff: grp.diff, status: grp.status, brand: grp.brand, drugForm: grp.drugForm, isHL: false, ndcGroup: grp });
    }
}

function normalizeInsName(name) {
    // Title-case: first letter of each word capitalised, rest lowercase
    if (!name) return name;
    return name.trim().toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

function populateFilters() {
    // Collect raw insurer names, normalize case for dedup, keep canonical form
    const rawIns = allRows.filter(r => r.type === 'detail').map(r => r.insName).filter(Boolean);
    // Dedup case-insensitively: keep first encountered capitalisation for display
    const insMap = new Map();
    for (const name of rawIns) {
        const key = name.trim().toLowerCase();
        if (!insMap.has(key)) insMap.set(key, normalizeInsName(name));
    }
    const ins = [...insMap.values()].sort((a, b) => a.localeCompare(b));

    const frm = [...new Set(allRows.filter(r => r.type === 'detail').map(r => r.drugForm).filter(Boolean))].sort();
    document.getElementById('ins-filter').innerHTML = '<option>All Insurers</option>' + ins.map(i => `<option value="${i.toLowerCase()}">${i}</option>`).join('');
    document.getElementById('form-filter').innerHTML = '<option>All Drug Forms</option>' + frm.map(f => `<option>${f}</option>`).join('');

    // Show/hide brand filter based on whether any brand data exists
    const hasBrand = allRows.some(r => r.brand && r.brand.trim());
    const brandEl = document.getElementById('brand-filter');
    if (brandEl) brandEl.style.display = hasBrand ? '' : 'none';
}

function applyFilters() {
    const insF    = document.getElementById('ins-filter').value;      // lowercase key
    const frmF    = document.getElementById('form-filter').value;
    const brF     = document.getElementById('brand-filter').value;
    const srch    = document.getElementById('search-box').value.toLowerCase();
    const filterIns = insF !== 'All Insurers';
    const match = new Set();
    for (const g of ndcGroups) {
        if (activeFilter !== 'all' && g.status !== activeFilter) continue;
        // Case-insensitive insurer match
        if (filterIns && !g.insurerRows.some(r => (r.insName || '').trim().toLowerCase() === insF)) continue;
        if (frmF !== 'All Drug Forms' && g.drugForm !== frmF) continue;
        if (brF === 'Brand: Y' && g.brand !== 'Y') continue;
        if (brF === 'Brand: N' && g.brand !== 'N') continue;
        if (srch && !g.description.toLowerCase().includes(srch) && !g.ndc.includes(srch)) continue;
        match.add(g.ndc);
    }
    filteredRows = allRows.filter(r => {
        if (!match.has(r.ndc)) return false;
        if (filterIns) {
            if (r.type === 'total') return false;
            if (r.type === 'detail' && (r.insName || '').trim().toLowerCase() !== insF) return false;
        }
        return true;
    });
    renderTable();
    document.getElementById('ndc-count-label').textContent = `Showing: ${match.size} NDCs`;
}

function renderTable() {
    const tbody = document.getElementById('table-body');
    const srch  = document.getElementById('search-box').value.toLowerCase();
    if (!filteredRows.length) {
        tbody.innerHTML = `<tr><td colspan="10" class="empty-state">No records match the current filters.</td></tr>`;
        return;
    }
    const frag = document.createDocumentFragment();
    let sr = 0, curNDC = null;
    for (const row of filteredRows) {
        if (row.ndc !== curNDC) { curNDC = row.ndc; sr = 1; } else sr++;
        const tr  = document.createElement('tr');
        // For total rows: packageSize is '' (empty) so fall back to ndcGroup.packageSize
        const pkg = parseFloat(row.packageSize) > 0
            ? parseFloat(row.packageSize)
            : parseFloat(row.ndcGroup && row.ndcGroup.packageSize || 0);

        if (row.type === 'total') {
            tr.className = `row-total status-${row.status}`;
            tr.innerHTML =
                `<td class="sr-cell">${sr}</td>`
              + `<td class="col-desc">${descCellHtml(row.drgName || row.description, row.strong, row.form, srch)}</td>`
              + `<td class="ndc-plain" onclick="copyText('${row.ndc}')">${row.ndc}</td>`
              + `<td></td><td></td><td></td>`
              + `<td class="qty-cell">${qtyDisp(row.rxQty, pkg)}</td>`
              + `<td class="qty-cell">${qtyDisp(row.purchaseQty, pkg)}</td>`
              + `<td></td>`
              + `<td>${statusHtmlFn(row.diff, pkg)}</td>`;
        } else {
            tr.className = 'row-detail';
            const h = row.isHL;
            tr.innerHTML =
                `<td class="sr-cell">${sr}</td>`
              + `<td class="col-desc">${descCellHtml(row.drgName || row.description, row.strong, row.form, srch)}</td>`
              + `<td class="ndc-plain" onclick="copyText('${row.ndc}')">${row.ndc}</td>`
              + `<td class="qty-cell">${row.packageSize ? row.packageSize.toFixed(3) : ''}</td>`
              + `<td class="${h ? 'hl-ins' : ''}">${srch ? hlText(escHtml(row.insName), srch) : escHtml(row.insName)}</td>`
              + `<td class="${h ? 'hl-bin' : ''}" style="white-space:nowrap">${row.binNo}</td>`
              + `<td class="qty-cell${h ? ' hl-qty' : ''}">${qtyDisp(row.rxQty, pkg)}</td>`
              + `<td class="qty-cell">${qtyDisp(row.purchaseQty, pkg)}</td>`
              + `<td class="diff-cell">${diffHtmlFn(row.diff, pkg)}</td>`
              + `<td></td>`;
        }
        frag.appendChild(tr);
    }
    tbody.innerHTML = '';
    tbody.appendChild(frag);
}

function renderSummary() {
    const ok = ndcGroups.filter(g => g.status === 'ok').length;
    const ov = ndcGroups.filter(g => g.status === 'over').length;
    const sh = ndcGroups.filter(g => g.status === 'short').length;
    document.getElementById('summary-bar').innerHTML = `<div class="summary-pill"><div class="pill-dot ok"></div><span>OK: <strong class="pill-count">${ok}</strong></span></div><div class="summary-pill"><div class="pill-dot over"></div><span>Over: <strong class="pill-count">${ov}</strong></span></div><div class="summary-pill"><div class="pill-dot short"></div><span>Short: <strong class="pill-count">${sh}</strong></span></div><div class="summary-pill" style="margin-left:8px;color:var(--text-muted)">Total NDCs: <strong>${ndcGroups.length}</strong></div>`;
    document.getElementById('ndc-count-label').textContent = `Showing: ${ndcGroups.length} NDCs`;
}

function setFilter(s, btn) {
    activeFilter = s;
    document.querySelectorAll('#status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    applyFilters();
}

function sortBy(field) {
    if (sortCol === field) sortDir *= -1; else { sortCol = field; sortDir = 1; }
    ndcGroups.sort((a, b) => { const av = a[field], bv = b[field]; if (typeof av === 'string') return sortDir * av.localeCompare(bv); return sortDir * ((av || 0) - (bv || 0)); });
    buildAllRows();
    applyFilters();
}

function resetResultsFilters() {
    activeFilter = 'all';
    document.querySelectorAll('#status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('#status-filters .filter-btn.all').classList.add('active');
    document.getElementById('ins-filter').value = 'All Insurers';
    document.getElementById('form-filter').value = 'All Drug Forms';
    const bf = document.getElementById('brand-filter');
    if (bf) bf.selectedIndex = 0;
    document.getElementById('search-box').value = '';
    applyFilters();
}

// ════════════════════════════════════
//  RAW PREVIEW TAB
// ════════════════════════════════════

function rawGlobalSearchFn(v) { rawGlobalSearch = v; renderRawPreview(); }

function renderRawPreview() {
    const container = document.getElementById('raw-content');
    if (!rawPreviewData.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">📄</div><span>No raw data available.</span></div>`; return; }
    let html = '';
    rawPreviewData.forEach((fd, idx) => {
        const bid   = 'raw_' + idx;
        const short = fd.fileName.length > 50 ? fd.fileName.slice(0, 47) + '…' : fd.fileName;
        const descI = fd.mappingIdx && fd.mappingIdx.desc >= 0 ? fd.mappingIdx.desc : 0;
        fd.rows = [...fd.rows].sort((a, b) => { const av = (a[descI] || '').toLowerCase(), bv = (b[descI] || '').toLowerCase(); return av.localeCompare(bv); });
        const isCol     = rawCollapsed[bid] || false;
        const sheetPart = fd.sheetName ? `<span class="raw-hitem"><span class="raw-hkey">Sheet:</span><span class="raw-hval">${escHtml(fd.sheetName)}</span></span>` : '';
        const perSearch = rawSearchTerms[bid] || '';
        html += `<div class="raw-block" id="${bid}"><div class="raw-header"><div class="raw-header-left"><span class="raw-hitem"><span class="raw-hkey">File:</span><span class="raw-hval filename" title="${escHtml(fd.fileName)}">${escHtml(short)}</span></span>${sheetPart}<span class="raw-hitem"><span class="raw-hkey">Header@row:</span><span class="raw-hval">${fd.headerRow}</span></span><span class="raw-hitem"><span class="raw-hkey">Total rows:</span><span class="raw-hval">${fd.totalRows.toLocaleString()}</span></span></div><div class="raw-header-right"><input class="raw-search" id="rs_${bid}" placeholder="Search this file..." value="${escHtml(perSearch)}" oninput="rawSearch('${bid}',this.value)"><button class="raw-btn" onclick="exportRawCSV(${idx})">Export CSV</button><div class="raw-collapse-btn" onclick="toggleRawCollapse('${bid}')">${isCol ? '+' : '−'}</div></div></div><div class="raw-table-wrap${isCol ? ' ' : ''}">`;
        if (!isCol) {
            html += `<table class="raw-table"><thead><tr><th style="width:42px;text-align:center">#</th>${fd.headers.map(h => `<th>${escHtml(h)}</th>`).join('')}</tr></thead><tbody>`;
            const terms = [rawGlobalSearch, perSearch].map(t => t.trim().toLowerCase()).filter(Boolean);
            for (let i = 0; i < fd.rows.length; i++) {
                const cells   = fd.rows[i];
                const rowText = cells.join(' ').toLowerCase();
                if (terms.some(t => t && !rowText.includes(t))) continue;
                html += `<tr><td style="text-align:center;color:var(--text-muted);font-size:10.5px">${i + 1}</td>`;
                for (let j = 0; j < fd.headers.length; j++) { const cellVal = escHtml(cells[j] || ''); const highlighted = terms.reduce((s, t) => t ? hlText(s, t) : s, cellVal); html += `<td title="${cellVal}">${highlighted}</td>`; }
                html += `</tr>`;
            }
            html += `</tbody></table>`;
            if (fd.mappingIdx) { const m = fd.mappingIdx; const parts = []; if (m.ndc >= 0) parts.push(`"ndc":${m.ndc}`); if (m.qty >= 0) parts.push(`"qty":${m.qty}`); if (m.desc >= 0) parts.push(`"desc":${m.desc}`); if (m.size >= 0) parts.push(`"size":${m.size}`); if (m.ins >= 0) parts.push(`"ins":${m.ins}`); if (m.bin >= 0) parts.push(`"bin":${m.bin}`); if (parts.length) html += `<div class="raw-mapping">Mapping: {${parts.join(',')}}</div>`; }
            if (fd.totalRows > fd.rows.length) html += `<div class="raw-more">Showing first ${fd.rows.length.toLocaleString()} of ${fd.totalRows.toLocaleString()} rows.</div>`;
        }
        html += `</div></div>`;
    });
    container.innerHTML = html;
}

function rawSearch(bid, val) {
    rawSearchTerms[bid] = val; renderRawPreview();
    const el = document.getElementById('rs_' + bid); if (el) { el.focus(); el.setSelectionRange(val.length, val.length); }
}

function toggleRawCollapse(bid) { rawCollapsed[bid] = !rawCollapsed[bid]; renderRawPreview(); }

function exportRawCSV(idx) {
    const fd = rawPreviewData[idx]; if (!fd) return;
    const rows = [fd.headers.join(',')];
    for (const r of fd.rows) rows.push(r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(','));
    const a = document.createElement('a');
    a.href     = URL.createObjectURL(new Blob([rows.join('\n')], { type: 'text/csv' }));
    a.download = fd.fileName.replace(/[^a-zA-Z0-9_.-]/g, '_') + '_preview.csv';
    a.click();
}
