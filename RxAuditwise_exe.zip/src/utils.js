// ════════════════════════════════════
//  APPLICATION STATE
// ════════════════════════════════════
let supplierFiles = [], billingFile = null;
let purchaseMap = {};
let supTransactions = {};
let supFileTotals = {};
let billingRows = [];
let ndcGroups = [], allRows = [], filteredRows = [];
let activeFilter = 'all', sortCol = 'description', sortDir = 1;
let rawPreviewData = [];
let mfpActiveYear = 'all', mfpActiveStatus = 'all';
let supSearch = '', supSortCol = 'desc', supSortDir = 1;
let rawSearchTerms = {}, rawCollapsed = {}, rawGlobalSearch = '';
let finalSearch = '', finalSortCol = 'description', finalSortDir = 1, finalStatusFilter = 'all';
let nbSearch = '', nbSortCol = 'desc', nbSortDir = 1;
let billSearch = '', billSortCol = 'totalRxQty', billSortDir = -1;
let discSearch = '', discSortCol = 'desc', discSortDir = 1;
let issSearch = '', issSortCol = 'shortAmt', issSortDir = 1;

// ════════════════════════════════════
//  UTILITY FUNCTIONS
// ════════════════════════════════════

function buildDesc(name, strong, form) {
    const parts = [name, strong, form].map(s => (s || '').trim().toUpperCase()).filter(Boolean);
    return parts.join(' - ');
}

function descCellHtml(name, strong, form, searchTerm) {
    const nameU = (name || '').trim().toUpperCase();
    const parts = [nameU, (strong || '').trim().toUpperCase(), (form || '').trim().toUpperCase()].filter(Boolean);
    const fullDesc = parts.join(' - ');
    const hl = v => searchTerm ? hlText(escHtml(v), searchTerm) : escHtml(v);
    return `<div class="desc-single-line">${hl(fullDesc)}</div>`;
}

function resolveInsName(raw, bin) {
    return (bin && BIN_TO_INSURER[bin]) ? BIN_TO_INSURER[bin] : (raw || '');
}

function matchCol(hdrs, f) {
    for (const p of PATTERNS[f] || []) {
        const i = hdrs.findIndex(h => p.test(h));
        if (i >= 0) return i;
    }
    return -1;
}

function cleanNDC(raw) {
    if (!raw) return '';
    let s = String(raw).replace(/[^0-9]/g, '').trim();
    if (s.length > 0 && s.length < 11) s = s.padStart(11, '0');
    return s;
}

function normBIN(v) {
    if (!v) return '';
    let s = String(v).replace(/[^0-9]/g, '').trim();
    if (!s) return '';
    if (s.length > 6) s = s.slice(-6);
    if (s.length < 6) s = s.padStart(6, '0');
    return s;
}

function stripF(v) {
    return v == null ? '' : String(v).replace(/^="?|"?$/g, '').trim();
}

function escHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function parseSize(s) {
    if (s == null || s === '' || s === undefined) return 1;
    const str = String(s).trim().toUpperCase();
    if (!str) return 1;
    const mx = str.match(/^(\d+(?:\.\d+)?)\s*X\s*(\d+(?:\.\d+)?)/i);
    if (mx) return parseFloat(mx[1]) * parseFloat(mx[2]);
    const mn = str.match(/^(\d+(?:\.\d+)?)/);
    if (mn) return parseFloat(mn[1]);
    return 1;
}

function fmt(n, dec = 0) {
    if (n === undefined || n === null || n === '') return '';
    const x = parseFloat(n);
    if (isNaN(x)) return n;
    if (dec > 0) return x.toFixed(dec);
    return x.toLocaleString();
}

function hlText(s, term) {
    if (!term) return s;
    const esc = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return s.replace(new RegExp('(' + esc + ')', 'gi'), '<mark style="background:#fef08a;color:#78350f;border-radius:2px;padding:0 1px">$1</mark>');
}

function csvLine(line) {
    const r = [];
    let cur = '', q = false;
    for (const c of line) {
        if (c === '"') { q = !q; }
        else if (c === ',' && !q) { r.push(cur); cur = ''; }
        else cur += c;
    }
    r.push(cur);
    return r;
}

function copyText(t) {
    navigator.clipboard.writeText(t).catch(() => {});
}

function tick() {
    return new Promise(r => setTimeout(r, 10));
}

function showProg(show, msg, pct) {
    document.getElementById('progress-bar').style.display = show ? 'block' : 'none';
    document.getElementById('progress-label').style.display = show ? 'block' : 'none';
    document.getElementById('progress-label').textContent = msg;
    document.getElementById('progress-fill').style.width = pct + '%';
}

function checkReady() {
    document.getElementById('process-btn').classList.toggle('ready', supplierFiles.length > 0 && !!billingFile);
}

function showApp() {
    document.getElementById('upload-screen').style.display = 'none';
    document.getElementById('app-screen').style.display = 'flex';
    document.getElementById('tab-results').style.display = 'flex';
}

function resetApp() {
    purchaseMap = {}; supTransactions = {}; supFileTotals = {}; billingRows = [];
    ndcGroups = []; allRows = []; filteredRows = []; rawPreviewData = [];
    supplierFiles = []; billingFile = null;
    activeFilter = 'all'; sortCol = 'description'; sortDir = 1;
    mfpActiveYear = 'all'; mfpActiveStatus = 'all';
    supSearch = ''; supSortCol = 'desc'; supSortDir = 1;
    finalSearch = ''; finalSortCol = 'description'; finalSortDir = 1; finalStatusFilter = 'all';
    nbSearch = ''; nbSortCol = 'desc'; nbSortDir = 1;
    billSearch = ''; billSortCol = 'totalRxQty'; billSortDir = -1;
    discSearch = ''; discSortCol = 'desc'; discSortDir = 1;
    issSearch = ''; issSortCol = 'shortAmt'; issSortDir = 1;
    rawSearchTerms = {}; rawCollapsed = {}; rawGlobalSearch = '';
    ['supplier', 'billing'].forEach(k => {
        document.getElementById('card-' + k).classList.remove('loaded');
        document.getElementById('fn-' + k).textContent = '';
        document.getElementById('inp-' + k).value = '';
    });
    document.getElementById('app-screen').style.display = 'none';
    document.getElementById('upload-screen').style.display = 'flex';
    checkReady();
}

// ── Global keyboard/click handlers ──
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        const sel = window.getSelection();
        if (sel && sel.toString().trim()) return;
        const a = document.activeElement;
        if (a && a.tagName === 'TD') navigator.clipboard.writeText(a.textContent.trim()).catch(() => {});
    }
});
document.addEventListener('click', e => {
    const td = e.target.closest('td');
    if (td) {
        document.querySelectorAll('td.focused').forEach(c => c.classList.remove('focused'));
        td.classList.add('focused');
        td.tabIndex = 0;
        td.focus();
    }
});
