// ════════════════════════════════════
//  SUPPLIERS TAB
// ════════════════════════════════════

function renderSuppliersTab() {
    const rows = Object.keys(purchaseMap).map(ndc => {
        const sup = purchaseMap[ndc];
        const transactions = supTransactions[ndc] || [];
        const fileTotals = supFileTotals[ndc] || {};
        const pkgSizes = [...new Set(transactions.map(t => t.sz))].sort((a, b) => a - b);
        return { ndc, desc: sup.description, total: sup.totalQty, transactions, fileTotals, pkgSizes };
    });
    let sorted = [...rows];
    if (supSortCol === 'ndc') sorted.sort((a, b) => supSortDir * a.ndc.localeCompare(b.ndc));
    else if (supSortCol === 'desc') sorted.sort((a, b) => supSortDir * a.desc.localeCompare(b.desc));
    else if (supSortCol === 'total') sorted.sort((a, b) => supSortDir * (a.total - b.total));
    else if (supSortCol === 'pkgSize') sorted.sort((a, b) => { const aSize = a.pkgSizes.length ? a.pkgSizes[0] : 0; const bSize = b.pkgSizes.length ? b.pkgSizes[0] : 0; return supSortDir * (aSize - bSize); });
    const filtered = supSearch ? sorted.filter(r => r.ndc.includes(supSearch) || r.desc.toLowerCase().includes(supSearch.toLowerCase())) : sorted;

    function suppliersCell(fileTotals) {
        const entries = Object.entries(fileTotals);
        if (!entries.length) return '—';
        return entries.map(([fname, ftotal]) => { const short = fname.length > 25 ? fname.slice(0, 22) + '…' : fname; return `<span class="sup-file-entry"><span class="sup-file-name">${escHtml(short)}</span> <span class="sup-file-total">(${ftotal.toLocaleString()})</span></span>`; }).join('');
    }
    function calcCell(transactions) { if (!transactions.length) return '—'; return transactions.map(t => `(${t.qty}x${t.sz === Math.floor(t.sz) ? Math.floor(t.sz) : t.sz})`).join(' + '); }
    function pkgSizeCell(pkgSizes) { if (!pkgSizes.length) return '—'; return pkgSizes.map(sz => sz === Math.floor(sz) ? Math.floor(sz) : sz).join(', '); }
    function thClass(col) { return supSortCol === col ? (supSortDir === 1 ? 'asc' : 'desc') : ''; }

    let html = `<div class="sup-outer"><div class="sup-header"><div class="sup-title">Suppliers: <span>${supplierFiles.length}</span></div><div class="sup-header-spacer"></div><input class="raw-search" id="sup-search-inp" placeholder="Search this view..." value="${escHtml(supSearch)}" oninput="supSearchFn(this.value)"><button class="export-btn" onclick="openExportModal('suppliers')">⬇ Export</button></div><div class="sup-table-wrap"><table class="sup-table"><thead><tr><th style="width:48px;text-align:center" onclick="supSort('sr')" class="${thClass('sr')}">Sr#</th><th style="width:112px" onclick="supSort('ndc')" class="${thClass('ndc')}">NDC</th><th style="min-width:200px" onclick="supSort('desc')" class="${thClass('desc')}">Description</th><th style="width:80px;text-align:right" onclick="supSort('pkgSize')" class="${thClass('pkgSize')}">Pkg Size</th><th style="min-width:170px">Suppliers (files)</th><th style="min-width:210px">Calculation</th><th style="width:80px;text-align:right" onclick="supSort('total')" class="${thClass('total')}">Total</th></tr></thead><tbody>`;
    filtered.forEach((r, i) => {
        const grp = ndcGroups.find(g => g.ndc === r.ndc);
        const bRow = billingRows.find(b => b.ndc === r.ndc);
        const nameDisp = bRow && bRow.drgName ? bRow.drgName : (r.desc || '');
        const strongDisp = bRow && bRow.strong ? bRow.strong : '';
        const formDisp = grp ? grp.drugForm : '';
        html += `<tr><td style="text-align:center;font-weight:700;color:var(--text-muted);font-size:11px">${i + 1}</td><td><span class="sup-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td>${descCellHtml(nameDisp, strongDisp, formDisp, supSearch)}</td><td style="text-align:right;font-variant-numeric:tabular-nums;">${pkgSizeCell(r.pkgSizes)}</td><td class="sup-files">${suppliersCell(r.fileTotals)}</td><td class="sup-calc">${escHtml(calcCell(r.transactions))}</td><td class="sup-total">${r.total.toLocaleString()}</td></tr>`;
    });
    html += `</tbody></table></div></div>`;
    document.getElementById('suppliers-content').innerHTML = html;
    const inp = document.getElementById('sup-search-inp'); if (inp && supSearch) { inp.focus(); inp.setSelectionRange(supSearch.length, supSearch.length); }
}

function supSearchFn(v) { supSearch = v; renderSuppliersTab(); }
function supSort(col) { if (supSortCol === col) { supSortDir *= -1; } else { supSortCol = col; supSortDir = col === 'desc' || col === 'ndc' || col === 'pkgSize' ? 1 : -1; } renderSuppliersTab(); }

// ════════════════════════════════════
//  MFP TAB
// ════════════════════════════════════

// MFP year filter: 'all'=all, '2026'=2026 only, '2027'=up to 2027, '2028'=up to 2028
function setMFPYear(year, btn) {
    mfpActiveYear = year;
    document.querySelectorAll('#mfp-year-filters .year-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderMFP();
}

// Returns the set of years included for a given filter selection
function mfpYearSet(filter) {
    if (filter === 'all')   return null;           // null = no year filter
    if (filter === '2026')  return new Set(['2026']);
    if (filter === '2027')  return new Set(['2026','2027']);
    if (filter === '2028')  return new Set(['2026','2027','2028']);
    return new Set([filter]);
}

function setMFPStatus(status, btn) {
    mfpActiveStatus = status;
    document.querySelectorAll('#mfp-status-filters .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderMFP();
}

function initMFPFilters() {
    const mfpGrps = ndcGroups.filter(g => MFP_NDCS[g.ndc]);
    const ins = [...new Set(mfpGrps.flatMap(g => g.insurerRows.map(r => r.insName)).filter(Boolean))].sort();
    const frm = [...new Set(mfpGrps.map(g => g.drugForm).filter(Boolean))].sort();
    document.getElementById('mfp-ins-filter').innerHTML = '<option>All Insurers</option>' + ins.map(i => `<option>${i}</option>`).join('');
    document.getElementById('mfp-form-filter').innerHTML = '<option>All Drug Forms</option>' + frm.map(f => `<option>${f}</option>`).join('');
}

function renderMFP() {
    const insF = document.getElementById('mfp-ins-filter').value;
    const frmF = document.getElementById('mfp-form-filter').value;
    const srch = document.getElementById('mfp-search').value.toLowerCase();
    const filterIns = insF !== 'All Insurers';
    let mfpGrps = ndcGroups.filter(g => {
        if (!MFP_NDCS[g.ndc]) return false;
        // Cumulative year filter: 2026=only 2026, 2027=up to 2027, 2028=up to 2028
        if (mfpActiveYear !== 'all') {
            const allowed = mfpYearSet(mfpActiveYear);
            const ndcYears = MFP_NDCS[g.ndc] || [];
            // NDC must have at least one year in the allowed set
            if (!ndcYears.some(y => allowed.has(y))) return false;
        }
        if (mfpActiveStatus !== 'all' && g.status !== mfpActiveStatus) return false;
        if (filterIns && !g.insurerRows.some(r => r.insName === insF)) return false;
        if (frmF !== 'All Drug Forms' && g.drugForm !== frmF) return false;
        if (srch && !g.description.toLowerCase().includes(srch) && !g.ndc.includes(srch)) return false;
        return true;
    });
    const ok = mfpGrps.filter(g => g.status === 'ok').length;
    const ov = mfpGrps.filter(g => g.status === 'over').length;
    const sh = mfpGrps.filter(g => g.status === 'short').length;
    document.getElementById('mfp-summary-bar').innerHTML = `<div class="summary-pill"><div class="pill-dot ok"></div><span>OK: <strong class="pill-count">${ok}</strong></span></div><div class="summary-pill"><div class="pill-dot over"></div><span>Over: <strong class="pill-count">${ov}</strong></span></div><div class="summary-pill"><div class="pill-dot short"></div><span>Short: <strong class="pill-count">${sh}</strong></span></div><div class="summary-pill" style="margin-left:8px;color:var(--text-muted)">MFP NDCs matched: <strong>${mfpGrps.length}</strong></div><div class="summary-pill" style="color:var(--mfp);font-weight:600">Year: ${mfpActiveYear === 'all' ? 'All' : mfpActiveYear === '2026' ? '2026' : mfpActiveYear === '2027' ? '2026–2027' : mfpActiveYear === '2028' ? '2026–2028' : mfpActiveYear}</div>`;
    const tbody = document.getElementById('mfp-body');
    if (!mfpGrps.length) { tbody.innerHTML = `<tr><td colspan="11" class="empty-state">No MFP records match.</td></tr>`; return; }
    const frag = document.createDocumentFragment();
    let sr = 0, curNDC = null;
    for (const grp of mfpGrps) {
        const insRows = filterIns ? grp.insurerRows.filter(r => r.insName === insF) : grp.insurerRows;
        for (const ins of insRows) {
            if (grp.ndc !== curNDC) { curNDC = grp.ndc; sr = 1; } else sr++;
            const isHL = ins.qty === grp.maxQty, d = grp.totalPurchaseQty - ins.qty;
            const mfpPkg = grp.packageSize || 0;
            const tr = document.createElement('tr'); tr.className = 'row-detail';
            tr.innerHTML = `<td class="sr-cell">${sr}</td><td class="col-desc">${descCellHtml(grp.drgName || grp.description, grp.strong, grp.form, srch)}</td><td class="ndc-plain" onclick="copyText('${grp.ndc}')">${grp.ndc}</td><td class="qty-cell">${grp.packageSize ? grp.packageSize.toFixed(3) : ''}</td><td class="${isHL ? 'hl-ins' : ''}">${ins.insName}</td><td class="${isHL ? 'hl-bin' : ''}" style="white-space:nowrap">${ins.binNo}</td><td class="qty-cell${isHL ? ' hl-qty' : ''}">${qtyDisp(ins.qty, mfpPkg)}</td><td class="qty-cell">${qtyDisp(grp.totalPurchaseQty, mfpPkg)}</td><td class="diff-cell">${diffHtmlFn(d, mfpPkg)}</td><td></td>`;
            frag.appendChild(tr);
        }
        if (!filterIns) {
            sr++;
            const d = grp.diff;
            const pkg = grp.packageSize || 0;
            const tr = document.createElement('tr'); tr.className = `row-total status-${grp.status}`;
            tr.innerHTML = `<td class="sr-cell">${sr}</td><td class="col-desc">${descCellHtml(grp.drgName || grp.description, grp.strong, grp.form, '')}</td><td class="ndc-plain" onclick="copyText('${grp.ndc}')">${grp.ndc}</td><td></td><td></td><td></td><td class="qty-cell">${qtyDisp(grp.totalRxQty, pkg)}</td><td class="qty-cell">${qtyDisp(grp.totalPurchaseQty, pkg)}</td><td></td><td>${statusHtmlFn(d, pkg)}</td>`;
            frag.appendChild(tr);
        }
    }
    tbody.innerHTML = ''; tbody.appendChild(frag);
}

// ════════════════════════════════════
//  FINAL TAB
// ════════════════════════════════════

function renderFinalTab() {
    const container = document.getElementById('final-content');
    if (!ndcGroups.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">✅</div><span>No data — upload and reconcile files first.</span></div>`; return; }
    let rows = [...ndcGroups].map(g => {
        const insurerNames = [...new Set(g.insurerRows.map(r => r.insName).filter(Boolean))];
        const pkg = g.packageSize || 0;
        const initsPerPkg = pkg > 0 && g.totalRxQty > 0 ? Math.round(g.totalRxQty / pkg) : null;
        return { ndc: g.ndc, desc: g.description, drgName: g.drgName, strong: g.strong, form: g.form, needed: g.totalRxQty, ordered: g.totalPurchaseQty, variance: g.diff, status: g.status, packageSize: pkg, insurers: insurerNames, initsPerPkg };
    });
    if (finalStatusFilter !== 'all') rows = rows.filter(r => r.status === finalStatusFilter);
    rows.sort((a, b) => { let av = a[finalSortCol], bv = b[finalSortCol]; if (typeof av === 'string') return finalSortDir * av.localeCompare(bv); return finalSortDir * ((av || 0) - (bv || 0)); });
    if (finalSearch) { const s = finalSearch.toLowerCase(); rows = rows.filter(r => r.ndc.includes(s) || r.desc.toLowerCase().includes(s) || r.insurers.some(i => i.toLowerCase().includes(s))); }
    const okAll = ndcGroups.filter(g => g.status === 'ok').length, ovAll = ndcGroups.filter(g => g.status === 'over').length, shAll = ndcGroups.filter(g => g.status === 'short').length;
    function thCls(col) { return finalSortCol === col ? (finalSortDir === 1 ? 'asc' : 'desc') : ''; }
    const fBtn = (s, label, color, bg) => `<button onclick="setFinalStatus('${s}')" style="padding:4px 11px;border-radius:4px;border:1px solid ${finalStatusFilter === s ? color : 'var(--border)'};background:${finalStatusFilter === s ? color : bg || 'var(--surface)'};color:${finalStatusFilter === s ? '#fff' : color};font-size:12px;font-weight:600;cursor:pointer;transition:all .15s">${label}</button>`;
    let html = `<div class="final-outer"><div class="final-header"><div class="final-title">Variance: <span>Needed vs Ordered</span></div><div style="display:flex;gap:8px;align-items:center;margin:0 8px;background:#7c3aed1d;padding:4px 4px;border-radius:4px;">${fBtn('all', 'All', '#374151')}${fBtn('ok', 'OK', '#16a34a')}${fBtn('over', 'Over', '#b45309')}${fBtn('short', 'Short', '#dc2626')}</div><div class="final-header-spacer"></div><input class="raw-search" id="final-search-inp" placeholder="Search NDC, name, insurer..." value="${escHtml(finalSearch)}" oninput="finalSearchFn(this.value)"><button class="export-btn" onclick="openExportModal('final')">⬇ Export</button></div><div style="background:var(--surface);border-bottom:1px solid var(--border);padding:5px 16px;display:flex;gap:14px;flex-shrink:0;align-items:center"><div class="summary-pill"><div class="pill-dot ok"></div><span>OK: <strong class="pill-count">${okAll}</strong></span></div><div class="summary-pill"><div class="pill-dot over"></div><span>Over: <strong class="pill-count">${ovAll}</strong></span></div><div class="summary-pill"><div class="pill-dot short"></div><span>Short: <strong class="pill-count">${shAll}</strong></span></div><div class="summary-pill" style="margin-left:8px;color:var(--text-muted)">Showing: <strong>${rows.length}</strong></div></div><div class="final-table-wrap"><table class="final-table"><thead><tr><th style="width:44px;text-align:center">Sr#</th><th style="width:108px" onclick="finalSort('ndc')" class="${thCls('ndc')}">NDC</th><th style="min-width:220px" onclick="finalSort('desc')" class="${thCls('desc')}">Description</th><th style="width:85px;text-align:right" onclick="finalSort('packageSize')" class="${thCls('packageSize')}">Pkg Size</th><th style="min-width:140px">Insurers</th><th style="width:80px;text-align:left" onclick="finalSort('initsPerPkg')" class="${thCls('initsPerPkg')}">INITS/PKG</th><th style="width:85px;text-align:right" onclick="finalSort('needed')" class="${thCls('needed')}">Needed</th><th style="width:85px;text-align:right" onclick="finalSort('ordered')" class="${thCls('ordered')}">Ordered</th><th style="width:85px;text-align:right" onclick="finalSort('variance')" class="${thCls('variance')}">Variance</th><th style="width:150px" onclick="finalSort('status')" class="${thCls('status')}">Status</th></tr></thead><tbody>`;
    rows.forEach((r, i) => {
        const rowCls = r.status === 'ok' ? 'final-row-ok' : r.status === 'over' ? 'final-row-over' : 'final-row-short';
        const pkg = r.packageSize || 0;
        const insChips = r.insurers.map(ins => `<span style="display:inline-block;background:rgba(0,0,0,.06);padding:1px 5px;border-radius:3px;font-size:10px;margin:1px 2px 1px 0;white-space:nowrap">${finalSearch ? hlText(escHtml(ins), finalSearch) : escHtml(ins)}</span>`).join('');
        let varDisp;
        if (pkgDivideOn && pkg > 0) {
            const vPkg   = r.variance / pkg;
            const abs    = Math.abs(vPkg);
            const absStr = abs % 1 === 0 ? abs.toFixed(1) : abs.toFixed(2);
            varDisp = vPkg === 0 ? '0.0'
                : vPkg > 0 ? `<span class="pkg-div-val">+${absStr}</span>`
                : `<span class="pkg-div-val" style="color:var(--short)">-${absStr}</span>`;
        } else {
            const abs = Math.abs(r.variance).toFixed(1);
            varDisp = r.variance === 0 ? '0.0'
                : r.variance > 0 ? `+${abs}`
                : `-${abs}`;
        }
        // Use shared statusHtmlFn so STATUS always shows amount (÷PKG or normal)
        const statDisp = statusHtmlFn(r.variance, pkg);
        html += `<tr class="${rowCls}"><td style="text-align:center;font-weight:700;font-size:11px">${i + 1}</td><td><span class="final-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td style="min-width:220px">${descCellHtml(r.drgName || r.desc, r.strong, r.form, finalSearch)}</td><td class="final-num">${r.packageSize ? r.packageSize.toFixed(3) : ''}</td><td style="font-size:11px">${insChips || '—'}</td><td class="final-num">${r.initsPerPkg != null ? r.initsPerPkg : ''}</td><td class="final-num">${qtyDisp(r.needed, pkg)}</td><td class="final-num">${qtyDisp(r.ordered, pkg)}</td><td class="final-num">${varDisp}</td><td style="font-weight:700;font-size:12px">${statDisp}</td></tr>`;
    });
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('final-search-inp'); if (inp && finalSearch) { inp.focus(); inp.setSelectionRange(finalSearch.length, finalSearch.length); }
}

function setFinalStatus(s) { finalStatusFilter = s; renderFinalTab(); }
function finalSearchFn(v) { finalSearch = v; renderFinalTab(); }
function finalSort(col) { if (col === 'sr') return; if (finalSortCol === col) { finalSortDir *= -1; } else { finalSortCol = col; finalSortDir = (col === 'desc' || col === 'ndc' || col === 'status') ? 1 : -1; } renderFinalTab(); }

// ════════════════════════════════════
//  NOT BILLED TAB
// ════════════════════════════════════

function renderNotBilledTab() {
    const container = document.getElementById('notbilled-content');
    if (!Object.keys(purchaseMap).length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">⚠️</div><span>No data — upload and reconcile files first.</span></div>`; return; }
    const billedNdcs = new Set(billingRows.map(r => r.ndc));
    let rows = Object.keys(purchaseMap).filter(ndc => !billedNdcs.has(ndc)).map(ndc => {
        const sup = purchaseMap[ndc]; const fileTotals = supFileTotals[ndc] || {};
        const transactions = supTransactions[ndc] || [];
        const pkgSizes = [...new Set(transactions.map(t => t.sz))].sort((a, b) => a - b);
        const bRow = billingRows.find(r => r.ndc === ndc);
        return { ndc, desc: sup.description, nameDisp: (bRow && bRow.drgName ? bRow.drgName : sup.description || ''), strongDisp: (bRow && bRow.strong ? bRow.strong : ''), formDisp: (bRow && bRow.form ? bRow.form : ''), totalQty: sup.totalQty, fileTotals, transactions, pkgSizes };
    });
    rows.sort((a, b) => { if (nbSortCol === 'ndc') return nbSortDir * a.ndc.localeCompare(b.ndc); if (nbSortCol === 'pkgSize') return nbSortDir * ((a.pkgSizes.length ? a.pkgSizes[0] : 0) - (b.pkgSizes.length ? b.pkgSizes[0] : 0)); if (nbSortCol === 'total') return nbSortDir * (a.totalQty - b.totalQty); return nbSortDir * a.desc.localeCompare(b.desc); });
    if (nbSearch) { const s = nbSearch.toLowerCase(); rows = rows.filter(r => r.ndc.includes(s) || r.desc.toLowerCase().includes(s)); }
    function thCls(col) { return nbSortCol === col ? (nbSortDir === 1 ? 'asc' : 'desc') : ''; }
    function fileChips(fileTotals) { return Object.entries(fileTotals).map(([f, t]) => { const sh = f.length > 22 ? f.slice(0, 19) + '…' : f; return `<span class="nb-file-chip">${escHtml(sh)} (${t.toLocaleString()})</span>`; }).join(''); }
    function pkgSizeCell(pkgSizes) { if (!pkgSizes.length) return '—'; return pkgSizes.map(sz => sz === Math.floor(sz) ? Math.floor(sz) : sz).join(', '); }
    function calcCell(transactions) { if (!transactions.length) return '—'; return transactions.map(t => `(${t.qty}x${t.sz === Math.floor(t.sz) ? Math.floor(t.sz) : t.sz})`).join(' + '); }
    let html = `<div class="nb-outer"><div class="nb-header"><div class="nb-title">Not Billed: <span>${rows.length} NDCs</span> &nbsp;<small style="font-size:11px;font-weight:400;color:var(--text-muted)">— Ordered by supplier but no billing record found</small></div><div class="nb-header-spacer"></div><input class="raw-search" id="nb-search-inp" placeholder="Search NDC or description..." value="${escHtml(nbSearch)}" oninput="nbSearchFn(this.value)"><button class="export-btn" onclick="openExportModal('notbilled')">⬇ Export</button></div><div class="nb-summary-bar"><div class="nb-summary-pill">Total Unmatched NDCs: <strong>${rows.length}</strong></div><div class="nb-summary-pill" style="margin-left:8px;">Total Ordered Qty: <strong>${rows.reduce((s, r) => s + r.totalQty, 0).toLocaleString()}</strong></div></div><div class="nb-table-wrap"><table class="nb-table"><thead><tr><th style="width:48px;text-align:center">Sr#</th><th style="width:112px" onclick="nbSort('ndc')" class="${thCls('ndc')}">NDC</th><th style="min-width:220px" onclick="nbSort('desc')" class="${thCls('desc')}">Description</th><th style="width:80px;text-align:right" onclick="nbSort('pkgSize')" class="${thCls('pkgSize')}">Pkg Size</th><th style="min-width:160px">Supplier Files</th><th style="min-width:210px">Calculation</th><th style="width:110px;text-align:right" onclick="nbSort('total')" class="${thCls('total')}">Ordered Qty</th><th style="width:100px;text-align:center">Status</th></tr></thead><tbody>`;
    if (!rows.length) { html += `<tr><td colspan="8" class="empty-state" style="background:#fff7ed">🎉 All supplier NDCs have matching billing records.</td></tr>`; }
    else { rows.forEach((r, i) => { html += `<tr><td style="text-align:center;font-weight:700;font-size:11px;color:#92400e">${i + 1}</td><td><span class="nb-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td>${descCellHtml(r.nameDisp, r.strongDisp, r.formDisp, nbSearch)}</td><td style="text-align:right;font-variant-numeric:tabular-nums;">${pkgSizeCell(r.pkgSizes)}</td><td>${fileChips(r.fileTotals)}</td><td class="sup-calc">${escHtml(calcCell(r.transactions))}</td><td class="nb-num" style="color:#b45309">${r.totalQty.toLocaleString()}</td><td style="text-align:center"><span class="nb-badge">NOT BILLED</span></td></tr>`; }); }
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('nb-search-inp'); if (inp && nbSearch) { inp.focus(); inp.setSelectionRange(nbSearch.length, nbSearch.length); }
}

function nbSearchFn(v) { nbSearch = v; renderNotBilledTab(); }
function nbSort(col) { if (nbSortCol === col) { nbSortDir *= -1; } else { nbSortCol = col; nbSortDir = (col === 'total' || col === 'pkgSize') ? -1 : 1; } renderNotBilledTab(); }

// ════════════════════════════════════
//  BILL TAB
// ════════════════════════════════════

function renderBillTab() {
    const container = document.getElementById('bill-content');
    if (!ndcGroups.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">💵</div><span>No data — run reconciliation first.</span></div>`; return; }
    const insMap = {};
    for (const grp of ndcGroups) {
        for (const ins of grp.insurerRows) { const key = ins.insName || 'UNKNOWN'; if (!insMap[key]) insMap[key] = { insName: ins.insName, bins: new Set(), ndcs: new Set(), totalRxQty: 0, totalPurchaseQty: 0, ok: 0, over: 0, short: 0 }; for (const b of ins.bins) insMap[key].bins.add(b); insMap[key].ndcs.add(grp.ndc); insMap[key].totalRxQty += ins.qty; insMap[key][grp.status]++; }
        for (const ins of grp.insurerRows) { const key = ins.insName || 'UNKNOWN'; if (insMap[key] && !insMap[key]['_ndcPurchase' + grp.ndc]) { insMap[key]['_ndcPurchase' + grp.ndc] = true; insMap[key].totalPurchaseQty += grp.totalPurchaseQty; } }
    }
    let rows = Object.values(insMap).map(r => ({ insName: r.insName, bins: [...r.bins].sort(), ndcCount: r.ndcs.size, totalRxQty: r.totalRxQty, totalPurchaseQty: r.totalPurchaseQty, ok: r.ok, over: r.over, short: r.short }));
    rows.sort((a, b) => { if (billSortCol === 'insName') return billSortDir * a.insName.localeCompare(b.insName); if (billSortCol === 'ndcCount') return billSortDir * (a.ndcCount - b.ndcCount); if (billSortCol === 'ok') return billSortDir * (a.ok - b.ok); if (billSortCol === 'over') return billSortDir * (a.over - b.over); if (billSortCol === 'short') return billSortDir * (a.short - b.short); if (billSortCol === 'totalPurchaseQty') return billSortDir * (a.totalPurchaseQty - b.totalPurchaseQty); return billSortDir * (a.totalRxQty - b.totalRxQty); });
    if (billSearch) { const s = billSearch.toLowerCase(); rows = rows.filter(r => r.insName.toLowerCase().includes(s) || r.bins.some(b => b.includes(s))); }
    const hl = v => billSearch ? hlText(escHtml(String(v)), billSearch) : escHtml(String(v));
    const totalRxQty = rows.reduce((s, r) => s + r.totalRxQty, 0); const totalPurchaseQty = rows.reduce((s, r) => s + r.totalPurchaseQty, 0); const totalNDCs = new Set(ndcGroups.map(g => g.ndc)).size;
    function thCls(col) { return billSortCol === col ? (billSortDir === 1 ? 'asc' : 'desc') : ''; }
    let html = `<div class="bill-outer"><div class="bill-header"><div class="bill-title">Bill: <span>By Insurer / Payer</span></div><div style="flex:1"></div><input class="raw-search" id="bill-search-inp" placeholder="Search insurer or BIN..." value="${escHtml(billSearch)}" oninput="billSearchFn(this.value)"><button class="export-btn" onclick="openExportModal('bill')">⬇ Export</button></div><div class="bill-summary-bar"><div class="summary-pill"><span>Insurers: <strong class="pill-count">${rows.length}</strong></span></div><div class="summary-pill"><span>Total NDCs: <strong class="pill-count">${totalNDCs}</strong></span></div><div class="summary-pill"><span>Total Rx Qty: <strong class="pill-count">${totalRxQty.toLocaleString()}</strong></span></div><div class="summary-pill"><span>Total Purchase Qty: <strong class="pill-count">${totalPurchaseQty.toLocaleString()}</strong></span></div></div><div class="bill-table-wrap"><table class="bill-table"><thead><tr><th style="width:44px;text-align:center">Sr#</th><th style="min-width:160px" onclick="billSort('insName')" class="${thCls('insName')}">Insurer Name</th><th style="min-width:180px">BIN Codes</th><th style="width:80px;text-align:right" onclick="billSort('ndcCount')" class="${thCls('ndcCount')}">NDC Count</th><th style="width:105px;text-align:right" onclick="billSort('totalRxQty')" class="${thCls('totalRxQty')}">Billed Qty</th><th style="width:115px;text-align:right" onclick="billSort('totalPurchaseQty')" class="${thCls('totalPurchaseQty')}">Purchase QTY</th><th style="width:70px;text-align:center" onclick="billSort('ok')" class="${thCls('ok')}">OK</th><th style="width:70px;text-align:center" onclick="billSort('over')" class="${thCls('over')}">Over</th><th style="width:70px;text-align:center" onclick="billSort('short')" class="${thCls('short')}">Short</th></tr></thead><tbody>`;
    rows.forEach((r, i) => { html += `<tr><td style="text-align:center;font-weight:700;color:var(--text-muted);font-size:11px">${i + 1}</td><td class="bill-ins-name">${hl(r.insName)}</td><td class="bill-bin-chips">${r.bins.map(b => `<span>${escHtml(b)}</span>`).join('')}</td><td class="bill-num">${r.ndcCount.toLocaleString()}</td><td class="bill-num">${r.totalRxQty.toLocaleString()}</td><td class="bill-num" style="color:var(--primary);font-weight:700">${r.totalPurchaseQty.toLocaleString()}</td><td style="text-align:center">${r.ok ? `<span class="bill-ok-pill">${r.ok}</span>` : ''}</td><td style="text-align:center">${r.over ? `<span class="bill-over-pill">${r.over}</span>` : ''}</td><td style="text-align:center">${r.short ? `<span class="bill-short-pill">${r.short}</span>` : ''}</td></tr>`; });
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('bill-search-inp'); if (inp && billSearch) { inp.focus(); inp.setSelectionRange(billSearch.length, billSearch.length); }
}

function billSearchFn(v) { billSearch = v; renderBillTab(); }
function billSort(col) { if (billSortCol === col) { billSortDir *= -1; } else { billSortCol = col; billSortDir = (col === 'insName') ? 1 : -1; } renderBillTab(); }

// ════════════════════════════════════
//  DISCARDED TAB
// ════════════════════════════════════

function renderDiscardedTab() {
    const container = document.getElementById('discarded-content');
    if (!billingRows.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">🗑️</div><span>No data — run reconciliation first.</span></div>`; return; }
    const suppliedNdcs = new Set(Object.keys(purchaseMap)); const discMap = {};
    for (const r of billingRows) {
        if (suppliedNdcs.has(r.ndc)) continue;
        if (!discMap[r.ndc]) discMap[r.ndc] = { ndc: r.ndc, desc: r.drgName || '', strong: r.strong || '', form: r.form || '', insurerQty: {}, total: 0 };
        const ins = r.insName || 'UNKNOWN'; if (!discMap[r.ndc].insurerQty[ins]) discMap[r.ndc].insurerQty[ins] = 0; discMap[r.ndc].insurerQty[ins] += r.qty; discMap[r.ndc].total += r.qty;
        if (!discMap[r.ndc].desc && r.drgName) discMap[r.ndc].desc = r.drgName;
        if (!discMap[r.ndc].strong && r.strong) discMap[r.ndc].strong = r.strong;
        if (!discMap[r.ndc].form && r.form) discMap[r.ndc].form = r.form;
    }
    let rows = Object.values(discMap).map(r => ({ ...r, insurers: Object.entries(r.insurerQty).sort((a, b) => b[1] - a[1]) }));
    rows.sort((a, b) => { if (discSortCol === 'ndc') return discSortDir * a.ndc.localeCompare(b.ndc); if (discSortCol === 'total') return discSortDir * (a.total - b.total); return discSortDir * (a.desc || '').localeCompare(b.desc || ''); });
    if (discSearch) { const s = discSearch.toLowerCase(); rows = rows.filter(r => r.ndc.includes(s) || (r.desc || '').toLowerCase().includes(s) || r.insurers.some(([ins]) => ins.toLowerCase().includes(s))); }
    function thCls(col) { return discSortCol === col ? (discSortDir === 1 ? 'asc' : 'desc') : ''; }
    let html = `<div class="disc-outer"><div class="disc-header"><div class="disc-title">Discarded: <span>${rows.length} NDCs</span> &nbsp;<small style="font-size:11px;font-weight:400;color:#6d28d9">— Billed/dispensed but no supplier purchase record found</small></div><div style="flex:1"></div><input class="raw-search" id="disc-search-inp" placeholder="Search NDC, description or insurer..." value="${escHtml(discSearch)}" oninput="discSearchFn(this.value)"><button class="export-btn" onclick="openExportModal('discarded')">⬇ Export</button></div><div class="disc-summary-bar"><span>Total Unmatched: <strong>${rows.length}</strong></span><span>Total Billed Qty: <strong>${rows.reduce((s, r) => s + r.total, 0).toLocaleString()}</strong></span></div><div class="disc-table-wrap"><table class="disc-table"><thead><tr><th style="width:44px;text-align:center">Sr#</th><th style="width:108px" onclick="discSort('ndc')" class="${thCls('ndc')}">NDC</th><th style="min-width:220px" onclick="discSort('desc')" class="${thCls('desc')}">Description</th><th style="min-width:180px">Insurer</th><th style="width:110px;text-align:right">Billed QTY</th><th style="width:110px;text-align:right" onclick="discSort('total')" class="${thCls('total')}">Total Billed</th><th style="width:110px;text-align:center">Status</th></tr></thead><tbody>`;
    if (!rows.length) { html += `<tr><td colspan="7" class="empty-state" style="background:#fdf4ff">🎉 All billed NDCs have matching supplier records.</td></tr>`; }
    else { rows.forEach((r, i) => { const rowspan = r.insurers.length || 1; if (r.insurers.length === 0) { html += `<tr><td style="text-align:center;font-weight:700;font-size:11px;color:#6d28d9">${i + 1}</td><td><span class="disc-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td>${descCellHtml(r.desc, r.strong, r.form, discSearch)}</td><td>—</td><td class="disc-num">0</td><td class="disc-num">${r.total.toLocaleString()}</td><td style="text-align:center"><span class="disc-badge">NO SUPPLIER</span></td></tr>`; } else { r.insurers.forEach(([ins, qty], j) => { html += `<tr>`; if (j === 0) { html += `<td rowspan="${rowspan}" style="text-align:center;font-weight:700;font-size:11px;color:#6d28d9;vertical-align:top;padding-top:8px">${i + 1}</td><td rowspan="${rowspan}" style="vertical-align:top;padding-top:8px"><span class="disc-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td rowspan="${rowspan}" style="vertical-align:top;padding-top:8px;min-width:220px">${descCellHtml(r.desc, r.strong, r.form, discSearch)}</td>`; } html += `<td><span style="display:inline-block;background:#ede9fe;color:#6d28d9;padding:1px 6px;border-radius:3px;font-size:10.5px;font-weight:600">${discSearch ? hlText(escHtml(ins), discSearch) : escHtml(ins)}</span></td><td class="disc-num">${qty.toLocaleString()}</td>`; if (j === 0) { html += `<td rowspan="${rowspan}" class="disc-num" style="font-size:13px;vertical-align:middle">${r.total.toLocaleString()}</td><td rowspan="${rowspan}" style="text-align:center;vertical-align:middle"><span class="disc-badge">NO SUPPLIER</span></td>`; } html += `</tr>`; }); } }); }
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('disc-search-inp'); if (inp && discSearch) { inp.focus(); inp.setSelectionRange(discSearch.length, discSearch.length); }
}

function discSearchFn(v) { discSearch = v; renderDiscardedTab(); }
function discSort(col) { if (discSortCol === col) { discSortDir *= -1; } else { discSortCol = col; discSortDir = (col === 'total') ? -1 : 1; } renderDiscardedTab(); }

// ════════════════════════════════════
//  ISSUES TAB
// ════════════════════════════════════

function renderIssuesTab() {
    const container = document.getElementById('issues-content');
    if (!ndcGroups.length) { container.innerHTML = `<div class="placeholder-tab"><div class="icon">⚠️</div><span>No data — run reconciliation first.</span></div>`; return; }
    let rows = ndcGroups.filter(g => g.status === 'short').map(g => {
        const shortAmt = Math.abs(g.diff); const pkg = g.packageSize || 0;
        const unitsNeeded = pkg > 0 ? Math.ceil(shortAmt / pkg) : null;
        const topIns = [...g.insurerRows].sort((a, b) => b.qty - a.qty)[0];
        return { ndc: g.ndc, desc: g.description, drgName: g.drgName, strong: g.strong, form: g.form, shortAmt, needed: g.totalRxQty, ordered: g.totalPurchaseQty, packageSize: pkg, unitsNeeded, topInsurer: topIns ? topIns.insName : '', insurerCount: g.insurerRows.length };
    });
    rows.sort((a, b) => { if (issSortCol === 'ndc') return issSortDir * a.ndc.localeCompare(b.ndc); if (issSortCol === 'desc') return issSortDir * a.desc.localeCompare(b.desc); if (issSortCol === 'needed') return issSortDir * (a.needed - b.needed); if (issSortCol === 'ordered') return issSortDir * (a.ordered - b.ordered); if (issSortCol === 'pkgSize') return issSortDir * (a.packageSize - b.packageSize); if (issSortCol === 'units') return issSortDir * ((a.unitsNeeded || 0) - (b.unitsNeeded || 0)); return issSortDir * (a.shortAmt - b.shortAmt); });
    if (issSearch) { const s = issSearch.toLowerCase(); rows = rows.filter(r => r.ndc.includes(s) || r.desc.toLowerCase().includes(s) || r.topInsurer.toLowerCase().includes(s)); }
    const totalShort = rows.reduce((s, r) => s + r.shortAmt, 0);
    function thCls(col) { return issSortCol === col ? (issSortDir === 1 ? 'asc' : 'desc') : ''; }
    let html = `<div class="iss-outer"><div class="iss-header"><div class="iss-title">Issues: <span>${rows.length} SHORT NDCs</span> &nbsp;<small style="font-size:11px;font-weight:400;color:#9f1239">— Purchase quantity less than billed quantity</small></div><div style="flex:1"></div><input class="raw-search" id="iss-search-inp" placeholder="Search NDC, description or insurer..." value="${escHtml(issSearch)}" oninput="issSearchFn(this.value)"><button class="export-btn" onclick="openExportModal('issues')">⬇ Export</button></div><div class="iss-summary-bar"><span>SHORT NDCs: <strong>${rows.length}</strong></span><span>Total Gap (units): <strong>${totalShort.toLocaleString()}</strong></span></div><div class="iss-table-wrap"><table class="iss-table"><thead><tr><th style="width:44px;text-align:center">Sr#</th><th style="width:112px" onclick="issSort('ndc')" class="${thCls('ndc')}">NDC</th><th style="min-width:220px" onclick="issSort('desc')" class="${thCls('desc')}">Description</th><th style="width:80px;text-align:right" onclick="issSort('pkgSize')" class="${thCls('pkgSize')}">Pkg Size</th><th style="width:100px;text-align:right" onclick="issSort('needed')" class="${thCls('needed')}">Billed Qty</th><th style="width:100px;text-align:right" onclick="issSort('ordered')" class="${thCls('ordered')}">Purchased Qty</th><th style="width:100px;text-align:right" onclick="issSort('shortAmt')" class="${thCls('shortAmt')}">Gap (units)</th><th style="width:90px;text-align:right" onclick="issSort('units')" class="${thCls('units')}">Pkgs Short</th><th style="min-width:140px">Top Insurer</th></tr></thead><tbody>`;
    if (!rows.length) { html += `<tr><td colspan="9" class="empty-state" style="background:#fff1f2">🎉 No SHORT issues found.</td></tr>`; }
    else { rows.forEach((r, i) => {
        const pctGap = r.needed > 0 ? ((r.shortAmt / r.needed) * 100).toFixed(1) : 0;
        const barW   = Math.min(100, parseFloat(pctGap));
        const pkg    = r.packageSize || 0;
        let neededDisp, orderedDisp, gapDisp, pkgsDisp;
        if (pkgDivideOn && pkg > 0) {
            neededDisp  = `<span class="pkg-div-val">${divByPkg(r.needed, pkg)}</span>`;
            orderedDisp = `<span class="pkg-div-val">${divByPkg(r.ordered, pkg)}</span>`;
            const gapPkg = r.shortAmt / pkg;
            const gapStr = gapPkg % 1 === 0 ? gapPkg.toFixed(0) : gapPkg.toFixed(2);
            gapDisp  = `<span style="font-weight:700;color:var(--short)" class="pkg-div-val">-${gapStr}</span><div style="margin-top:3px"><span class="iss-gap-bar" style="width:${barW}%;background:#fca5a5;"></span></div><div style="font-size:10px;color:#9f1239">${pctGap}% gap</div>`;
            pkgsDisp = `<span class="pkg-div-val">${r.unitsNeeded != null ? r.unitsNeeded : '—'}</span>`;
        } else {
            neededDisp  = fmt(r.needed);
            orderedDisp = fmt(r.ordered);
            gapDisp  = `<span style="font-weight:700;color:var(--short)">-${fmt(r.shortAmt)}</span><div style="margin-top:3px"><span class="iss-gap-bar" style="width:${barW}%;background:#fca5a5;"></span></div><div style="font-size:10px;color:#9f1239">${pctGap}% gap</div>`;
            pkgsDisp = r.unitsNeeded != null ? r.unitsNeeded : '—';
        }
        html += `<tr><td style="text-align:center;font-weight:700;font-size:11px;color:#9f1239">${i + 1}</td><td><span class="iss-ndc" onclick="copyText('${r.ndc}')">${r.ndc}</span></td><td>${descCellHtml(r.drgName || r.desc, r.strong, r.form, issSearch)}</td><td class="iss-num" style="color:var(--text)">${fmt(r.packageSize)}</td><td class="iss-num" style="color:var(--text)">${neededDisp}</td><td class="iss-num" style="color:var(--text)">${orderedDisp}</td><td style="text-align:right">${gapDisp}</td><td class="iss-num" style="color:var(--short)">${pkgsDisp}</td><td style="font-size:11.5px;color:var(--text-muted)">${issSearch ? hlText(escHtml(r.topInsurer), issSearch) : escHtml(r.topInsurer)}${r.insurerCount > 1 ? ` <span style="font-size:10px;color:var(--primary)">(+${r.insurerCount - 1} more)</span>` : ''}</td></tr>`;
    }); }
    html += `</tbody></table></div></div>`;
    container.innerHTML = html;
    const inp = document.getElementById('iss-search-inp'); if (inp && issSearch) { inp.focus(); inp.setSelectionRange(issSearch.length, issSearch.length); }
}

function issSearchFn(v) { issSearch = v; renderIssuesTab(); }
function issSort(col) { if (issSortCol === col) { issSortDir *= -1; } else { issSortCol = col; issSortDir = (col === 'desc' || col === 'ndc' || col === 'pkgSize') ? 1 : -1; } renderIssuesTab(); }

// ════════════════════════════════════
//  TAB SWITCHER
// ════════════════════════════════════

function switchTab(name, btn) {
    document.querySelectorAll('.topbar-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-results').style.display = 'none';
    document.getElementById('tab-mfp').style.display = 'none';
    ['raw', 'suppliers', 'final', 'bill', 'discarded', 'issues', 'notbilled'].forEach(t => document.getElementById('tab-' + t).classList.remove('active'));
    if (name === 'results') document.getElementById('tab-results').style.display = 'flex';
    else if (name === 'mfp') { document.getElementById('tab-mfp').style.display = 'flex'; initMFPFilters(); renderMFP(); }
    else {
        document.getElementById('tab-' + name).classList.add('active');
        if (name === 'suppliers') renderSuppliersTab();
        if (name === 'raw') renderRawPreview();
        if (name === 'final') renderFinalTab();
        if (name === 'notbilled') renderNotBilledTab();
        if (name === 'bill') renderBillTab();
        if (name === 'discarded') renderDiscardedTab();
        if (name === 'issues') renderIssuesTab();
    }
}
