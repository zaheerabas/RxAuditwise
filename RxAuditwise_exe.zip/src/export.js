// ════════════════════════════════════
//  EXPORT MODAL STATE
// ════════════════════════════════════

let emActiveTab = 'results', emFmt = 'csv', emCols = [];

// ── Helpers ──

function emCountRows(tab) {
    if (tab === 'results') return filteredRows.filter(r => r.type === 'total').length;
    if (tab === 'suppliers') return Object.keys(purchaseMap).length;
    if (tab === 'final') return ndcGroups.length;
    if (tab === 'bill') return [...new Set(ndcGroups.flatMap(g => g.insurerRows.map(r => r.insName)))].length;
    if (tab === 'discarded') { const s = new Set(Object.keys(purchaseMap)); return [...new Set(billingRows.filter(r => !s.has(r.ndc)).map(r => r.ndc))].length; }
    if (tab === 'issues') return ndcGroups.filter(g => g.status === 'short').length;
    if (tab === 'notbilled') { const b = new Set(billingRows.map(r => r.ndc)); return Object.keys(purchaseMap).filter(n => !b.has(n)).length; }
    if (tab === 'mfp') return ndcGroups.filter(g => MFP_NDCS[g.ndc]).length;
    return 0;
}

// ── Open / Close ──

function openExportModal(tab) {
    emActiveTab = tab; emFmt = 'csv';
    emCols = (EM_COLS[tab] || EM_COLS.results).map(c => ({ ...c }));
    document.getElementById('em-tab-info').textContent = `${EM_TAB_LABELS[tab]} · ${emCountRows(tab)} rows`;
    document.querySelectorAll('.em-fmt').forEach(b => b.classList.remove('active'));
    document.querySelector('.em-fmt[data-fmt="csv"]').classList.add('active');
    document.getElementById('em-fname').value = EM_DEFAULTS[tab] || 'NDC_Export';
    document.getElementById('em-ext').textContent = '.csv';
    emRenderCols();
    document.getElementById('export-overlay').style.display = 'flex';
}

function closeExportModal() { document.getElementById('export-overlay').style.display = 'none'; }

// ── Column grid ──

function emRenderCols() {
    const grid = document.getElementById('em-col-grid');
    grid.innerHTML = emCols.map((c, i) => `
        <div class="em-col-item${c.on ? ' on' : ''}" onclick="emToggleCol(${i})">
          <div class="em-checkbox">
            ${c.on ? '<svg width="9" height="7" viewBox="0 0 9 7" fill="none"><path d="M1 3.5L3.5 6L8 1" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : ''}
          </div>
          <span class="em-col-name">${c.label}</span>
        </div>`).join('');
    emUpdateFooter();
}

function emToggleCol(i) { emCols[i].on = !emCols[i].on; emRenderCols(); }

function emToggleAll() {
    const anyOff = emCols.some(c => !c.on);
    emCols.forEach(c => c.on = anyOff);
    document.getElementById('em-selall-btn').textContent = anyOff ? 'Deselect all' : 'Select all';
    emRenderCols();
}

function emSetFmt(el) {
    emFmt = el.dataset.fmt;
    document.querySelectorAll('.em-fmt').forEach(b => b.classList.remove('active'));
    el.classList.add('active');
    const extMap = { csv: '.csv', xlsx: '.xlsx', json: '.json', pdf: '.pdf' };
    document.getElementById('em-ext').textContent = extMap[emFmt];
    emUpdateFooter();
}

function emUpdateFooter() {
    const on = emCols.filter(c => c.on).length;
    const fmtLabels = { csv: 'CSV', xlsx: 'Excel', json: 'JSON', pdf: 'PDF' };
    document.getElementById('em-footer-info').textContent = `${on} of ${emCols.length} columns · ${fmtLabels[emFmt]} format`;
    document.getElementById('em-export-btn').disabled = on === 0;
    const anyOff = emCols.some(c => !c.on);
    document.getElementById('em-selall-btn').textContent = anyOff ? 'Select all' : 'Deselect all';
}

// ── Build data for export ──

function emBuildData() {
    const on = emCols.filter(c => c.on).map(c => c.key);
    const headers = emCols.filter(c => c.on).map(c => c.label);
    let rows = [];

    if (emActiveTab === 'results') {
        let sr = 0, curNDC = null;
        for (const row of filteredRows) {
            if (row.ndc !== curNDC) { curNDC = row.ndc; sr = 1; } else sr++;
            const pkg = row.packageSize || row.ndcGroup?.packageSize || 0, d = row.diff;
            const units = row.type === 'total' ? (d < 0 && pkg > 0 ? (Math.abs(d) / pkg).toFixed(2) : '✔') : '';
            const statusStr = row.type === 'total' ? (d === 0 ? 'OK' : d > 0 ? `OVER (${Math.abs(d).toFixed(1)})` : `SHORT (${Math.abs(d).toFixed(1)})`) : '';
            const diffStr = row.type === 'detail' ? (d > 0 ? 'OVER' : d === 0 ? 'OK' : `SHORT (${Math.abs(d).toFixed(0)})`) : '';
            const obj = { sr, description: row.description, ndc: row.ndc, packageSize: row.packageSize || '', insName: row.insName || (row.type === 'total' ? '[TOTAL]' : ''), binNo: row.binNo || '', rxQty: row.rxQty, purchaseQty: row.purchaseQty, diff: diffStr || statusStr, status: statusStr, units, brand: row.brand || '', drugForm: row.drugForm || '' };
            rows.push(on.map(k => obj[k] ?? ''));
        }
    }
    else if (emActiveTab === 'suppliers') {
        Object.keys(purchaseMap).sort((a, b) => (purchaseMap[a].description || '').localeCompare(purchaseMap[b].description || '')).forEach((ndc, i) => {
            const sup = purchaseMap[ndc]; const transactions = supTransactions[ndc] || []; const fileTotals = supFileTotals[ndc] || {};
            const pkgSizes = [...new Set(transactions.map(t => t.sz))].sort((a, b) => a - b).map(sz => sz === Math.floor(sz) ? Math.floor(sz) : sz).join(', ');
            const calc = transactions.map(t => `(${t.qty}x${t.sz === Math.floor(t.sz) ? Math.floor(t.sz) : t.sz})`).join(' + ');
            const suppliersStr = Object.entries(fileTotals).map(([f, t]) => `${f}(${t})`).join('; ');
            const obj = { sr: i + 1, ndc, description: sup.description || '', pkgSize: pkgSizes, suppliers: suppliersStr, calc, total: sup.totalQty };
            rows.push(on.map(k => obj[k] ?? ''));
        });
    }
    else if (emActiveTab === 'final') {
        [...ndcGroups].sort((a, b) => a.description.localeCompare(b.description)).forEach((g, i) => {
            const insurers = [...new Set(g.insurerRows.map(r => r.insName).filter(Boolean))].join('; ');
            const pkg = g.packageSize || 0; const inits = pkg > 0 && g.totalRxQty > 0 ? Math.round(g.totalRxQty / pkg) : '';
            const statusStr = g.status === 'ok' ? 'OK' : g.status === 'over' ? `OVER (${Math.abs(g.diff).toFixed(1)})` : `SHORT (${g.diff.toFixed(1)})`;
            const obj = { sr: i + 1, ndc: g.ndc, description: g.description, packageSize: pkg || '', insurers, initsPerPkg: inits, needed: g.totalRxQty, ordered: g.totalPurchaseQty, variance: g.diff, status: statusStr };
            rows.push(on.map(k => obj[k] ?? ''));
        });
    }
    else if (emActiveTab === 'bill') {
        const insMap = {};
        for (const grp of ndcGroups) {
            for (const ins of grp.insurerRows) { const key = ins.insName || 'UNKNOWN'; if (!insMap[key]) insMap[key] = { insName: ins.insName, bins: new Set(), ndcs: new Set(), totalRxQty: 0, totalPurchaseQty: 0, ok: 0, over: 0, short: 0 }; for (const b of ins.bins) insMap[key].bins.add(b); insMap[key].ndcs.add(grp.ndc); insMap[key].totalRxQty += ins.qty; insMap[key][grp.status]++; }
            for (const ins of grp.insurerRows) { const key = ins.insName || 'UNKNOWN'; if (insMap[key] && !insMap[key]['_p' + grp.ndc]) { insMap[key]['_p' + grp.ndc] = true; insMap[key].totalPurchaseQty += grp.totalPurchaseQty; } }
        }
        Object.values(insMap).sort((a, b) => b.totalRxQty - a.totalRxQty).forEach((r, i) => {
            const obj = { sr: i + 1, insName: r.insName, bins: [...r.bins].sort().join(', '), ndcCount: r.ndcs.size, totalRxQty: r.totalRxQty, totalPurchaseQty: r.totalPurchaseQty, ok: r.ok, over: r.over, short: r.short };
            rows.push(on.map(k => obj[k] ?? ''));
        });
    }
    else if (emActiveTab === 'discarded') {
        const supplied = new Set(Object.keys(purchaseMap)); const discMap = {};
        for (const r of billingRows) { if (supplied.has(r.ndc)) continue; if (!discMap[r.ndc]) discMap[r.ndc] = { ndc: r.ndc, desc: r.drgName || '', strong: r.strong || '', form: r.form || '', insurerQty: {}, total: 0 }; const ins = r.insName || 'UNKNOWN'; if (!discMap[r.ndc].insurerQty[ins]) discMap[r.ndc].insurerQty[ins] = 0; discMap[r.ndc].insurerQty[ins] += r.qty; discMap[r.ndc].total += r.qty; }
        Object.values(discMap).sort((a, b) => (a.desc || '').localeCompare(b.desc || '')).forEach((r, i) => {
            const desc = buildDesc(r.desc, r.strong, r.form); const insurers = Object.entries(r.insurerQty).sort((a, b) => b[1] - a[1]);
            if (!insurers.length) { rows.push(on.map(k => ({ sr: i + 1, ndc: r.ndc, description: desc, insurer: '—', billedQty: 0, total: r.total, status: 'NO SUPPLIER' }[k] ?? ''))); }
            else { insurers.forEach(([ins, qty], j) => { const obj = { sr: j === 0 ? i + 1 : '', ndc: j === 0 ? r.ndc : '', description: j === 0 ? desc : '', insurer: ins, billedQty: qty, total: j === 0 ? r.total : '', status: 'NO SUPPLIER' }; rows.push(on.map(k => obj[k] ?? '')); }); }
        });
    }
    else if (emActiveTab === 'issues') {
        ndcGroups.filter(g => g.status === 'short').sort((a, b) => Math.abs(a.diff) - Math.abs(b.diff)).forEach((g, i) => {
            const pkg = g.packageSize || 0; const topIns = [...g.insurerRows].sort((a, b) => b.qty - a.qty)[0];
            const obj = { sr: i + 1, ndc: g.ndc, description: g.description, pkgSize: pkg || '', needed: g.totalRxQty, ordered: g.totalPurchaseQty, shortAmt: Math.abs(g.diff), unitsNeeded: pkg > 0 ? Math.ceil(Math.abs(g.diff) / pkg) : '', topInsurer: topIns ? topIns.insName : '' };
            rows.push(on.map(k => obj[k] ?? ''));
        });
    }
    else if (emActiveTab === 'notbilled') {
        const billed = new Set(billingRows.map(r => r.ndc));
        Object.keys(purchaseMap).filter(n => !billed.has(n)).sort((a, b) => (purchaseMap[a].description || '').localeCompare(purchaseMap[b].description || '')).forEach((ndc, i) => {
            const sup = purchaseMap[ndc]; const transactions = supTransactions[ndc] || []; const fileTotals = supFileTotals[ndc] || {};
            const pkgSizes = [...new Set(transactions.map(t => t.sz))].sort((a, b) => a - b).map(sz => sz === Math.floor(sz) ? Math.floor(sz) : sz).join(', ');
            const calc = transactions.map(t => `(${t.qty}x${t.sz === Math.floor(t.sz) ? Math.floor(t.sz) : t.sz})`).join(' + ');
            const suppliersStr = Object.entries(fileTotals).map(([f, t]) => `${f}(${t})`).join('; ');
            const obj = { sr: i + 1, ndc, description: sup.description || '', pkgSize: pkgSizes, suppliers: suppliersStr, calc, total: sup.totalQty, status: 'NOT BILLED' };
            rows.push(on.map(k => obj[k] ?? ''));
        });
    }
    else if (emActiveTab === 'mfp') {
        const mfpGrps = ndcGroups.filter(g => MFP_NDCS[g.ndc]);
        let sr = 0, curNDC = null;
        for (const grp of mfpGrps) {
            for (const ins of grp.insurerRows) {
                if (grp.ndc !== curNDC) { curNDC = grp.ndc; sr = 1; } else sr++;
                const d = grp.totalPurchaseQty - ins.qty; const diffStr = d > 0 ? 'OVER' : d === 0 ? 'OK' : `SHORT (${Math.abs(d).toFixed(0)})`;
                const obj = { sr, description: grp.description, ndc: grp.ndc, packageSize: grp.packageSize || '', insName: ins.insName, binNo: ins.binNo, rxQty: ins.qty, purchaseQty: grp.totalPurchaseQty, diff: diffStr, status: grp.status.toUpperCase(), year: (MFP_NDCS[grp.ndc] || []).join(', ') };
                rows.push(on.map(k => obj[k] ?? ''));
            }
        }
    }

    return { headers, rows };
}

// ── Execute export ──

function emDoExport() {
    const btn = document.getElementById('em-export-btn');
    btn.textContent = 'Exporting…'; btn.disabled = true;
    setTimeout(() => {
        try {
            const fname = document.getElementById('em-fname').value.trim() || 'NDC_Export';
            const { headers, rows } = emBuildData();
            if (emFmt === 'csv') emExportCSV(headers, rows, fname);
            else if (emFmt === 'xlsx') emExportXLSX(headers, rows, fname);
            else if (emFmt === 'json') emExportJSON(headers, rows, fname);
            else if (emFmt === 'pdf') emExportPDF(headers, rows, fname);
            closeExportModal();
        } catch (e) { alert('Export error: ' + e.message); console.error(e); }
        btn.textContent = '⬇ Export'; btn.disabled = false;
    }, 50);
}

function emExportCSV(headers, rows, fname) {
    const escape = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = [headers.map(escape).join(',')];
    for (const r of rows) lines.push(r.map(escape).join(','));
    emDownload(new Blob([lines.join('\n')], { type: 'text/csv' }), fname + '.csv');
}

function emExportJSON(headers, rows, fname) {
    const data = rows.map(r => { const obj = {}; headers.forEach((h, i) => obj[h] = r[i] ?? ''); return obj; });
    emDownload(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), fname + '.json');
}

function emExportXLSX(headers, rows, fname) {
    if (typeof XLSX === 'undefined') { alert('XLSX library not loaded.'); return; }
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    ws['!cols'] = headers.map((h, i) => ({ wch: Math.min(40, Math.max(h.length, ...rows.map(r => String(r[i] ?? '').length)) + 2) }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, emActiveTab.charAt(0).toUpperCase() + emActiveTab.slice(1));
    XLSX.writeFile(wb, fname + '.xlsx');
}

function emExportPDF(headers, rows, fname) {
    if (typeof window.jspdf === 'undefined') { alert('jsPDF library not loaded.'); return; }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: headers.length > 6 ? 'landscape' : 'portrait', unit: 'pt', format: 'a4' });
    doc.setFontSize(13); doc.text('NDC Viewer — ' + (EM_TAB_LABELS[emActiveTab] || emActiveTab), 40, 36);
    doc.setFontSize(9); doc.setTextColor(120); doc.text(`Exported: ${new Date().toLocaleString()}  ·  ${rows.length} rows`, 40, 52);
    doc.autoTable({ head: [headers], body: rows.map(r => r.map(v => String(v ?? ''))), startY: 64, styles: { fontSize: 7.5, cellPadding: 3, overflow: 'linebreak' }, headStyles: { fillColor: [37, 99, 235], textColor: 255, fontStyle: 'bold', fontSize: 8 }, alternateRowStyles: { fillColor: [245, 247, 250] }, margin: { left: 30, right: 30 } });
    doc.save(fname + '.pdf');
}

function emDownload(blob, filename) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

// Close modal on backdrop click
document.getElementById('export-overlay').addEventListener('click', function (e) { if (e.target === this) closeExportModal(); });
