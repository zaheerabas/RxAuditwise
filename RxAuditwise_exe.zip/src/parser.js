// ════════════════════════════════════
//  FILE INPUT LISTENERS
// ════════════════════════════════════

document.getElementById('inp-supplier').addEventListener('change', function (e) {
    supplierFiles = Array.from(e.target.files);
    document.getElementById('card-supplier').classList.toggle('loaded', supplierFiles.length > 0);
    document.getElementById('fn-supplier').textContent = supplierFiles.map(f => f.name).join(', ');
    checkReady();
});

document.getElementById('inp-billing').addEventListener('change', function (e) {
    billingFile = e.target.files[0] || null;
    document.getElementById('card-billing').classList.toggle('loaded', !!billingFile);
    document.getElementById('fn-billing').textContent = billingFile ? billingFile.name : '';
    checkReady();
});

// ════════════════════════════════════
//  PROCESS ENTRY POINT
// ════════════════════════════════════

async function processFiles() {
    // ── LICENSE CHECK ────────────────────────────────────────────────────────
    showProg(true, 'Verifying subscription…', 5);
    await tick();
    try {
        const lic = await licCheckFiles(supplierFiles, billingFile);
        if (!lic.allowed) {
            showProg(false, '', 0);
            licShowGate(lic);
            return;
        }
    } catch (licErr) {
        showProg(false, '', 0);
        alert('License check failed:\n' + licErr.message);
        return;
    }
    // ── END LICENSE CHECK ────────────────────────────────────────────────────

    showProg(true, 'Reading supplier files…', 10);
    purchaseMap = {}; supTransactions = {}; supFileTotals = {}; billingRows = []; rawPreviewData = [];
    try {
        for (const f of supplierFiles) await readSupplier(f);
        showProg(true, 'Reading billing file…', 40);
        await readBilling(billingFile);
        showProg(true, 'Reconciling…', 70);
        await tick(); reconcile();
        showProg(true, 'Rendering…', 90);
        await tick(); renderAll();
        showProg(false, '', 100); showApp();
    } catch (err) {
        alert('Error:\n' + err.message);
        showProg(false, '', 0);
        console.error(err);
    }
}

// ════════════════════════════════════
//  SUPPLIER TRANSACTION TRACKER
// ════════════════════════════════════

function addSupTransaction(ndc, fileName, qty, size) {
    if (!ndc || ndc.length < 9) return;
    const sz = parseSize(size);
    const total = qty * sz;
    if (!supTransactions[ndc]) supTransactions[ndc] = [];
    supTransactions[ndc].push({ file: fileName, qty, sz, total });
    if (!supFileTotals[ndc]) supFileTotals[ndc] = {};
    if (!supFileTotals[ndc][fileName]) supFileTotals[ndc][fileName] = 0;
    supFileTotals[ndc][fileName] += total;
}

// ════════════════════════════════════
//  READ SUPPLIER FILE
// ════════════════════════════════════

async function readSupplier(file) {
    const ext = file.name.split('.').pop().toLowerCase();
    const MAX_PREVIEW = 500;

    if (ext === 'csv') {
        const text = await file.text();
        const lines = text.split('\n').map(l => l.replace(/\r/g, ''));
        let hi = 0;
        for (let i = 0; i < Math.min(lines.length, 8); i++) {
            const cols = csvLine(lines[i]).map(c => c.replace(/['"]/g, '').trim());
            const joined = cols.join(',').toLowerCase();
            if (cols.length >= 4 && (/ndc/i.test(joined) || /product.*desc/i.test(joined) || /description/i.test(joined))) {
                hi = i; break;
            }
        }
        const hdrs = csvLine(lines[hi]).map(h => h.replace(/['"]/g, '').trim());
        const ndcI = matchCol(hdrs, 'ndc'), descI = matchCol(hdrs, 'description'),
              qtyI = matchCol(hdrs, 'qty'), szI = matchCol(hdrs, 'size');
        const mappingIdx = { ndc: ndcI, qty: qtyI, desc: descI, size: szI };
        const previewRows = [];
        for (let i = hi + 1; i < Math.min(lines.length, MAX_PREVIEW + hi + 1); i++) {
            if (!lines[i].trim()) continue;
            previewRows.push(csvLine(lines[i]).map(c => c.replace(/^"|"$/g, '')));
        }
        rawPreviewData.push({ fileName: file.name, type: 'supplier', sheetName: null, headerRow: hi + 1, totalRows: lines.length - hi - 1, headers: hdrs, rows: previewRows, mappingIdx });
        if (ndcI < 0) return;
        for (let i = hi + 1; i < lines.length; i++) {
            const c = csvLine(lines[i]); if (c.length < 2) continue;
            const ndc = cleanNDC(c[ndcI]); if (!ndc || ndc.length < 9) continue;
            const desc = descI >= 0 ? c[descI].replace(/^"|"$/g, '').trim() : '';
            const qty = qtyI >= 0 ? (parseFloat(c[qtyI].replace(/[^0-9.]/g, '')) || 0) : 1;
            const szRaw = szI >= 0 ? c[szI] : ''; const sz = parseSize(szRaw);
            if (!purchaseMap[ndc]) purchaseMap[ndc] = { description: '', packageSize: 0, totalQty: 0 };
            purchaseMap[ndc].totalQty += qty * sz;
            if (!purchaseMap[ndc].packageSize && sz > 1) purchaseMap[ndc].packageSize = sz;
            if (!purchaseMap[ndc].description && desc) purchaseMap[ndc].description = desc;
            addSupTransaction(ndc, file.name, qty, szRaw);
        }
    } else {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: 'array' });
        for (const sheetName of wb.SheetNames) {
            const data = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '', header: 1 });
            if (!data.length) continue;
            const hdrs = (data[0] || []).map(h => String(h).trim());
            const ndcI = matchCol(hdrs, 'ndc'), descI = matchCol(hdrs, 'description'),
                  qtyI = matchCol(hdrs, 'qty'), szI = matchCol(hdrs, 'size');
            const mappingIdx = { ndc: ndcI, qty: qtyI, desc: descI, size: szI };
            const previewRows = data.slice(1, MAX_PREVIEW + 1).map(r => hdrs.map((_, i) => String(r[i] !== undefined ? r[i] : '')));
            const label = wb.SheetNames.length > 1 ? `${file.name} [${sheetName}]` : file.name;
            rawPreviewData.push({ fileName: label, type: 'supplier', sheetName, headerRow: 1, totalRows: data.length - 1, headers: hdrs, rows: previewRows, mappingIdx });
            if (ndcI < 0) continue;
            for (const rowArr of data.slice(1)) {
                const v = i => i >= 0 ? stripF(String(rowArr[i] !== undefined ? rowArr[i] : '')) : '';
                const ndc = cleanNDC(v(ndcI)); if (!ndc || ndc.length < 9) continue;
                const desc = descI >= 0 ? v(descI) : '';
                const qty = qtyI >= 0 ? (parseFloat(v(qtyI).replace(/[^0-9.]/g, '')) || 0) : 1;
                const szRaw = szI >= 0 ? v(szI) : ''; const sz = parseSize(szRaw);
                if (!purchaseMap[ndc]) purchaseMap[ndc] = { description: '', packageSize: 0, totalQty: 0 };
                purchaseMap[ndc].totalQty += qty * sz;
                if (!purchaseMap[ndc].packageSize && sz > 1) purchaseMap[ndc].packageSize = sz;
                if (!purchaseMap[ndc].description && desc) purchaseMap[ndc].description = desc;
                addSupTransaction(ndc, label, qty, szRaw);
            }
        }
    }
}

// ════════════════════════════════════
//  READ BILLING FILE
// ════════════════════════════════════

async function readBilling(file) {
    const ext = file.name.split('.').pop().toLowerCase();
    const MAX_PREVIEW = 500;
    let rows = [];

    if (ext === 'csv') {
        const lines = (await file.text()).split('\n').map(l => l.replace(/\r/g, ''));
        const hdrs = csvLine(lines[0]).map(h => h.replace(/['"]/g, '').trim());
        const ix = f => matchCol(hdrs, f);
        const [ndcI, insI, binI, qtyI, descI, strI, frmI, pkgI, brI] =
            ['ndc', 'insName', 'binNo', 'qty', 'description', 'drugStrong', 'drugForm', 'pkgSize', 'brand'].map(ix);
        const previewRows = [];
        for (let i = 1; i < Math.min(lines.length, MAX_PREVIEW + 1); i++) {
            if (!lines[i].trim()) continue;
            previewRows.push(csvLine(lines[i]).map(c => c.replace(/^"|"$/g, '')));
        }
        rawPreviewData.push({ fileName: file.name, type: 'billing', sheetName: null, headerRow: 1, totalRows: lines.length - 1, headers: hdrs, rows: previewRows, mappingIdx: { ndc: ndcI, qty: qtyI, ins: insI, bin: binI } });
        for (let i = 1; i < lines.length; i++) {
            const c = csvLine(lines[i]); if (c.length < 3) continue;
            const ndc = cleanNDC(c[ndcI]); if (!ndc || ndc.length < 9) continue;
            const rawIns = insI >= 0 ? stripF(c[insI]).toUpperCase() : '';
            const bin = normBIN(binI >= 0 ? c[binI] : '');
            rows.push({ ndc, insName: resolveInsName(rawIns, bin), binNo: bin, qty: qtyI >= 0 ? (parseFloat(stripF(c[qtyI])) || 0) : 0, drgName: descI >= 0 ? stripF(c[descI]) : '', strong: strI >= 0 ? stripF(c[strI]) : '', form: frmI >= 0 ? stripF(c[frmI]) : '', pkgSize: pkgI >= 0 ? (parseFloat(stripF(c[pkgI])) || 0) : 0, brand: brI >= 0 ? stripF(c[brI]) : '' });
        }
    } else {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: 'array' });
        const data = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '', header: 1 });
        if (!data.length) { billingRows = []; return; }
        const hdrs = (data[0] || []).map(h => String(h).trim());
        const ix = f => matchCol(hdrs, f);
        const [ndcI, insI, binI, qtyI, descI, strI, frmI, pkgI, brI] =
            ['ndc', 'insName', 'binNo', 'qty', 'description', 'drugStrong', 'drugForm', 'pkgSize', 'brand'].map(ix);
        const previewRows = data.slice(1, MAX_PREVIEW + 1).map(r => hdrs.map((_, i) => String(r[i] !== undefined ? r[i] : '')));
        rawPreviewData.push({ fileName: file.name, type: 'billing', sheetName: wb.SheetNames[0], headerRow: 1, totalRows: data.length - 1, headers: hdrs, rows: previewRows, mappingIdx: { ndc: ndcI, qty: qtyI, ins: insI, bin: binI } });
        for (const rowArr of data.slice(1)) {
            const v = i => i >= 0 ? stripF(String(rowArr[i] !== undefined ? rowArr[i] : '')) : '';
            const ndc = cleanNDC(v(ndcI)); if (!ndc || ndc.length < 9) continue;
            const rawIns = v(insI).toUpperCase(); const bin = normBIN(v(binI));
            rows.push({ ndc, insName: resolveInsName(rawIns, bin), binNo: bin, qty: parseFloat(v(qtyI)) || 0, drgName: v(descI), strong: v(strI), form: v(frmI), pkgSize: parseFloat(v(pkgI)) || 0, brand: v(brI) });
        }
    }
    billingRows = rows;
}

// ════════════════════════════════════
//  RECONCILE
// ════════════════════════════════════

function reconcile() {
    const grouped = {};
    for (const r of billingRows) {
        if (!grouped[r.ndc]) grouped[r.ndc] = [];
        grouped[r.ndc].push(r);
    }
    ndcGroups = [];
    for (const [ndc, rows] of Object.entries(grouped)) {
        const insMap = {};
        for (const r of rows) {
            // Normalize to lowercase key so "CAREMARK" and "Caremark" merge
            const key = (r.insName || 'UNKNOWN').trim().toLowerCase();
            if (!insMap[key]) {
                // Use title-case display name from first encounter
                const display = (r.insName || 'UNKNOWN').trim()
                    .toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
                insMap[key] = { insName: display, bins: [], qty: 0 };
            }
            insMap[key].qty += r.qty;
            if (r.binNo && !insMap[key].bins.includes(r.binNo)) insMap[key].bins.push(r.binNo);
        }
        const insurerRows = Object.values(insMap).map(r => ({ insName: r.insName, binNo: r.bins.join(', '), bins: r.bins, qty: r.qty }));
        const maxQty = Math.max(...insurerRows.map(r => r.qty));
        const totalRxQty = insurerRows.reduce((s, r) => s + r.qty, 0);
        const sup = purchaseMap[ndc] || {};
        const totalPurchaseQty = sup.totalQty || 0;
        const diff = totalPurchaseQty - totalRxQty;
        const status = diff === 0 ? 'ok' : diff > 0 ? 'over' : 'short';
        const s = rows[0];
        const drgName = s.drgName || sup.description || '';
        const strong = s.strong || ''; const form = s.form || '';
        ndcGroups.push({ ndc, drgName, strong, form, description: buildDesc(drgName, strong, form) || drgName.toUpperCase(), packageSize: s.pkgSize || sup.packageSize || 0, insurerRows, maxQty, totalRxQty, totalPurchaseQty, diff, status, brand: s.brand, drugForm: (form || '').toUpperCase() });
    }
    ndcGroups.sort((a, b) => a.description.localeCompare(b.description));
}
