# RxAuditwise — Desktop App Builder

## Before Building — Update Your Server URL

Open **main.js** and change line 6:
```js
const SERVER_URL = 'https://software.rxauditwise.com'; // ← your URL
```

Open **src/license.js** and change line 10:
```js
const LIC_API = 'https://software.rxauditwise.com/api.php'; // ← your URL
```

---

## Build Windows .EXE (Step by Step)

### Requirements
- Windows 10 or 11
- Node.js LTS from https://nodejs.org

### Steps
1. Install Node.js (if not already installed)
2. Extract this folder anywhere, e.g. `C:\rxauditwise-build\`
3. Double-click `build-windows.bat`
4. Wait 3-8 minutes
5. Find your installer in `dist\` folder

### Output files
- `dist\RxAuditwise Setup 1.0.0.exe` — Standard installer (recommended)
- `dist\RxAuditwise-Portable-1.0.0.exe` — Portable, no install needed

---

## Project Structure

```
rxauditwise-electron/
├── main.js          ← Electron window (EDIT: server URL line 6)
├── preload.js       ← Security bridge
├── package.json     ← Build settings
├── LICENSE.txt      ← Shown during install
├── build-windows.bat ← Double-click to build
└── src/
    ├── index.html   ← Main app interface
    ├── license.js   ← License check (EDIT: server URL line 10)
    ├── styles.css
    ├── *.js         ← App logic
    └── icon.ico     ← App icon (replace with your own)
```

---

## How License Works

1. User installs the .exe and opens RxAuditwise
2. User uploads their CSV files
3. App calls YOUR server to check if their code is registered
4. Admin panel (admin.html on your server) controls all access
5. No changes to the .exe needed when adding/renewing users

---

## Updating the App

When you want to release a new version:
1. Update the files in `src/`
2. Change version in `package.json`: `"version": "1.1.0"`
3. Run `build-windows.bat` again
4. Distribute the new `dist\RxAuditwise Setup 1.1.0.exe`
